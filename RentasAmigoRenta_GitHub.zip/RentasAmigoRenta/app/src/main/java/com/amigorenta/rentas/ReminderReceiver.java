package com.amigorenta.rentas;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("rentas", "Rentas Amigo Renta", NotificationManager.IMPORTANCE_HIGH));
        int code = i.getIntExtra("code", (int) (System.currentTimeMillis() % 100000));
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        String title = i.getStringExtra("title");
        String text = i.getStringExtra("text");
        if (title == null) title = "Rentas Amigo Renta";
        if (text == null) text = "";
        Notification.Builder b = new Notification.Builder(c, "rentas")
                .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(open)
                .setAutoCancel(true);
        String action = i.getStringExtra("action");
        if (action != null) {
            Intent wa = Store.waIntent(c, i.getStringExtra("waPhone"), i.getStringExtra("waText"));
            wa.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent pa = PendingIntent.getActivity(c, code, wa,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            b.addAction(new Notification.Action.Builder(
                    Icon.createWithResource(c, android.R.drawable.sym_action_chat), "💬 " + action, pa).build());
        }
        nm.notify(code, b.build());
    }
}
