package com.amigorenta.rentas;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {

    static final int PRI = 0xFF0D3B7A, PRI2 = 0xFF1565C0, BG = 0xFFF3F6FB, TXT = 0xFF1A2433,
            MUT = 0xFF6B7585, BRD = 0xFFE1E7EF, RED = 0xFFDC2626, GRN = 0xFF16A34A, ORG = 0xFFEA580C, YEL = 0xFFB45309;
    static final String[] METHODS = {"e-Transfer", "Efectivo", "Cheque", "Depósito", "Otro"};
    static final int REQ_EXPORT = 91, REQ_PHOTO = 92, REQ_PICK = 93, REQ_IMPORT = 94;
    static final int TXT_CAP = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    static final int TXT_MULTI = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;
    static final int DEC = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL;

    interface Cb { void on(String s); }

    List<JSONObject> tenants, recs, detected;
    FrameLayout content;
    LinearLayout header, nav;
    TextView fab;
    final ArrayList<Runnable> stack = new ArrayList<>();
    int tabSel = 0;
    String month, filter = "Todos", search = "", tSearch = "", exportMonth, propFilter = "";
    // formulario de pago (se conserva al tomar la foto)
    String formKey = "", formAmt = null, formRef = "", formMethod = "e-Transfer", formImg = "";
    long formDate = 0;
    int pendingPayId = -1;
    Uri pendingCap;

    // ============================ ciclo de vida ============================
    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        month = Store.thisMonth();
        reload();
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        LinearLayout col = vbox();
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        header = hbox();
        header.setBackgroundColor(PRI);
        header.setPadding(dp(16), dp(14), dp(16), dp(14));
        col.addView(header, new LinearLayout.LayoutParams(-1, -2));
        content = new FrameLayout(this);
        col.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = buildNav();
        col.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        fab = tv("", 15, Color.WHITE, true);
        fab.setBackground(round(PRI2, 28));
        fab.setPadding(dp(22), dp(14), dp(22), dp(14));
        fab.setElevation(dp(6));
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        fl.setMargins(0, 0, dp(16), dp(84));
        root.addView(fab, fl);
        setContentView(root);
        Backup.autoBackup(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        openTab(getIntent() != null ? getIntent().getIntExtra("tab", 0) : 0);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i != null && i.hasExtra("tab")) { reload(); openTab(i.getIntExtra("tab", 0)); }
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
        autoExport();
        if (!stack.isEmpty()) stack.get(stack.size() - 1).run();
    }

    void reload() {
        tenants = Store.list(this, "tenants");
        recs = Store.list(this, "recs");
        detected = Store.list(this, "detected");
    }

    void saveAll() {
        Store.save(this, "tenants", tenants);
        Store.save(this, "recs", recs);
        Store.save(this, "detected", detected);
    }

    // ============================ navegación ============================
    void open(Runnable r) { stack.add(r); r.run(); }

    void openTab(int k) {
        tabSel = k;
        stack.clear();
        if (k == 0) open(this::monthScreen);
        else if (k == 1) open(this::tenantsScreen);
        else if (k == 2) open(this::etScreen);
        else open(this::more);
    }

    void goBack() {
        if (stack.size() > 1) { stack.remove(stack.size() - 1); stack.get(stack.size() - 1).run(); }
        else if (tabSel != 0) openTab(0);
        else finish();
    }

    void refresh() { if (!stack.isEmpty()) stack.get(stack.size() - 1).run(); }

    @Override
    public void onBackPressed() { goBack(); }

    void setHeader(String title, String sub, String icon, boolean back) {
        header.removeAllViews();
        if (back) {
            TextView bk = tv("←", 24, Color.WHITE, true);
            bk.setPadding(dp(2), 0, dp(16), 0);
            bk.setOnClickListener(v -> goBack());
            header.addView(bk);
        } else if (icon != null) {
            TextView ic = tv(icon, 24, Color.WHITE, false);
            ic.setPadding(0, 0, dp(12), 0);
            header.addView(ic);
        }
        LinearLayout t = vbox();
        TextView tt = tv(title, 20, Color.WHITE, true);
        tt.setMaxLines(1);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        t.addView(tt);
        if (sub != null) t.addView(tv(sub, 13, 0xFFCFE0FF, false));
        header.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
    }

    void show(View body, boolean navOn, String fabText, Runnable fabAction) {
        content.removeAllViews();
        content.addView(body, new FrameLayout.LayoutParams(-1, -1));
        nav.setVisibility(navOn ? View.VISIBLE : View.GONE);
        if (fabText != null) {
            fab.setText(fabText);
            fab.setOnClickListener(v -> fabAction.run());
            fab.setVisibility(View.VISIBLE);
        } else fab.setVisibility(View.GONE);
        refreshNav();
    }

    static final String[][] TABS = {{"📅", "Mes"}, {"👥", "Inquilinos"}, {"📩", "e-Transfers"}, {"☰", "Más"}};

    LinearLayout buildNav() {
        LinearLayout n = hbox();
        n.setBackgroundColor(Color.WHITE);
        n.setElevation(dp(10));
        n.setPadding(dp(4), dp(4), dp(4), dp(4));
        for (int i = 0; i < TABS.length; i++) {
            final int k = i;
            LinearLayout it = vbox();
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, dp(6), 0, dp(6));
            TextView ic = tv(TABS[i][0], 19, TXT, false);
            ic.setGravity(Gravity.CENTER);
            TextView lb = tv(TABS[i][1], 11, MUT, false);
            lb.setGravity(Gravity.CENTER);
            it.addView(ic);
            it.addView(lb);
            it.setTag(lb);
            it.setOnClickListener(v -> openTab(k));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            n.addView(it, lp);
        }
        return n;
    }

    void refreshNav() {
        for (int i = 0; i < nav.getChildCount(); i++) {
            View it = nav.getChildAt(i);
            TextView lb = (TextView) it.getTag();
            boolean s = i == tabSel;
            lb.setTextColor(s ? PRI2 : MUT);
            lb.setTypeface(s ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            it.setBackground(s ? round(0xFFEAF1FF, 12) : null);
        }
    }

    // ============================ cálculos ============================
    String money(double v) { return Store.money(this, v); }

    List<JSONObject> activeTenants(String m) {
        List<JSONObject> r = new ArrayList<>();
        for (JSONObject t : tenants) if (Store.activeIn(t, m)) r.add(t);
        return r;
    }

    /** 0 pagado, 1 parcial, 2 pendiente, 3 atrasado */
    int status(JSONObject t, String m) {
        JSONObject r = Store.rec(recs, t.optInt("id"), m, false);
        double due = Store.due(t, r), pd = Store.paid(r);
        if (pd >= due - 0.009) return 0;
        String dd = Store.dueDate(t, m, this);
        int grace = Store.getI(this, "grace", 0);
        boolean late = Store.daysBetween(dd, Store.today()) > grace;
        if (late) return 3;
        return pd > 0.009 ? 1 : 2;
    }

    static final String[] ST_NAMES = {"Pagado", "Parcial", "Pendiente", "Atrasado"};
    static final int[][] ST_COL = {{0xFF15803D, 0xFFE3F6E8}, {0xFFB45309, 0xFFFFF1DB}, {0xFF1D4ED8, 0xFFE4ECFF}, {0xFFB91C1C, 0xFFFDE6E6}};
    static final String[] ST_ICON = {"✅", "🟡", "⏳", "🔴"};

    long lastPaymentDate(JSONObject r) {
        long l = 0;
        if (r == null) return 0;
        JSONArray p = r.optJSONArray("payments");
        if (p != null) for (int i = 0; i < p.length(); i++) { JSONObject x = p.optJSONObject(i); if (x != null) l = Math.max(l, x.optLong("date")); }
        return l;
    }

    String statusLine(JSONObject t, String m) {
        JSONObject r = Store.rec(recs, t.optInt("id"), m, false);
        int s = status(t, m);
        double owed = Store.due(t, r) - Store.paid(r);
        String dd = Store.dueDate(t, m, this);
        if (s == 0) return "✅ Pagado" + (lastPaymentDate(r) > 0 ? " el " + Store.shortDate(Store.dayOf(lastPaymentDate(r))) : "");
        if (s == 3) {
            int d = Store.daysBetween(dd, Store.today());
            return "🔴 Atrasado " + d + (d == 1 ? " día" : " días") + " · faltan " + money(owed);
        }
        if (s == 1) return "🟡 Parcial · faltan " + money(owed);
        return "⏳ Vence el " + Store.shortDate(dd);
    }

    // ============================ pantalla del mes ============================
    void monthScreen() {
        List<JSONObject> act = activeTenants(month);
        setHeader("Rentas · " + Store.monthName(month), act.size() + " inquilinos", "📅", false);
        LinearLayout p = vbox();

        LinearLayout mn = hbox();
        mn.setPadding(dp(14), dp(10), dp(14), 0);
        TextView prev = tv("‹", 28, PRI2, true);
        prev.setPadding(dp(14), 0, dp(14), 0);
        prev.setOnClickListener(v -> { month = Store.addMonth(month, -1); monthScreen(); });
        TextView ml = tv(Store.monthName(month), 18, TXT, true);
        ml.setGravity(Gravity.CENTER);
        TextView next = tv("›", 28, PRI2, true);
        next.setPadding(dp(14), 0, dp(14), 0);
        next.setOnClickListener(v -> { month = Store.addMonth(month, 1); monthScreen(); });
        mn.addView(prev);
        mn.addView(ml, new LinearLayout.LayoutParams(0, -2, 1f));
        mn.addView(next);
        p.addView(mn);
        if (!month.equals(Store.thisMonth())) {
            TextView hoy = tv("Volver al mes actual", 13, PRI2, true);
            hoy.setGravity(Gravity.CENTER);
            hoy.setOnClickListener(v -> { month = Store.thisMonth(); monthScreen(); });
            p.addView(hoy, new LinearLayout.LayoutParams(-1, -2));
        }

        double exp = 0, got = 0;
        int[] cnt = new int[4];
        for (JSONObject t : act) {
            JSONObject r = Store.rec(recs, t.optInt("id"), month, false);
            exp += Store.due(t, r);
            got += Math.min(Store.paid(r), Store.due(t, r));
            cnt[status(t, month)]++;
        }
        LinearLayout big = card();
        big.setBackground(round(PRI, 18));
        LinearLayout r1 = hbox();
        r1.addView(bigNum("Esperado", money(exp), Color.WHITE), new LinearLayout.LayoutParams(0, -2, 1f));
        r1.addView(bigNum("Cobrado", money(got), 0xFF86EFAC), new LinearLayout.LayoutParams(0, -2, 1f));
        r1.addView(bigNum("Falta", money(exp - got), 0xFFFCA5A5), new LinearLayout.LayoutParams(0, -2, 1f));
        big.addView(r1);
        LinearLayout bar = hbox();
        bar.setBackground(round(0x33FFFFFF, 6));
        bar.setClipToOutline(true);
        float pct = exp > 0 ? (float) (got / exp) : 0;
        View fill = new View(this);
        fill.setBackgroundColor(0xFF4ADE80);
        bar.addView(fill, new LinearLayout.LayoutParams(0, dp(10), Math.max(pct, 0.0001f)));
        bar.addView(new View(this), new LinearLayout.LayoutParams(0, dp(10), Math.max(1 - pct, 0.0001f)));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(10));
        bl.setMargins(0, dp(12), 0, dp(4));
        big.addView(bar, bl);
        big.addView(tv(Math.round(pct * 100) + "% cobrado", 12, 0xFFCFE0FF, true));
        p.addView(big);

        LinearLayout chips = hbox();
        chips.setPadding(dp(10), dp(4), dp(10), 0);
        String[] fs = {"Todos", "Faltan", "Pagado", "Parcial", "Pendiente", "Atrasado"};
        for (String o : fs) {
            String lbl = o;
            if (o.equals("Todos")) lbl = "Todos (" + act.size() + ")";
            else if (o.equals("Faltan")) lbl = "Faltan por pagar (" + (cnt[1] + cnt[2] + cnt[3]) + ")";
            else for (int i = 0; i < 4; i++) if (ST_NAMES[i].equals(o)) lbl = ST_ICON[i] + " " + o + " (" + cnt[i] + ")";
            chips.addView(chip(lbl, o.equals(filter), v -> { filter = o; monthScreen(); }));
        }
        p.addView(hscroll(chips));

        TextView pf = field("🏠  " + (propFilter.isEmpty() ? "Todas las propiedades" : propFilter) + "  ▾");
        ((LinearLayout.LayoutParams) pf.getLayoutParams()).setMargins(dp(14), dp(6), dp(14), 0);
        pf.setOnClickListener(x -> {
            List<String> ps = properties();
            ps.add(0, "Todas las propiedades");
            new AlertDialog.Builder(this).setTitle("Propiedad").setItems(ps.toArray(new String[0]), (dlg, w) -> {
                propFilter = w == 0 ? "" : ps.get(w);
                monthScreen();
            }).show();
        });
        p.addView(pf);
        EditText s = input("🔍  Buscar inquilino o cuarto", InputType.TYPE_CLASS_TEXT);
        s.setText(search);
        ((LinearLayout.LayoutParams) s.getLayoutParams()).setMargins(dp(14), dp(6), dp(14), dp(4));
        p.addView(s);
        final LinearLayout list = vbox();
        p.addView(list);
        final Runnable fillList = () -> {
            list.removeAllViews();
            String q = Store.norm(search);
            List<JSONObject> l = new ArrayList<>();
            for (JSONObject t : act) {
                int st = status(t, month);
                if (filter.equals("Faltan") && st == 0) continue;
                if (!filter.equals("Todos") && !filter.equals("Faltan") && !ST_NAMES[st].equals(filter)) continue;
                if (!propFilter.isEmpty() && !Store.norm(t.optString("property")).equals(Store.norm(propFilter))) continue;
                if (!q.isEmpty() && !Store.norm(t.optString("name") + " " + t.optString("property") + " " + room(t)).contains(q)) continue;
                l.add(t);
            }
            Collections.sort(l, (x, y) -> {
                int a = order(status(x, month)), c = order(status(y, month));
                if (a != c) return Integer.compare(a, c);
                return (x.optString("property") + x.optString("unit") + x.optString("name"))
                        .compareToIgnoreCase(y.optString("property") + y.optString("unit") + y.optString("name"));
            });
            if (tenants.isEmpty()) list.addView(empty("Todavía no hay inquilinos.\nAgrégalos en 👥 Inquilinos, o pega tu lista desde Excel en Más → Importar lista."));
            else if (l.isEmpty()) list.addView(empty("No hay inquilinos con este filtro"));
            for (JSONObject t : l) list.addView(monthRow(t));
        };
        s.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable e) { search = e.toString(); fillList.run(); }
        });
        fillList.run();
        show(scroll(p), true, "＋  Registrar pago", () -> pickTenant(month, id -> open(() -> payScreen(Integer.parseInt(id), month))));
    }

    static int order(int st) { return st == 3 ? 0 : st == 1 ? 1 : st == 2 ? 2 : 3; }

    View bigNum(String label, String value, int color) {
        LinearLayout b = vbox();
        b.addView(tv(label, 12, 0xFFCFE0FF, true));
        TextView v = tv(value, 18, color, true);
        v.setMaxLines(1);
        b.addView(v);
        return b;
    }

    View monthRow(JSONObject t) {
        int st = status(t, month);
        JSONObject r = Store.rec(recs, t.optInt("id"), month, false);
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        TextView ic = tv(ST_ICON[st], 20, TXT, false);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(round(ST_COL[st][1], 12));
        c.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout v = vbox();
        v.setPadding(dp(12), 0, dp(6), 0);
        TextView nm = tv(t.optString("name"), 16, TXT, true);
        nm.setMaxLines(1);
        nm.setEllipsize(TextUtils.TruncateAt.END);
        v.addView(nm);
        String where = where(t);
        if (!where.isEmpty()) { TextView w = tv(where, 13, MUT, false); w.setMaxLines(1); w.setEllipsize(TextUtils.TruncateAt.END); v.addView(w); }
        v.addView(tv(statusLine(t, month), 13, ST_COL[st][0], true));
        if (r != null && !r.optString("promise").isEmpty() && st != 0)
            v.addView(tv("🤝 Prometió pagar el " + Store.shortDate(r.optString("promise")), 13, PRI2, true));
        c.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout g = vbox();
        g.setGravity(Gravity.END);
        g.addView(tv(money(Store.due(t, r)), 15, TXT, true));
        if (Store.paid(r) > 0.009 && st != 0) g.addView(tv("pagó " + money(Store.paid(r)), 12, GRN, true));
        c.addView(g);
        final int id = t.optInt("id");
        final String m = month;
        c.setOnClickListener(x -> open(() -> payScreen(id, m)));
        return c;
    }

    void pickTenant(String m, Cb cb) {
        List<JSONObject> l = activeTenants(m);
        if (l.isEmpty()) { toast("Primero agrega inquilinos"); return; }
        Collections.sort(l, (x, y) -> {
            int a = order(status(x, m)), b = order(status(y, m));
            return a != b ? Integer.compare(a, b) : x.optString("name").compareToIgnoreCase(y.optString("name"));
        });
        String[] names = new String[l.size()];
        for (int i = 0; i < names.length; i++) {
            JSONObject t = l.get(i);
            names[i] = ST_ICON[status(t, m)] + " " + t.optString("name") + (where(t).isEmpty() ? "" : " · " + where(t));
        }
        new AlertDialog.Builder(this).setTitle("Elige el inquilino")
                .setItems(names, (dlg, w) -> cb.on(String.valueOf(l.get(w).optInt("id")))).show();
    }

    // ============================ pago / seguimiento de un inquilino ============================
    void payScreen(int tid, String m) {
        final JSONObject t = Store.tenant(tenants, tid);
        if (t == null) { goBack(); return; }
        final JSONObject r0 = Store.rec(recs, tid, m, false);
        int st = status(t, m);
        double due = Store.due(t, r0), pd = Store.paid(r0), owed = Math.max(0, due - pd);
        setHeader(t.optString("name"), Store.monthName(m), null, true);
        LinearLayout p = vbox();

        LinearLayout c = card();
        c.setBackground(round(ST_COL[st][1], 16));
        c.addView(tv(statusLine(t, m), 17, ST_COL[st][0], true));
        String where = where(t);
        if (!where.isEmpty()) c.addView(tv("🏠 " + where, 14, TXT, false));
        c.addView(divider());
        c.addView(kv("Renta del mes", money(due)));
        c.addView(kv("Pagado", money(pd), GRN));
        c.addView(kv("Falta", money(owed), owed > 0.009 ? RED : GRN));
        c.addView(kv("Fecha de pago", Store.shortDate(Store.dueDate(t, m, this))));
        TextView chg = tv("✏️ Cambiar el monto solo para este mes", 13, PRI2, true);
        chg.setPadding(0, dp(8), 0, 0);
        chg.setOnClickListener(v -> {
            EditText e = input("Monto de " + Store.monthName(m), DEC);
            e.setText(qty(due));
            LinearLayout box = vbox();
            box.setPadding(dp(20), dp(4), dp(20), 0);
            box.addView(e);
            new AlertDialog.Builder(this).setTitle("Renta de " + Store.monthName(m)).setView(box)
                    .setPositiveButton("Guardar", (dlg, w) -> {
                        JSONObject rr = Store.rec(recs, tid, m, true);
                        Store.put(rr, "due", num(e.getText().toString()));
                        saveAll();
                        refresh();
                    })
                    .setNeutralButton("Usar la renta normal", (dlg, w) -> {
                        JSONObject rr = Store.rec(recs, tid, m, false);
                        if (rr != null) rr.remove("due");
                        saveAll();
                        refresh();
                    })
                    .setNegativeButton("Cancelar", null).show();
        });
        c.addView(chg);
        p.addView(c);

        JSONArray pays = r0 == null ? null : r0.optJSONArray("payments");
        if (pays != null && pays.length() > 0) {
            p.addView(sectionTitle("Pagos de " + Store.monthName(m).toLowerCase(Store.ES), null, null));
            LinearLayout pc = card();
            for (int i = 0; i < pays.length(); i++) {
                final JSONObject x = pays.optJSONObject(i);
                if (x == null) continue;
                if (pc.getChildCount() > 0) pc.addView(divider());
                LinearLayout row = hbox();
                if (!x.optString("img").isEmpty()) {
                    ImageView th = new ImageView(this);
                    th.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    th.setBackground(round(0xFFE1E7EF, 10));
                    th.setClipToOutline(true);
                    LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(dp(46), dp(46));
                    tl.setMargins(0, 0, dp(10), 0);
                    row.addView(th, tl);
                    loadThumb(th, Uri.parse(x.optString("img")));
                }
                LinearLayout tx = vbox();
                tx.addView(tv((x.optString("source").equals("auto") ? "📩 " : "💵 ") + money(x.optDouble("amount", 0)) + " · " + x.optString("method"), 15, TXT, true));
                tx.addView(tv(Store.dateTime(x.optLong("date")) + (x.optString("ref").isEmpty() ? "" : " · " + x.optString("ref")), 12, MUT, false));
                tx.addView(tv(x.optString("img").isEmpty() ? "📷 Toca para agregar el comprobante" : "🧾 Con comprobante · toca para verlo", 12,
                        x.optString("img").isEmpty() ? PRI2 : 0xFF15803D, true));
                row.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
                row.setOnClickListener(v -> payMenu(x));
                pc.addView(row);
            }
            p.addView(pc);
        }

        String key = tid + "|" + m;
        if (!key.equals(formKey)) {
            formKey = key;
            formAmt = null;
            formRef = "";
            formMethod = METHODS[0];
            formImg = "";
            formDate = System.currentTimeMillis();
        }
        p.addView(sectionTitle("💵 Registrar pago", null, null));
        LinearLayout f = card();
        EditText amt = input("Monto", DEC);
        amt.setText(formAmt != null ? formAmt : (owed > 0.009 ? qty(owed) : ""));
        final long[] date = {formDate};
        final String[] method = {formMethod};
        EditText ref = input("Referencia o nota (opcional)", InputType.TYPE_CLASS_TEXT);
        ref.setText(formRef);
        watch(amt, () -> formAmt = amt.getText().toString());
        watch(ref, () -> formRef = ref.getText().toString());
        f.addView(twoCols(labeled("Monto (" + Store.get(this, "cur", "$") + ")", amt), dateField(date)));
        f.addView(label("💳", "Forma de pago", false));
        LinearLayout mr = hbox();
        final TextView[] mc = new TextView[METHODS.length];
        for (int i = 0; i < METHODS.length; i++) {
            final int j = i;
            mc[i] = chip(METHODS[i], METHODS[i].equals(method[0]), v -> {
                method[0] = METHODS[j];
                formMethod = METHODS[j];
                for (int k = 0; k < mc.length; k++) styleChip(mc[k], k == j);
            });
            mr.addView(mc[i]);
        }
        f.addView(hscroll(mr));
        f.addView(ref);
        f.addView(label("🧾", "Comprobante (foto o captura del pago)", false));
        if (!formImg.isEmpty()) {
            LinearLayout ir = hbox();
            ImageView pv = new ImageView(this);
            pv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            pv.setBackground(round(0xFFE1E7EF, 12));
            pv.setClipToOutline(true);
            ir.addView(pv, new LinearLayout.LayoutParams(dp(90), dp(90)));
            loadThumb(pv, Uri.parse(formImg));
            pv.setOnClickListener(v -> viewImage(formImg));
            LinearLayout iv = vbox();
            iv.setPadding(dp(12), 0, 0, 0);
            iv.addView(tv("✅ Comprobante listo", 14, 0xFF15803D, true));
            TextView rm = tv("Quitar", 14, RED, true);
            rm.setPadding(0, dp(8), 0, 0);
            rm.setOnClickListener(v -> { formImg = ""; refresh(); });
            iv.addView(rm);
            ir.addView(iv, new LinearLayout.LayoutParams(0, -2, 1f));
            LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(-1, -2);
            il.setMargins(0, dp(6), 0, 0);
            f.addView(ir, il);
        } else {
            LinearLayout ib = hbox();
            ib.setPadding(0, dp(6), 0, 0);
            ib.addView(smallBtn("📷 Tomar foto", PRI2, v -> { pendingPayId = -1; formDate = date[0]; capture(); }), weightLp(1f));
            ib.addView(smallBtn("🖼️ De la galería", PRI2, v -> { pendingPayId = -1; formDate = date[0]; pickImage(); }), weightLp(1f));
            f.addView(ib);
        }
        p.addView(f);
        p.addView(button("💵  Guardar pago", GRN, v -> {
            double a = num(amt.getText().toString());
            if (a <= 0) { toast("Escribe el monto"); return; }
            JSONObject rr = Store.rec(recs, tid, m, true);
            JSONObject x = new JSONObject();
            Store.put(x, "id", Store.nextId(this));
            Store.put(x, "amount", a);
            Store.put(x, "date", date[0]);
            Store.put(x, "method", method[0]);
            Store.put(x, "source", "manual");
            Store.put(x, "ref", ref.getText().toString().trim());
            if (!formImg.isEmpty()) Store.put(x, "img", formImg);
            rr.optJSONArray("payments").put(x);
            formKey = "";
            saveAll();
            if (Store.due(t, rr) - Store.paid(rr) <= 0.009) Store.cancelPromise(this, tid);
            toast("Pago guardado ✅");
            refresh();
            if (Store.getB(this, "askMgr", true)) {
                final int pid = x.optInt("id");
                new AlertDialog.Builder(this).setTitle("👔 ¿Enviar este pago al " + mgrName() + "?")
                        .setMessage("Se abre WhatsApp con los datos del pago" + (x.optString("img").isEmpty() ? "." : " y el comprobante."))
                        .setPositiveButton("Enviar", (dlg, w) -> sendPayment(pid))
                        .setNegativeButton("Ahora no", null).show();
            }
        }));

        if (owed > 0.009) {
            p.addView(sectionTitle("📌 Seguimiento", null, null));
            LinearLayout sc = card();
            final String prom = r0 == null ? "" : r0.optString("promise");
            TextView pf = field(prom.isEmpty() ? "📅  ¿Cuándo dijo que pagará?" : "🤝  Pagará el " + Store.shortDate(prom) + "  (tocar para cambiar)");
            pf.setOnClickListener(v -> pickDate(prom.isEmpty() ? Store.today() : prom, iso -> {
                JSONObject rr = Store.rec(recs, tid, m, true);
                Store.put(rr, "promise", iso);
                saveAll();
                Store.schedulePromise(this, t, rr);
                toast("Te aviso ese día a las 9 AM 🔔");
                refresh();
            }));
            sc.addView(labeled("Fecha prometida", pf));
            if (!prom.isEmpty()) {
                TextView clr = tv("Quitar fecha prometida", 13, RED, true);
                clr.setPadding(0, dp(6), 0, 0);
                clr.setOnClickListener(v -> {
                    Store.put(r0, "promise", "");
                    Store.cancelPromise(this, tid);
                    saveAll();
                    refresh();
                });
                sc.addView(clr);
            }
            EditText notes = input("Notas del seguimiento (ej. pagará en dos partes)", TXT_MULTI);
            notes.setText(r0 == null ? "" : r0.optString("notes"));
            sc.addView(label("📝", "Notas de este mes", false));
            sc.addView(notes);
            TextView sv = tv("Guardar notas", 14, PRI2, true);
            sv.setPadding(0, dp(8), 0, 0);
            sv.setOnClickListener(v -> {
                JSONObject rr = Store.rec(recs, tid, m, true);
                Store.put(rr, "notes", notes.getText().toString().trim());
                saveAll();
                toast("Notas guardadas");
            });
            sc.addView(sv);
            p.addView(sc);
            LinearLayout b2 = hbox();
            b2.setPadding(dp(8), dp(6), dp(8), 0);
            final String phone = t.optString("phone");
            b2.addView(outline("💬  Recordar por WhatsApp", GRN, v -> {
                if (phone.replaceAll("[^0-9]", "").isEmpty()) { toast("Agrega el teléfono del inquilino"); return; }
                launch(Store.waIntent(this, phone, Store.reminderText(this, t, m, owed)));
            }), weightLp(1.4f));
            b2.addView(outline("📞  Llamar", PRI2, v -> {
                if (phone.isEmpty()) { toast("Agrega el teléfono del inquilino"); return; }
                launch(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone)));
            }), weightLp(1f));
            p.addView(b2);
        }
        TextView ficha = tv("👤  Ver ficha e historial del inquilino ›", 14, PRI2, true);
        ficha.setPadding(dp(18), dp(18), dp(18), 0);
        ficha.setOnClickListener(v -> open(() -> tenantDetail(tid)));
        p.addView(ficha);
        show(scroll(p), false, null, null);
    }

    // ============================ manager ============================
    String mgrName() { return Store.get(this, "mgrName", "Manager"); }

    void sendToManager(String text, Uri file, String mime) {
        String phone = Store.get(this, "mgrPhone", "+16047678650");
        String d = phone.replaceAll("[^0-9]", "");
        if (d.length() == 10) d = "1" + d;
        if (d.isEmpty()) { toast("Agrega el WhatsApp del manager en Más → Ajustes"); return; }
        String pref = Store.get(this, "waApp", "business").equals("business") ? "com.whatsapp.w4b" : "com.whatsapp";
        String pkg = Store.installed(this, pref) ? pref : Store.installed(this, "com.whatsapp") ? "com.whatsapp" : Store.installed(this, "com.whatsapp.w4b") ? "com.whatsapp.w4b" : null;
        if (pkg != null) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setPackage(pkg);
            i.putExtra("jid", d + "@s.whatsapp.net");
            i.putExtra(Intent.EXTRA_TEXT, text);
            if (file != null) {
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, file);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } else i.setType("text/plain");
            try { startActivity(i); return; } catch (Exception ignored) { }
        }
        if (file != null) toast("Se envía solo el texto. Comparte el archivo aparte.");
        launch(Store.waIntent(this, phone, text));
    }

    void sendPayment(int pid) {
        JSONObject x = findPayment(pid);
        JSONObject r = recOfPayment(pid);
        if (x == null || r == null) { toast("No encontré el pago"); return; }
        JSONObject t = Store.tenant(tenants, r.optInt("tid"));
        if (t == null) { toast("No encontré el inquilino"); return; }
        String m = r.optString("month");
        double due = Store.due(t, r), pd = Store.paid(r), owed = due - pd;
        StringBuilder b = new StringBuilder("💵 *Pago recibido*\n");
        b.append("👤 ").append(t.optString("name")).append("\n");
        if (!where(t).isEmpty()) b.append("🏠 ").append(where(t)).append("\n");
        b.append("💲 ").append(money(x.optDouble("amount", 0))).append(" · ").append(x.optString("method"))
                .append(x.optString("source").equals("auto") ? " (automático)" : "").append("\n");
        b.append("📅 ").append(Store.dateTime(x.optLong("date"))).append("\n");
        b.append("🗓️ Renta de ").append(Store.monthName(m).toLowerCase(Store.ES)).append(": pagado ").append(money(pd))
                .append(" de ").append(money(due)).append(owed <= 0.009 ? " ✅ completo" : " · falta " + money(owed)).append("\n");
        if (!x.optString("ref").isEmpty()) b.append("📝 ").append(x.optString("ref")).append("\n");
        boolean img = !x.optString("img").isEmpty();
        if (img) b.append("🧾 Comprobante adjunto\n");
        b.append("\n— Rentas Amigo Renta");
        sendToManager(b.toString(), img ? Uri.parse(x.optString("img")) : null, "image/*");
    }

    String tenantText(JSONObject t) {
        int tid = t.optInt("id");
        StringBuilder b = new StringBuilder("👤 *").append(t.optString("name")).append("*\n");
        if (!where(t).isEmpty()) b.append("🏠 ").append(where(t)).append("\n");
        b.append("💲 Renta: ").append(money(t.optDouble("rent", 0))).append(" · paga el día ").append(t.optInt("dueDay", Store.getI(this, "dueDay", 1))).append("\n");
        if (!t.optString("phone").isEmpty()) b.append("📞 ").append(t.optString("phone")).append("\n");
        if (t.optDouble("deposit", 0) > 0)
            b.append("🔐 Depósito: ").append(money(t.optDouble("deposit", 0))).append(t.optBoolean("depPaid") ? " (recibido)" : " (pendiente)").append("\n");
        b.append("\n*Últimos meses:*\n");
        double debt = 0;
        String cm = Store.thisMonth();
        for (int i = 0; i < 4; i++) {
            String mm = Store.addMonth(cm, -i);
            if (!Store.activeIn(t, mm)) continue;
            JSONObject r = Store.rec(recs, tid, mm, false);
            int st = status(t, mm);
            double owed = Store.due(t, r) - Store.paid(r);
            if (st != 0 && i > 0) debt += Math.max(0, owed);
            b.append(ST_ICON[st]).append(" ").append(Store.monthName(mm)).append(": ")
                    .append(st == 0 ? "pagado " + money(Store.paid(r)) : "falta " + money(owed));
            if (r != null && !r.optString("promise").isEmpty() && st != 0) b.append(" (prometió el ").append(Store.shortDate(r.optString("promise"))).append(")");
            b.append("\n");
        }
        if (debt > 0.009) b.append("\n⚠️ Debe de meses anteriores: ").append(money(debt)).append("\n");
        b.append("\n— Rentas Amigo Renta");
        return b.toString();
    }

    String monthText(String m) {
        List<JSONObject> act = activeTenants(m);
        Collections.sort(act, (x, y) -> where(x).compareToIgnoreCase(where(y)));
        double exp = 0, got = 0;
        StringBuilder paid = new StringBuilder(), owe = new StringBuilder();
        int np = 0, no = 0;
        for (JSONObject t : act) {
            JSONObject r = Store.rec(recs, t.optInt("id"), m, false);
            double due = Store.due(t, r), pd = Store.paid(r);
            exp += due;
            got += Math.min(pd, due);
            int st = status(t, m);
            String line = "• " + t.optString("name") + (room(t).isEmpty() ? "" : " – " + room(t));
            if (st == 0) { np++; paid.append(line).append(" – ").append(money(pd)).append("\n"); }
            else {
                no++;
                owe.append(ST_ICON[st]).append(" ").append(t.optString("name")).append(room(t).isEmpty() ? "" : " – " + room(t))
                        .append(" – falta ").append(money(due - pd));
                if (r != null && !r.optString("promise").isEmpty()) owe.append(" (prometió el ").append(Store.shortDate(r.optString("promise"))).append(")");
                owe.append("\n");
            }
        }
        StringBuilder b = new StringBuilder("📊 *Rentas · ").append(Store.monthName(m)).append("*\n");
        if (!propFilter.isEmpty()) b.append("🏠 ").append(propFilter).append("\n");
        b.append("Esperado: ").append(money(exp)).append("\nCobrado: ").append(money(got))
                .append("\nFalta: ").append(money(exp - got)).append(exp > 0 ? " (" + Math.round(got * 100 / exp) + "% cobrado)" : "").append("\n");
        if (no > 0) b.append("\n*Faltan por pagar (").append(no).append("):*\n").append(owe);
        if (np > 0) b.append("\n*Pagados (").append(np).append("):*\n").append(paid);
        b.append("\n— Rentas Amigo Renta · ").append(Store.dateTime(System.currentTimeMillis()));
        return b.toString();
    }

    void managerMenu() {
        final String m = month;
        String[] items = {"📝 Resumen de " + Store.monthName(m) + " (texto)", "📊 Reporte de Excel de " + Store.monthName(m),
                "🔴 Solo los que faltan por pagar", "📅 Cambiar de mes en la pestaña Mes"};
        new AlertDialog.Builder(this).setTitle("👔 Enviar al " + mgrName()).setItems(items, (dlg, w) -> {
            if (w == 0) sendToManager(monthText(m), null, null);
            else if (w == 1) {
                Uri u = saveReportUri(m);
                if (u == null) { toast("No se pudo crear el Excel"); return; }
                sendToManager("📊 Reporte de rentas · " + Store.monthName(m) + "\n\n" + monthText(m).split("\\n\\*Faltan|\\n\\*Pagados")[0],
                        u, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            } else if (w == 2) {
                String full = monthText(m);
                int a = full.indexOf("*Faltan por pagar");
                int b = full.indexOf("\n*Pagados");
                String part = a < 0 ? "✅ Todos pagaron " + Store.monthName(m).toLowerCase(Store.ES) : full.substring(a, b > a ? b : full.indexOf("\n— Rentas"));
                sendToManager("🔴 *Pendientes · " + Store.monthName(m) + "*\n\n" + part + "\n\n— Rentas Amigo Renta", null, null);
            } else openTab(0);
        }).show();
    }

    // ============================ comprobantes ============================
    JSONObject findPayment(int pid) {
        for (JSONObject r : recs) {
            JSONArray p = r.optJSONArray("payments");
            if (p == null) continue;
            for (int i = 0; i < p.length(); i++) { JSONObject x = p.optJSONObject(i); if (x != null && x.optInt("id") == pid) return x; }
        }
        return null;
    }

    JSONObject recOfPayment(int pid) {
        for (JSONObject r : recs) {
            JSONArray p = r.optJSONArray("payments");
            if (p == null) continue;
            for (int i = 0; i < p.length(); i++) { JSONObject x = p.optJSONObject(i); if (x != null && x.optInt("id") == pid) return r; }
        }
        return null;
    }

    void payMenu(JSONObject x) {
        boolean has = !x.optString("img").isEmpty();
        List<String> o = new ArrayList<>();
        o.add("👔 Enviar al " + mgrName());
        if (has) { o.add("🧾 Ver comprobante"); o.add("📤 Compartir comprobante"); }
        o.add(has ? "📷 Cambiar: tomar foto" : "📷 Agregar: tomar foto");
        o.add(has ? "🖼️ Cambiar: elegir de la galería" : "🖼️ Agregar: elegir de la galería");
        if (has) o.add("❌ Quitar comprobante");
        o.add("🗑️ Eliminar este pago");
        new AlertDialog.Builder(this).setTitle(money(x.optDouble("amount", 0)) + " · " + Store.dateTime(x.optLong("date")))
                .setItems(o.toArray(new String[0]), (dlg, w) -> {
                    String s = o.get(w);
                    if (s.startsWith("👔")) sendPayment(x.optInt("id"));
                    else if (s.startsWith("🧾")) viewImage(x.optString("img"));
                    else if (s.startsWith("📤")) {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("image/*");
                        i.putExtra(Intent.EXTRA_STREAM, Uri.parse(x.optString("img")));
                        i.putExtra(Intent.EXTRA_TEXT, "Comprobante de pago · " + money(x.optDouble("amount", 0)) + " · " + Store.dateTime(x.optLong("date")));
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        launch(Intent.createChooser(i, "Compartir comprobante"));
                    } else if (s.startsWith("📷")) { pendingPayId = x.optInt("id"); capture(); }
                    else if (s.startsWith("🖼️")) { pendingPayId = x.optInt("id"); pickImage(); }
                    else if (s.startsWith("❌")) { x.remove("img"); saveAll(); refresh(); }
                    else deletePayment(x);
                }).show();
    }

    void deletePayment(JSONObject x) {
        new AlertDialog.Builder(this).setTitle("¿Eliminar este pago?")
                .setPositiveButton("Eliminar", (dlg, w) -> {
                    JSONObject r = recOfPayment(x.optInt("id"));
                    if (r != null) {
                        JSONArray pays = r.optJSONArray("payments");
                        JSONArray na = new JSONArray();
                        for (int j = 0; j < pays.length(); j++) { JSONObject y = pays.optJSONObject(j); if (y != null && y.optInt("id") != x.optInt("id")) na.put(y); }
                        Store.put(r, "payments", na);
                    }
                    int did = x.optInt("detId", -1);
                    for (JSONObject d : detected) if (d.optInt("id") == did) { Store.put(d, "status", "pendiente"); d.remove("month"); }
                    saveAll();
                    refresh();
                }).setNegativeButton("Cancelar", null).show();
    }

    void viewImage(String uri) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(Uri.parse(uri), "image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        launch(i);
    }

    void capture() {
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 9);
            toast("Acepta el permiso y vuelve a intentarlo");
            return;
        }
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "comprobante_" + System.currentTimeMillis() + ".jpg");
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
        if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Amigo Renta Comprobantes");
        Uri u = null;
        try { u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv); } catch (Exception e) { }
        if (u == null) { toast("No se pudo preparar la cámara"); return; }
        pendingCap = u;
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT, u);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(i, REQ_PHOTO); } catch (Exception e) { toast("No hay app de cámara"); }
    }

    void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        try { startActivityForResult(i, REQ_PICK); } catch (Exception e) { toast("No se pudo abrir la galería"); }
    }

    void setImage(String uri) {
        if (pendingPayId >= 0) {
            JSONObject x = findPayment(pendingPayId);
            if (x != null) { Store.put(x, "img", uri); saveAll(); toast("Comprobante guardado 🧾"); }
        } else {
            formImg = uri;
            toast("Comprobante agregado. Ahora toca «Guardar pago».");
        }
        pendingPayId = -1;
    }

    void loadThumb(ImageView iv, Uri u) {
        new Thread(() -> {
            Bitmap b = null;
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
                int sz = 1;
                while (o.outWidth / (sz * 2) >= 200 && o.outHeight / (sz * 2) >= 200) sz *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = sz;
                try (InputStream in = getContentResolver().openInputStream(u)) { b = BitmapFactory.decodeStream(in, null, o2); }
                int rot = 0;
                try (InputStream in = getContentResolver().openInputStream(u)) {
                    int ori = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    rot = ori == ExifInterface.ORIENTATION_ROTATE_90 ? 90 : ori == ExifInterface.ORIENTATION_ROTATE_180 ? 180 : ori == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
                } catch (Exception e) { }
                if (b != null && rot != 0) {
                    Matrix mx = new Matrix();
                    mx.postRotate(rot);
                    b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), mx, true);
                }
            } catch (Exception e) { b = null; }
            final Bitmap fb = b;
            runOnUiThread(() -> { if (fb != null) iv.setImageBitmap(fb); });
        }).start();
    }

    void watch(EditText e, Runnable r) {
        e.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable ed) { r.run(); }
        });
    }

    TextView smallBtn(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 13, color, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundStroke(Color.WHITE, 12, color));
        b.setPadding(dp(6), dp(11), dp(6), dp(11));
        b.setMaxLines(1);
        b.setOnClickListener(l);
        return b;
    }

    // ============================ inquilinos ============================
    void tenantsScreen() {
        int act = 0;
        for (JSONObject t : tenants) if (!t.optBoolean("inactive")) act++;
        setHeader("Inquilinos", act + " activos", "👥", false);
        LinearLayout p = vbox();
        EditText s = input("🔍  Buscar por nombre, propiedad o cuarto", InputType.TYPE_CLASS_TEXT);
        s.setText(tSearch);
        ((LinearLayout.LayoutParams) s.getLayoutParams()).setMargins(dp(14), dp(10), dp(14), dp(4));
        p.addView(s);
        final LinearLayout list = vbox();
        p.addView(list);
        final Runnable fillList = () -> {
            list.removeAllViews();
            String q = Store.norm(tSearch);
            List<JSONObject> l = new ArrayList<>();
            for (JSONObject t : tenants)
                if (q.isEmpty() || Store.norm(t.optString("name") + " " + t.optString("property") + " " + t.optString("unit") + " " + t.optString("aliases")).contains(q)) l.add(t);
            Collections.sort(l, (x, y) -> {
                if (x.optBoolean("inactive") != y.optBoolean("inactive")) return x.optBoolean("inactive") ? 1 : -1;
                return (x.optString("property") + x.optString("unit") + x.optString("name")).compareToIgnoreCase(y.optString("property") + y.optString("unit") + y.optString("name"));
            });
            if (tenants.isEmpty()) list.addView(empty("Todavía no hay inquilinos.\nToca «＋ Inquilino» o pega tu lista en Más → Importar lista."));
            for (JSONObject t : l) {
                LinearLayout c = card();
                c.setOrientation(LinearLayout.HORIZONTAL);
                c.setGravity(Gravity.CENTER_VERTICAL);
                LinearLayout v = vbox();
                v.addView(tv(t.optString("name") + (t.optBoolean("inactive") ? "  (ya no vive)" : ""), 16, t.optBoolean("inactive") ? MUT : TXT, true));
                String where = where(t);
                if (!where.isEmpty()) v.addView(tv(where, 13, MUT, false));
                v.addView(tv("Paga el día " + t.optInt("dueDay", Store.getI(this, "dueDay", 1)) + (t.optString("phone").isEmpty() ? "" : " · 📞 " + t.optString("phone")), 12, MUT, false));
                if (t.optDouble("deposit", 0) > 0)
                    v.addView(tv("🔐 Depósito " + money(t.optDouble("deposit", 0)) + (t.optBoolean("depPaid") ? " ✅" : " ⏳ pendiente"),
                            12, t.optBoolean("depPaid") ? 0xFF15803D : YEL, true));
                c.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
                c.addView(tv(money(t.optDouble("rent", 0)), 16, TXT, true));
                final int id = t.optInt("id");
                c.setOnClickListener(x -> open(() -> tenantDetail(id)));
                list.addView(c);
            }
        };
        s.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable e) { tSearch = e.toString(); fillList.run(); }
        });
        fillList.run();
        show(scroll(p), true, "＋  Inquilino", () -> open(() -> tenantForm(-1)));
    }

    void tenantDetail(int tid) {
        final JSONObject t = Store.tenant(tenants, tid);
        if (t == null) { goBack(); return; }
        setHeader(t.optString("name"), where(t), null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.addView(kv("Renta mensual", money(t.optDouble("rent", 0))));
        c.addView(kv("Paga el día", String.valueOf(t.optInt("dueDay", Store.getI(this, "dueDay", 1)))));
        if (!t.optString("phone").isEmpty()) c.addView(kv("Teléfono", t.optString("phone")));
        if (!t.optString("email").isEmpty()) c.addView(kv("Correo", t.optString("email")));
        if (!t.optString("aliases").isEmpty()) c.addView(kv("Nombre en e-Transfer", t.optString("aliases")));
        if (!t.optString("since").isEmpty()) c.addView(kv("Desde", Store.monthName(t.optString("since"))));
        double dp0 = t.optDouble("deposit", 0);
        if (dp0 > 0) {
            c.addView(divider());
            c.addView(kv("🔐 Depósito", money(dp0)));
            c.addView(kv("Estado", t.optBoolean("depPaid")
                    ? "✅ Recibido" + (t.optLong("depDate") > 0 ? " el " + Store.shortDate(Store.dayOf(t.optLong("depDate"))) : "")
                    : "⏳ Pendiente", t.optBoolean("depPaid") ? GRN : YEL));
            if (t.optDouble("depReturned", 0) > 0) c.addView(kv("Devuelto", money(t.optDouble("depReturned", 0)), PRI2));
        } else {
            c.addView(kv("🔐 Depósito", "No registrado", MUT));
        }
        if (t.optBoolean("inactive")) c.addView(kv("Ya no vive desde", Store.monthName(Store.addMonth(t.optString("until"), 1)), RED));
        if (!t.optString("notes").isEmpty()) { c.addView(divider()); c.addView(tv("📝 " + t.optString("notes"), 14, TXT, false)); }
        p.addView(c);

        p.addView(sectionTitle("Historial (12 meses)", null, null));
        LinearLayout h = card();
        String m = Store.thisMonth();
        int shown = 0;
        double debt = 0;
        for (int i = 0; i < 12; i++) {
            String mm = Store.addMonth(m, -i);
            if (!Store.activeIn(t, mm)) continue;
            JSONObject r = Store.rec(recs, tid, mm, false);
            int st = status(t, mm);
            double owed = Store.due(t, r) - Store.paid(r);
            if (st == 3) debt += Math.max(0, owed);
            if (h.getChildCount() > 0) h.addView(divider());
            LinearLayout row = hbox();
            row.addView(tv(ST_ICON[st] + "  " + Store.monthName(mm), 14, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
            row.addView(tv(st == 0 ? money(Store.paid(r)) : "falta " + money(owed), 14, ST_COL[st][0], true));
            final String fm = mm;
            row.setOnClickListener(x -> open(() -> payScreen(tid, fm)));
            h.addView(row);
            shown++;
        }
        if (shown == 0) h.addView(tv("Sin meses registrados", 14, MUT, false));
        p.addView(h);
        if (debt > 0.009) {
            TextView d = tv("⚠️ Debe en total " + money(debt) + " de meses anteriores", 15, RED, true);
            d.setPadding(dp(18), dp(8), dp(18), 0);
            p.addView(d);
        }
        LinearLayout b = hbox();
        b.setPadding(dp(8), dp(12), dp(8), 0);
        final String phone = t.optString("phone");
        b.addView(outline("💬  WhatsApp", GRN, v -> { if (!phone.isEmpty()) launch(Store.waIntent(this, phone, "")); else toast("Sin teléfono"); }), weightLp(1f));
        b.addView(outline("✏️  Editar", PRI2, v -> open(() -> tenantForm(tid))), weightLp(1f));
        p.addView(b);
        p.addView(button("👔  Enviar información al " + mgrName(), PRI2, v -> sendToManager(tenantText(t), null, null)));
        show(scroll(p), false, null, null);
    }

    void tenantForm(int tid) {
        final JSONObject old = tid < 0 ? null : Store.tenant(tenants, tid);
        setHeader(old == null ? "Nuevo inquilino" : "Editar inquilino", null, null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        EditText name = input("Nombre completo", TXT_CAP);
        EditText aliases = input("Ej. JUAN PEREZ, MARIA LOPEZ", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        EditText phone = input("Ej. +1 604 555 1111", InputType.TYPE_CLASS_PHONE);
        EditText email = input("Correo (opcional)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText prop = input("Ej. 801 E Broadway, Vancouver", TXT_CAP);
        EditText unit = input("Ej. 3", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        EditText rent = input("Renta mensual", DEC);
        EditText day = input("1", InputType.TYPE_CLASS_NUMBER);
        EditText notes = input("Notas (opcional)", TXT_MULTI);
        EditText dep = input("Ej. 475", DEC);
        EditText depRet = input("0", DEC);
        final long[] depDate = {old != null && old.optLong("depDate") > 0 ? old.optLong("depDate") : System.currentTimeMillis()};
        Switch depPaid = new Switch(this);
        depPaid.setText("✅  Ya entregó el depósito");
        depPaid.setTextSize(15);
        depPaid.setTextColor(TXT);
        depPaid.setPadding(0, dp(12), 0, dp(4));
        final String[] since = {old != null && !old.optString("since").isEmpty() ? old.optString("since") : Store.thisMonth()};
        final TextView sinceF = field("📅  " + Store.monthName(since[0]));
        sinceF.setOnClickListener(v -> pickDate(since[0] + "-01", iso -> { since[0] = iso.substring(0, 7); sinceF.setText("📅  " + Store.monthName(since[0])); }));
        Switch active = new Switch(this);
        active.setText("✅  Vive actualmente (se incluye cada mes)");
        active.setTextSize(15);
        active.setTextColor(TXT);
        active.setPadding(0, dp(14), 0, dp(4));
        active.setChecked(old == null || !old.optBoolean("inactive"));
        if (old != null) {
            name.setText(old.optString("name"));
            aliases.setText(old.optString("aliases"));
            phone.setText(old.optString("phone"));
            email.setText(old.optString("email"));
            prop.setText(old.optString("property"));
            unit.setText(old.optString("unit"));
            rent.setText(qty(old.optDouble("rent", 0)));
            day.setText(String.valueOf(old.optInt("dueDay", Store.getI(this, "dueDay", 1))));
            notes.setText(old.optString("notes"));
            if (old.optDouble("deposit", 0) > 0) dep.setText(qty(old.optDouble("deposit", 0)));
            if (old.optDouble("depReturned", 0) > 0) depRet.setText(qty(old.optDouble("depReturned", 0)));
            depPaid.setChecked(old.optBoolean("depPaid"));
        } else day.setText(String.valueOf(Store.getI(this, "dueDay", 1)));
        c.addView(label("👤", "Nombre del inquilino", true));
        c.addView(name);
        c.addView(label("📩", "Nombre como aparece en el e-Transfer", false));
        c.addView(aliases);
        c.addView(tv("Si paga otra persona o el banco usa otro nombre, escríbelo aquí (varios separados por coma).", 12, MUT, false));
        p.addView(c);
        LinearLayout pc = card();
        pc.addView(tv("🏠  ¿Qué renta?", 16, TXT, true));
        pc.addView(label("🏠", "Propiedad", true));
        pc.addView(prop);
        List<String> props = properties();
        if (!props.isEmpty()) {
            LinearLayout chipsP = hbox();
            for (String pr : props) chipsP.addView(chip(pr, false, x -> prop.setText(pr)));
            pc.addView(hscroll(chipsP));
        }
        pc.addView(twoCols(labeled("Número de cuarto", unit), labeled("Renta mensual (" + Store.get(this, "cur", "$") + ")", rent)));
        final TextView roomInfo = tv("", 13, YEL, true);
        roomInfo.setPadding(0, dp(6), 0, 0);
        pc.addView(roomInfo);
        Runnable checkRoom = () -> {
            JSONObject other = roomTaken(prop.getText().toString(), unit.getText().toString(), tid);
            roomInfo.setText(other == null ? "" : "⚠️ En ese cuarto ya está " + other.optString("name"));
        };
        TextWatcher tw = new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable e) { checkRoom.run(); }
        };
        prop.addTextChangedListener(tw);
        unit.addTextChangedListener(tw);
        p.addView(pc);
        c = card();
        c.addView(twoCols(labeled("Paga el día", day), labeled("Desde el mes", sinceF)));
        c.addView(label("📞", "Teléfono / WhatsApp", false));
        c.addView(phone);
        c.addView(label("📧", "Correo", false));
        c.addView(email);
        p.addView(c);
        LinearLayout dc = card();
        dc.addView(tv("🔐  Depósito", 16, TXT, true));
        dc.addView(twoCols(labeled("Monto del depósito (" + Store.get(this, "cur", "$") + ")", dep), dateField(depDate)));
        dc.addView(depPaid);
        dc.addView(labeled("Depósito devuelto al mudarse (" + Store.get(this, "cur", "$") + ")", depRet));
        dc.addView(tv("Llénalo solo cuando se le devuelva todo o parte del depósito.", 12, MUT, false));
        p.addView(dc);
        LinearLayout c2 = card();
        c2.addView(active);
        c2.addView(label("📝", "Notas", false));
        c2.addView(notes);
        p.addView(c2);
        final Runnable[] doSave = new Runnable[1];
        p.addView(button("Guardar inquilino", PRI2, v -> {
            String n = name.getText().toString().trim();
            double rn = num(rent.getText().toString());
            if (n.isEmpty()) { toast("Escribe el nombre"); return; }
            if (prop.getText().toString().trim().isEmpty()) { toast("Escribe la propiedad"); return; }
            if (unit.getText().toString().trim().isEmpty()) { toast("Escribe el número de cuarto"); return; }
            if (rn <= 0) { toast("Escribe la renta mensual"); return; }
            JSONObject other = active.isChecked() ? roomTaken(prop.getText().toString(), unit.getText().toString(), tid) : null;
            if (other != null) {
                new AlertDialog.Builder(this).setTitle("Cuarto ocupado")
                        .setMessage("En " + where(other) + " ya está " + other.optString("name") + ". ¿Guardar de todas formas? (por ejemplo, si comparten el cuarto)")
                        .setPositiveButton("Guardar", (dlg, w) -> doSave[0].run())
                        .setNegativeButton("Revisar", null).show();
            } else doSave[0].run();
        }));
        doSave[0] = () -> {
            String n = name.getText().toString().trim();
            double rn = num(rent.getText().toString());
            JSONObject o = old != null ? old : new JSONObject();
            if (old == null) Store.put(o, "id", Store.nextId(this));
            Store.put(o, "name", n);
            Store.put(o, "aliases", aliases.getText().toString().trim());
            Store.put(o, "phone", phone.getText().toString().trim());
            Store.put(o, "email", email.getText().toString().trim());
            Store.put(o, "property", prop.getText().toString().trim());
            Store.put(o, "unit", unit.getText().toString().trim());
            Store.put(o, "rent", rn);
            int d = (int) num(day.getText().toString());
            Store.put(o, "dueDay", d < 1 || d > 31 ? 1 : d);
            Store.put(o, "since", since[0]);
            Store.put(o, "notes", notes.getText().toString().trim());
            Store.put(o, "deposit", num(dep.getText().toString()));
            Store.put(o, "depPaid", depPaid.isChecked());
            Store.put(o, "depDate", depPaid.isChecked() ? depDate[0] : 0);
            Store.put(o, "depReturned", num(depRet.getText().toString()));
            boolean wasInactive = o.optBoolean("inactive");
            if (!active.isChecked()) {
                if (!wasInactive) Store.put(o, "until", Store.thisMonth());
                Store.put(o, "inactive", true);
            } else { Store.put(o, "inactive", false); o.remove("until"); }
            if (old == null) tenants.add(o);
            saveAll();
            toast("Inquilino guardado ✅");
            goBack();
        };
        if (old != null) {
            p.addView(button("🗑️  Eliminar inquilino", RED, v -> new AlertDialog.Builder(this)
                    .setTitle("Eliminar a " + old.optString("name"))
                    .setMessage("Se borra con todo su historial de pagos. Si solo se mudó, mejor desmarca «Vive actualmente».")
                    .setPositiveButton("Eliminar", (dlg, w) -> {
                        tenants.remove(old);
                        for (int i = recs.size() - 1; i >= 0; i--) if (recs.get(i).optInt("tid") == tid) recs.remove(i);
                        Store.cancelPromise(this, tid);
                        saveAll();
                        openTab(1);
                    }).setNegativeButton("Cancelar", null).show()));
        }
        show(scroll(p), false, null, null);
    }

    // ============================ e-Transfers ============================
    boolean listenerOn() {
        String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(new ComponentName(this, PagosListener.class).flattenToString());
    }

    void etScreen() {
        int pend = 0;
        for (JSONObject d : detected) if (d.optString("status").equals("pendiente")) pend++;
        setHeader("e-Transfers recibidos", pend + " por asignar", "📩", false);
        LinearLayout p = vbox();
        boolean on = listenerOn();
        LinearLayout c = card();
        c.setBackground(round(on ? 0xFFE3F6E8 : 0xFFFDE6E6, 16));
        c.addView(tv(on ? "🟢  Lectura automática ACTIVA" : "🔴  Lectura automática desactivada", 17, on ? 0xFF15803D : 0xFFB91C1C, true));
        c.addView(tv(on
                ? "Cuando llegue al correo de este teléfono un aviso de INTERAC e-Transfer, la app lo lee, busca al inquilino y marca el pago."
                : "Actívala para que la app lea los avisos de INTERAC e-Transfer que llegan al correo de este teléfono.", 14, TXT, false));
        if (!on) {
            c.addView(tv("\nPasos:\n1. Toca «Activar» y busca «Rentas Amigo Renta» → actívalo.\n2. Si sale «Ajuste restringido»: ve a Ajustes → Aplicaciones → Rentas Amigo Renta → ⋮ (arriba) → «Permitir ajustes restringidos», y vuelve a intentar.\n3. En la app de correo (Outlook/Gmail) deja activadas las notificaciones de la cuenta donde llegan los e-Transfers.", 13, TXT, false));
            TextView bt = button("Activar", RED, v -> {
                try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
                catch (Exception e) { toast("Abre Ajustes → Notificaciones → Acceso a notificaciones"); }
            });
            ((LinearLayout.LayoutParams) bt.getLayoutParams()).setMargins(0, dp(12), 0, 0);
            c.addView(bt);
        }
        p.addView(c);

        LinearLayout opts = card();
        Switch auto = new Switch(this);
        auto.setText("Marcar el pago automáticamente cuando el nombre coincide");
        auto.setTextSize(14);
        auto.setTextColor(TXT);
        auto.setChecked(Store.getB(this, "autoApply", true));
        auto.setOnCheckedChangeListener((bv, ck) -> Store.putB(this, "autoApply", ck));
        opts.addView(auto);
        p.addView(opts);

        p.addView(button("📋  Pegar el texto de un e-Transfer", PRI2, v -> pasteDialog()));

        p.addView(sectionTitle("Recibidos", null, null));
        List<JSONObject> l = new ArrayList<>(detected);
        Collections.sort(l, (x, y) -> Long.compare(y.optLong("at"), x.optLong("at")));
        if (l.isEmpty()) p.addView(empty("Todavía no ha llegado ningún aviso de e-Transfer"));
        for (int i = 0; i < l.size() && i < 200; i++) p.addView(detRow(l.get(i)));
        show(scroll(p), true, null, null);
    }

    View detRow(JSONObject d) {
        String stt = d.optString("status");
        JSONObject t = d.has("tid") ? Store.tenant(tenants, d.optInt("tid")) : null;
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        boolean ok = stt.equals("aplicado"), ign = stt.equals("ignorado");
        TextView ic = tv(ok ? "✅" : ign ? "🚫" : "❓", 20, TXT, false);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(round(ok ? 0xFFE3F6E8 : ign ? 0xFFEEF0F3 : 0xFFFFF1DB, 12));
        c.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout v = vbox();
        v.setPadding(dp(12), 0, dp(6), 0);
        v.addView(tv(d.optString("name").isEmpty() ? "Nombre no visible" : d.optString("name"), 15, TXT, true));
        v.addView(tv(Store.dateTime(d.optLong("at")) + (d.optString("source").equals("manual") ? " · pegado" : ""), 12, MUT, false));
        String line = ok ? "Aplicado a " + (t != null ? t.optString("name") : "inquilino") + " · " + Store.monthName(d.optString("month"))
                : ign ? "Ignorado" : (t != null ? "¿Es de " + t.optString("name") + "? Toca para confirmar" : "Toca para asignarlo a un inquilino");
        v.addView(tv(line, 13, ok ? 0xFF15803D : ign ? MUT : YEL, true));
        c.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(tv(d.optDouble("amount", 0) > 0 ? money(d.optDouble("amount", 0)) : "—", 15, TXT, true));
        c.setOnClickListener(x -> detMenu(d));
        return c;
    }

    void detMenu(JSONObject d) {
        String stt = d.optString("status");
        List<String> o = new ArrayList<>();
        JSONObject sug = d.has("tid") ? Store.tenant(tenants, d.optInt("tid")) : null;
        if (!stt.equals("aplicado")) {
            if (sug != null) o.add("✅ Confirmar: es de " + sug.optString("name"));
            o.add("👤 Asignar a un inquilino…");
            if (!stt.equals("ignorado")) o.add("🚫 Ignorar (no es de renta)");
        } else {
            o.add("👔 Enviar al " + mgrName());
            o.add("↩️ Deshacer (quitar el pago)");
        }
        o.add("📄 Ver texto del aviso");
        new AlertDialog.Builder(this).setTitle((d.optString("name").isEmpty() ? "e-Transfer" : d.optString("name")) + (d.optDouble("amount", 0) > 0 ? " · " + money(d.optDouble("amount", 0)) : ""))
                .setItems(o.toArray(new String[0]), (dlg, w) -> {
                    String s = o.get(w);
                    if (s.startsWith("✅")) { applyTo(d, sug, false); }
                    else if (s.startsWith("👤")) {
                        pickTenant(Store.month(d.optLong("at")), id -> {
                            JSONObject t = Store.tenant(tenants, Integer.parseInt(id));
                            if (t == null) return;
                            String nm = d.optString("name");
                            boolean known = Store.match(Collections.singletonList(t), nm, 0) != null;
                            if (!nm.isEmpty() && !known) {
                                new AlertDialog.Builder(this).setTitle("¿Recordar este nombre?")
                                        .setMessage("La próxima vez que llegue un e-Transfer de «" + nm + "» se aplicará a " + t.optString("name") + " automáticamente.")
                                        .setPositiveButton("Sí, recordar", (d2, w2) -> applyTo(d, t, true))
                                        .setNegativeButton("Solo esta vez", (d2, w2) -> applyTo(d, t, false)).show();
                            } else applyTo(d, t, false);
                        });
                    } else if (s.startsWith("🚫")) { Store.put(d, "status", "ignorado"); saveAll(); refresh(); }
                    else if (s.startsWith("↩️")) { undo(d); }
                    else if (s.startsWith("👔")) {
                        JSONObject px = null;
                        for (JSONObject r : recs) {
                            JSONArray pa = r.optJSONArray("payments");
                            if (pa != null) for (int i = 0; i < pa.length(); i++) {
                                JSONObject y = pa.optJSONObject(i);
                                if (y != null && y.optInt("detId", -1) == d.optInt("id")) px = y;
                            }
                        }
                        if (px != null) sendPayment(px.optInt("id")); else toast("No encontré el pago");
                    }
                    else new AlertDialog.Builder(this).setTitle("Texto del aviso").setMessage(d.optString("raw")).setPositiveButton("OK", null).show();
                }).show();
    }

    void applyTo(JSONObject d, JSONObject t, boolean remember) {
        if (t == null) return;
        if (remember) {
            String a = t.optString("aliases").trim();
            Store.put(t, "aliases", a.isEmpty() ? d.optString("name") : a + ", " + d.optString("name"));
        }
        String m = Store.apply(this, d, t, recs);
        saveAll();
        toast("Aplicado a " + t.optString("name") + " · " + Store.monthName(m) + " ✅");
        refresh();
    }

    void undo(JSONObject d) {
        int did = d.optInt("id");
        for (JSONObject r : recs) {
            JSONArray p = r.optJSONArray("payments");
            if (p == null) continue;
            JSONArray na = new JSONArray();
            for (int i = 0; i < p.length(); i++) { JSONObject x = p.optJSONObject(i); if (x != null && x.optInt("detId", -1) != did) na.put(x); }
            Store.put(r, "payments", na);
        }
        Store.put(d, "status", "pendiente");
        d.remove("month");
        saveAll();
        toast("Pago quitado");
        refresh();
    }

    void pasteDialog() {
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(4), dp(20), 0);
        EditText e = input("Pega aquí el texto del correo de INTERAC e-Transfer", TXT_MULTI);
        e.setMinLines(5);
        box.addView(e);
        new AlertDialog.Builder(this).setTitle("Pegar e-Transfer").setView(box)
                .setPositiveButton("Leer", (dlg, w) -> {
                    JSONObject d = Store.handleIncoming(this, e.getText().toString(), System.currentTimeMillis(), "manual");
                    reload();
                    if (d == null) toast("No encontré un e-Transfer en ese texto");
                    else toast(d.optString("status").equals("aplicado") ? "Pago aplicado ✅" : "Leído. Asígnalo a un inquilino.");
                    refresh();
                }).setNegativeButton("Cancelar", null).show();
    }

    // ============================ más ============================
    void more() {
        setHeader("Más", null, "☰", false);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.addView(menuRow("👔", "Enviar al " + mgrName(), "Resumen del mes o reporte de Excel por WhatsApp", v -> managerMenu()));
        c.addView(divider());
        c.addView(menuRow("📊", "Exportar reporte a Excel", "Elige el mes y dónde guardarlo", v -> exportDialog()));
        c.addView(divider());
        c.addView(menuRow("🟢", "Exportar para QuickBooks Online", "Clientes y facturas del mes listos para importar", v -> qboDialog()));
        c.addView(divider());
        c.addView(menuRow("📗", "Cargar mi tabla maestra de Excel", "Importa o actualiza inquilinos desde un .xlsx o .csv", v -> pickImportFile()));
        c.addView(divider());
        c.addView(menuRow("📥", "Pegar lista de inquilinos", "Pega filas copiadas desde Excel", v -> importDialog()));
        c.addView(divider());
        c.addView(menuRow("⚙️", "Ajustes", "Día de pago, días de gracia, correo para e-Transfer", v -> open(this::settings)));
        c.addView(divider());
        c.addView(menuRow("💾", "Copia de seguridad", "Guardar, enviar o restaurar tus datos", v -> Backup.menu(this)));
        c.addView(divider());
        c.addView(menuRow("ℹ️", "Acerca de", "Rentas Amigo Renta · versión 1.8", null));
        p.addView(c);
        TextView info = tv("📁 Cada mes, al abrir la app, se guarda solo el reporte del mes anterior en Descargas → Amigo Renta Reportes" + (Store.getB(this, "autoReport", true) ? "." : " (desactivado en Ajustes)."), 13, MUT, false);
        info.setPadding(dp(18), dp(10), dp(18), 0);
        p.addView(info);
        show(scroll(p), true, null, null);
    }

    View menuRow(String ic, String title, String sub, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(6), 0, dp(6));
        TextView i = tv(ic, 22, TXT, false);
        i.setPadding(0, 0, dp(14), 0);
        r.addView(i);
        LinearLayout t = vbox();
        t.addView(tv(title, 16, TXT, true));
        t.addView(tv(sub, 13, MUT, false));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (l != null) { r.addView(tv("›", 22, MUT, false)); r.setOnClickListener(l); }
        return r;
    }

    void settings() {
        setHeader("Ajustes", null, null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        EditText day = input("1", InputType.TYPE_CLASS_NUMBER);
        day.setText(String.valueOf(Store.getI(this, "dueDay", 1)));
        EditText grace = input("0", InputType.TYPE_CLASS_NUMBER);
        grace.setText(String.valueOf(Store.getI(this, "grace", 0)));
        EditText et = input("Ej. pagos@amigorenta.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        et.setText(Store.get(this, "etEmail", ""));
        EditText cur = input("$", InputType.TYPE_CLASS_TEXT);
        cur.setText(Store.get(this, "cur", "$"));
        final String[] waOpts = {"WhatsApp Business", "WhatsApp normal"};
        TextView wa = picker(waOpts, Store.get(this, "waApp", "business").equals("business") ? waOpts[0] : waOpts[1]);
        Switch rep = new Switch(this);
        rep.setText("📁 Guardar solo el reporte del mes anterior en Descargas");
        rep.setTextColor(TXT);
        rep.setTextSize(14);
        rep.setPadding(0, dp(14), 0, dp(4));
        rep.setChecked(Store.getB(this, "autoReport", true));
        c.addView(twoCols(labeled("Día de pago (por defecto)", day), labeled("Días de gracia", grace)));
        c.addView(tv("Después de los días de gracia el pago aparece como 🔴 atrasado.", 12, MUT, false));
        c.addView(label("📩", "Correo para recibir e-Transfers", false));
        c.addView(et);
        c.addView(tv("Aparece en el recordatorio de WhatsApp a los inquilinos.", 12, MUT, false));
        c.addView(twoCols(labeled("Moneda", cur), labeled("Abrir WhatsApp con", wa)));
        c.addView(rep);
        p.addView(c);
        LinearLayout mg = card();
        mg.addView(tv("👔  Manager", 16, TXT, true));
        EditText mName = input("Manager", TXT_CAP);
        mName.setText(mgrName());
        EditText mPhone = input("+1 604 767 8650", InputType.TYPE_CLASS_PHONE);
        mPhone.setText(Store.get(this, "mgrPhone", "+16047678650"));
        Switch ask = new Switch(this);
        ask.setText("Preguntar si quiero enviarle cada pago que registro");
        ask.setTextColor(TXT);
        ask.setTextSize(14);
        ask.setPadding(0, dp(12), 0, dp(4));
        ask.setChecked(Store.getB(this, "askMgr", true));
        mg.addView(twoCols(labeled("Nombre", mName), labeled("WhatsApp", mPhone)));
        mg.addView(ask);
        p.addView(mg);
        LinearLayout q = card();
        q.addView(tv("🟢  QuickBooks Online", 16, TXT, true));
        EditText qItem = input("Renta", InputType.TYPE_CLASS_TEXT);
        qItem.setText(Store.get(this, "qbItem", "Renta"));
        EditText qTax = input("Exempt", InputType.TYPE_CLASS_TEXT);
        qTax.setText(Store.get(this, "qbTax", "Exempt"));
        final String[] dfs = {"MM/dd/yyyy", "dd/MM/yyyy"};
        TextView qDf = picker(dfs, Store.get(this, "qbDate", "MM/dd/yyyy"));
        q.addView(twoCols(labeled("Producto o servicio", qItem), labeled("Código de impuesto", qTax)));
        q.addView(tv("Deben llamarse igual que en tu QuickBooks. La renta residencial normalmente está exenta (Exempt).", 12, MUT, false));
        q.addView(labeled("Formato de fecha", qDf));
        p.addView(q);
        p.addView(button("Guardar", PRI2, v -> {
            Store.putS(this, "qbItem", qItem.getText().toString().trim().isEmpty() ? "Renta" : qItem.getText().toString().trim());
            Store.putS(this, "qbTax", qTax.getText().toString().trim());
            Store.putS(this, "qbDate", (String) qDf.getTag());
            int d = (int) num(day.getText().toString());
            Store.putI(this, "dueDay", d < 1 || d > 31 ? 1 : d);
            Store.putI(this, "grace", Math.max(0, (int) num(grace.getText().toString())));
            Store.putS(this, "etEmail", et.getText().toString().trim());
            Store.putS(this, "cur", cur.getText().toString().trim().isEmpty() ? "$" : cur.getText().toString().trim());
            Store.putS(this, "waApp", ((String) wa.getTag()).equals(waOpts[0]) ? "business" : "normal");
            Store.putB(this, "autoReport", rep.isChecked());
            Store.putS(this, "mgrName", mName.getText().toString().trim().isEmpty() ? "Manager" : mName.getText().toString().trim());
            Store.putS(this, "mgrPhone", mPhone.getText().toString().trim());
            Store.putB(this, "askMgr", ask.isChecked());
            toast("Ajustes guardados ✅");
            goBack();
        }));
        show(scroll(p), false, null, null);
    }

    // ============================ tabla maestra (Excel / CSV) ============================
    List<List<String>> impRows;
    List<String> impHeaders;
    int[] impMap;
    static final String[] IMP_FIELDS = {"name", "property", "unit", "rent", "phone", "email", "dueDay", "deposit", "aliases", "notes"};
    static final String[] IMP_LABELS = {"Nombre del inquilino *", "Propiedad *", "Número de cuarto", "Renta mensual *", "Teléfono / WhatsApp",
            "Correo", "Día de pago", "Depósito", "Nombre en el e-Transfer", "Notas"};
    static final String[][] IMP_SYN = {
            {"nombre", "inquilino", "tenant", "nombre completo", "nombre y apellido", "nombre inquilino", "cliente", "name", "full name", "residente"},
            {"propiedad", "direccion", "casa", "property", "address", "edificio", "building", "ubicacion", "propiedades"},
            {"cuarto", "habitacion", "room", "unidad", "unit", "numero de cuarto", "hab", "no cuarto", "n cuarto", "room number", "cuarto numero", "suite"},
            {"renta", "alquiler", "rent", "precio", "monto", "mensualidad", "renta mensual", "monthly rent", "pago mensual", "cuota"},
            {"telefono", "tel", "celular", "phone", "whatsapp", "movil", "cel", "numero de telefono", "phone number"},
            {"correo", "email", "e mail", "mail", "correo electronico"},
            {"dia de pago", "dia", "due day", "fecha de pago", "pago dia", "dia pago", "payment day"},
            {"deposito", "deposit", "garantia", "security deposit", "damage deposit"},
            {"e transfer", "etransfer", "nombre e transfer", "nombre en e transfer", "interac", "pagador"},
            {"notas", "notes", "comentarios", "observaciones", "nota", "comments"}};

    void pickImportFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "text/csv", "text/comma-separated-values", "text/plain", "application/vnd.ms-excel", "application/octet-stream"});
        try { startActivityForResult(i, REQ_IMPORT); } catch (Exception e) { toast("No se pudo abrir el selector de archivos"); }
    }

    void readImportFile(Uri u) {
        byte[] bytes;
        try (InputStream in = getContentResolver().openInputStream(u)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            bytes = bo.toByteArray();
        } catch (Throwable e) { importError("No se pudo leer el archivo desde el teléfono.", e); return; }
        if (bytes.length > 2 && bytes[0] == 'P' && bytes[1] == 'K') {
            try {
                final java.util.LinkedHashMap<String, List<List<String>>> sheets = readXlsx(bytes);
                if (sheets.isEmpty()) { toast("El Excel no tiene hojas con datos"); return; }
                if (sheets.size() == 1) { prepareImport(sheets.values().iterator().next()); return; }
                final String[] names = sheets.keySet().toArray(new String[0]);
                new AlertDialog.Builder(this).setTitle("¿Qué hoja tiene los inquilinos?")
                        .setItems(names, (dlg, w) -> prepareImport(sheets.get(names[w]))).show();
            } catch (Throwable e) { importError("No pude leer ese Excel.", e); }
        } else if (bytes.length > 4 && (bytes[0] & 0xFF) == 0xD0 && (bytes[1] & 0xFF) == 0xCF) {
            importError("Este archivo es un Excel antiguo (.xls) o está protegido (con contraseña o etiqueta de confidencialidad de la empresa).\n\n"
                    + "Solución: ábrelo en Excel → Archivo → Guardar como → «CSV UTF-8 (delimitado por comas)» o un .xlsx nuevo sin protección, y cárgalo otra vez.", null);
        } else {
            String text = new String(bytes, StandardCharsets.UTF_8);
            if (text.startsWith("\uFEFF")) text = text.substring(1);
            prepareImport(parseCsv(text));
        }
    }

    static List<List<String>> parseCsv(String text) {
        String first = text.split("\\r?\\n", 2)[0];
        int tabs = first.split("\t", -1).length, semis = first.split(";", -1).length, commas = first.split(",", -1).length;
        char sep = tabs >= semis && tabs >= commas ? '\t' : semis > commas ? ';' : ',';
        List<List<String>> rows = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (q) {
                if (ch == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') { cell.append('"'); i++; }
                    else q = false;
                } else cell.append(ch);
            } else if (ch == '"') q = true;
            else if (ch == sep) { row.add(cell.toString().trim()); cell.setLength(0); }
            else if (ch == '\n' || ch == '\r') {
                if (ch == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') i++;
                row.add(cell.toString().trim()); cell.setLength(0);
                rows.add(row); row = new ArrayList<>();
            } else cell.append(ch);
        }
        if (cell.length() > 0 || !row.isEmpty()) { row.add(cell.toString().trim()); rows.add(row); }
        return rows;
    }

    static java.util.LinkedHashMap<String, List<List<String>>> readXlsx(byte[] bytes) throws Exception {
        java.util.HashMap<String, byte[]> files = new java.util.HashMap<>();
        try (java.util.zip.ZipInputStream z = new java.util.zip.ZipInputStream(new java.io.ByteArrayInputStream(bytes))) {
            java.util.zip.ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String n = e.getName();
                if (n.startsWith("/")) n = n.substring(1);
                if (!(n.startsWith("xl/") && n.endsWith(".xml") || n.endsWith(".rels"))) continue;
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int k;
                while ((k = z.read(buf)) > 0) bo.write(buf, 0, k);
                files.put(n, bo.toByteArray());
            }
        }
        // textos compartidos
        List<String> shared = new ArrayList<>();
        byte[] ss = files.get("xl/sharedStrings.xml");
        if (ss != null) {
            org.xmlpull.v1.XmlPullParser x = android.util.Xml.newPullParser();
            x.setFeature(org.xmlpull.v1.XmlPullParser.FEATURE_PROCESS_NAMESPACES, true);
            x.setInput(new java.io.ByteArrayInputStream(ss), "UTF-8");
            StringBuilder cur = null;
            boolean inT = false, inRph = false;
            for (int ev = x.getEventType(); ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT; ev = x.next()) {
                String tag = x.getName();
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG) {
                    if ("si".equals(tag)) cur = new StringBuilder();
                    else if ("t".equals(tag)) inT = true;
                    else if ("rPh".equals(tag)) inRph = true;
                } else if (ev == org.xmlpull.v1.XmlPullParser.END_TAG) {
                    if ("si".equals(tag)) { shared.add(cur == null ? "" : cur.toString()); cur = null; }
                    else if ("t".equals(tag)) inT = false;
                    else if ("rPh".equals(tag)) inRph = false;
                } else if (ev == org.xmlpull.v1.XmlPullParser.TEXT && inT && !inRph && cur != null) cur.append(x.getText());
            }
        }
        // hojas: nombre -> archivo
        java.util.HashMap<String, String> relTarget = new java.util.HashMap<>();
        byte[] rels = files.get("xl/_rels/workbook.xml.rels");
        if (rels != null) {
            org.xmlpull.v1.XmlPullParser x = android.util.Xml.newPullParser();
            x.setFeature(org.xmlpull.v1.XmlPullParser.FEATURE_PROCESS_NAMESPACES, true);
            x.setInput(new java.io.ByteArrayInputStream(rels), "UTF-8");
            for (int ev = x.getEventType(); ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT; ev = x.next())
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG && "Relationship".equals(x.getName())) {
                    String t = x.getAttributeValue(null, "Target");
                    if (t == null) continue;
                    if (t.startsWith("/")) t = t.substring(1); else t = "xl/" + t;
                    relTarget.put(x.getAttributeValue(null, "Id"), t);
                }
        }
        java.util.LinkedHashMap<String, String> sheetFiles = new java.util.LinkedHashMap<>();
        byte[] wb = files.get("xl/workbook.xml");
        if (wb != null) {
            org.xmlpull.v1.XmlPullParser x = android.util.Xml.newPullParser();
            x.setFeature(org.xmlpull.v1.XmlPullParser.FEATURE_PROCESS_NAMESPACES, true);
            x.setInput(new java.io.ByteArrayInputStream(wb), "UTF-8");
            for (int ev = x.getEventType(); ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT; ev = x.next())
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG && "sheet".equals(x.getName())) {
                    String rid = null;
                    for (int a = 0; a < x.getAttributeCount(); a++) if (x.getAttributeName(a).endsWith("id")) rid = x.getAttributeValue(a);
                    String target = rid == null ? null : relTarget.get(rid);
                    if (target != null && files.containsKey(target)) sheetFiles.put(x.getAttributeValue(null, "name"), target);
                }
        }
        if (sheetFiles.isEmpty()) for (String k : files.keySet()) if (k.startsWith("xl/worksheets/sheet")) sheetFiles.put(k.replace("xl/worksheets/", "").replace(".xml", ""), k);
        java.util.LinkedHashMap<String, List<List<String>>> out = new java.util.LinkedHashMap<>();
        for (java.util.Map.Entry<String, String> sf : sheetFiles.entrySet()) {
            List<List<String>> rows = new ArrayList<>();
            org.xmlpull.v1.XmlPullParser x = android.util.Xml.newPullParser();
            x.setFeature(org.xmlpull.v1.XmlPullParser.FEATURE_PROCESS_NAMESPACES, true);
            x.setInput(new java.io.ByteArrayInputStream(files.get(sf.getValue())), "UTF-8");
            List<String> row = null;
            String type = null, ref = null;
            StringBuilder val = null;
            boolean inV = false, inT = false;
            for (int ev = x.getEventType(); ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT; ev = x.next()) {
                String tag = x.getName();
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG) {
                    if ("row".equals(tag)) row = new ArrayList<>();
                    else if ("c".equals(tag)) { type = x.getAttributeValue(null, "t"); ref = x.getAttributeValue(null, "r"); val = new StringBuilder(); }
                    else if ("v".equals(tag)) inV = true;
                    else if ("t".equals(tag)) inT = true;
                } else if (ev == org.xmlpull.v1.XmlPullParser.TEXT) {
                    if ((inV || inT) && val != null) val.append(x.getText());
                } else if (ev == org.xmlpull.v1.XmlPullParser.END_TAG) {
                    if ("v".equals(tag)) inV = false;
                    else if ("t".equals(tag)) inT = false;
                    else if ("c".equals(tag) && row != null) {
                        String v = val == null ? "" : val.toString();
                        if ("s".equals(type)) { try { v = shared.get(Integer.parseInt(v.trim())); } catch (Exception e) { v = ""; } }
                        else if ("b".equals(type)) v = "1".equals(v) ? "Sí" : "No";
                        else if (type == null || "n".equals(type)) {
                            try { double d = Double.parseDouble(v); v = Math.abs(d - Math.round(d)) < 1e-9 ? String.valueOf(Math.round(d)) : String.valueOf(d); } catch (Exception ignored) { }
                        }
                        int col = row.size();
                        if (ref != null) {
                            int c = 0;
                            for (char ch : ref.toCharArray()) { if (ch >= 'A' && ch <= 'Z') c = c * 26 + (ch - 'A' + 1); else break; }
                            if (c > 0) col = c - 1;
                        }
                        while (row.size() < col) row.add("");
                        if (col < row.size()) row.set(col, v.trim()); else row.add(v.trim());
                        val = null;
                    } else if ("row".equals(tag) && row != null) { rows.add(row); row = null; }
                }
            }
            boolean any = false;
            for (List<String> r : rows) for (String v : r) if (!v.isEmpty()) { any = true; break; }
            if (any) out.put(sf.getKey(), rows);
        }
        return out;
    }

    static String normH(String s) { return Store.norm(s).toLowerCase(Locale.US).replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim(); }

    int detectField(String header) {
        String h = normH(header);
        if (h.isEmpty()) return -1;
        for (int f = 0; f < IMP_SYN.length; f++) for (String syn : IMP_SYN[f]) if (h.equals(syn)) return f;
        for (int f = 0; f < IMP_SYN.length; f++) for (String syn : IMP_SYN[f]) if (syn.length() >= 4 && (h.startsWith(syn) || h.contains(" " + syn))) return f;
        return -1;
    }

    void importError(String msg, Throwable e) {
        String det = e == null ? "" : "\n\nDetalle técnico: " + e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
        new AlertDialog.Builder(this).setTitle("⚠️ No se pudo cargar")
                .setMessage(msg + (e != null ? "\n\nPrueba guardarlo como «CSV UTF-8» desde Excel y cárgalo de nuevo." : "") + det)
                .setPositiveButton("OK", null).show();
    }

    void prepareImport(List<List<String>> rows) {
        try { prepareImportSafe(rows); } catch (Throwable e) { importError("Ocurrió un error al leer las filas.", e); }
    }

    void prepareImportSafe(List<List<String>> rows) {
        if (rows == null || rows.isEmpty()) { importError("No encontré datos en el archivo.", null); return; }
        int hdr = 0, best = -1;
        for (int r = 0; r < Math.min(rows.size(), 15); r++) {
            int hits = 0;
            for (String c : rows.get(r)) if (detectField(c) >= 0) hits++;
            if (hits > best) { best = hits; hdr = r; }
        }
        impHeaders = new ArrayList<>(rows.get(hdr));
        impRows = new ArrayList<>(rows.subList(hdr + 1, rows.size()));
        impMap = new int[IMP_FIELDS.length];
        java.util.Arrays.fill(impMap, -1);
        for (int c = 0; c < impHeaders.size(); c++) {
            int f = detectField(impHeaders.get(c));
            if (f >= 0 && impMap[f] < 0) impMap[f] = c;
        }
        if (impHeaders.isEmpty()) { importError("No encontré la fila de títulos de las columnas.", null); return; }
        open(() -> {
            try { importMapScreen(); }
            catch (Throwable e) { importError("Ocurrió un error al mostrar las columnas.", e); }
        });
    }

    String cellOf(List<String> row, int col) { return col < 0 || col >= row.size() ? "" : row.get(col).trim(); }

    void importMapScreen() {
        setHeader("Cargar tabla maestra", impRows.size() + " filas encontradas", null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.addView(tv("Revisa qué columna de tu Excel corresponde a cada dato. Lo que la app reconoció ya está elegido.", 14, TXT, false));
        String[] opts = new String[impHeaders.size() + 1];
        opts[0] = "— No importar —";
        for (int i = 0; i < impHeaders.size(); i++)
            opts[i + 1] = colName(i) + ": " + (impHeaders.get(i).isEmpty() ? "(sin título)" : impHeaders.get(i));
        for (int f = 0; f < IMP_FIELDS.length; f++) {
            final int ff = f;
            TextView sel = field((impMap[f] < 0 ? opts[0] : opts[impMap[f] + 1]) + "  ▾");
            if (impMap[f] < 0 && (f == 0 || f == 1 || f == 3)) sel.setTextColor(RED);
            sel.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(IMP_LABELS[ff]).setItems(opts, (dlg, w) -> {
                impMap[ff] = w - 1;
                refresh();
            }).show());
            c.addView(labeled(IMP_LABELS[f], sel));
        }
        p.addView(c);

        int ok = 0, upd = 0, skip = 0;
        for (List<String> r : impRows) {
            String n = cellOf(r, impMap[0]);
            if (n.isEmpty() || num(cellOf(r, impMap[3])) <= 0 && findExisting(n, cellOf(r, impMap[1]), cellOf(r, impMap[2])) == null) { if (!n.isEmpty() || !String.join("", r).trim().isEmpty()) skip++; continue; }
            if (findExisting(n, cellOf(r, impMap[1]), cellOf(r, impMap[2])) != null) upd++; else ok++;
        }
        p.addView(sectionTitle("Vista previa", null, null));
        LinearLayout pv = card();
        int shown = 0;
        for (List<String> r : impRows) {
            String n = cellOf(r, impMap[0]);
            if (n.isEmpty()) continue;
            if (pv.getChildCount() > 0) pv.addView(divider());
            pv.addView(tv(n, 15, TXT, true));
            pv.addView(tv(join(" · ", cellOf(r, impMap[1]), cellOf(r, impMap[2]).isEmpty() ? "" : "Cuarto " + cellOf(r, impMap[2]),
                    num(cellOf(r, impMap[3])) > 0 ? money(num(cellOf(r, impMap[3]))) : "sin renta"), 13, MUT, false));
            if (++shown >= 5) break;
        }
        if (shown == 0) pv.addView(tv("Elige la columna del nombre para ver la vista previa.", 14, MUT, false));
        p.addView(pv);
        TextView sum = tv("➕ " + ok + " nuevos   ✏️ " + upd + " se actualizan   ⏭️ " + skip + " filas se omiten", 15, TXT, true);
        sum.setPadding(dp(18), dp(10), dp(18), 0);
        p.addView(sum);
        TextView note = tv("Si un inquilino ya existe (mismo nombre y propiedad), se actualizan sus datos en lugar de duplicarlo. Las filas sin nombre o sin renta se omiten.", 12, MUT, false);
        note.setPadding(dp(18), dp(6), dp(18), 0);
        p.addView(note);
        final int total = ok + upd;
        p.addView(button("📗  Cargar " + total + " inquilinos", GRN, v -> {
            if (impMap[0] < 0 || impMap[3] < 0) { toast("Elige al menos las columnas de nombre y renta"); return; }
            if (impMap[1] < 0) { toast("Elige la columna de la propiedad"); return; }
            try { doImport(); } catch (Throwable e) { importError("Ocurrió un error al guardar los inquilinos.", e); }
        }));
        show(scroll(p), false, null, null);
    }

    JSONObject findExisting(String name, String prop, String unit) {
        String nn = Store.norm(name), np = Store.norm(prop);
        for (JSONObject t : tenants)
            if (Store.norm(t.optString("name")).equals(nn) && (np.isEmpty() || Store.norm(t.optString("property")).equals(np))) return t;
        return null;
    }

    void doImport() {
        int added = 0, updated = 0;
        for (List<String> r : impRows) {
            String n = cellOf(r, impMap[0]);
            if (n.isEmpty()) continue;
            JSONObject t = findExisting(n, cellOf(r, impMap[1]), cellOf(r, impMap[2]));
            double rent = num(cellOf(r, impMap[3]));
            if (t == null && rent <= 0) continue;
            boolean isNew = t == null;
            if (isNew) {
                t = new JSONObject();
                Store.put(t, "id", Store.nextId(this));
                Store.put(t, "since", Store.thisMonth());
                Store.put(t, "dueDay", Store.getI(this, "dueDay", 1));
            }
            Store.put(t, "name", n);
            for (int f = 1; f < IMP_FIELDS.length; f++) {
                String v = cellOf(r, impMap[f]);
                if (v.isEmpty()) continue;
                switch (IMP_FIELDS[f]) {
                    case "rent": if (num(v) > 0) Store.put(t, "rent", num(v)); break;
                    case "deposit": if (num(v) > 0) { Store.put(t, "deposit", num(v)); if (isNew) Store.put(t, "depPaid", true); } break;
                    case "dueDay": { int d = (int) num(v.replaceAll("[^0-9.]", "")); if (d >= 1 && d <= 31) Store.put(t, "dueDay", d); } break;
                    case "unit": Store.put(t, "unit", v.replaceAll("(?i)^(cuarto|habitaci[oó]n|room|hab\\.?)\\s*#?\\s*", "")); break;
                    default: Store.put(t, IMP_FIELDS[f], v);
                }
            }
            if (isNew) { tenants.add(t); added++; } else updated++;
        }
        saveAll();
        toast("✅ " + added + " inquilinos nuevos · " + updated + " actualizados");
        openTab(1);
    }

    void importDialog() {
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(4), dp(20), 0);
        box.addView(tv("Copia desde Excel estas columnas en este orden y pégalas aquí:\nNombre | Propiedad | Cuarto | Renta | Teléfono | Día de pago | Depósito\n(Teléfono, día de pago y depósito son opcionales)", 13, MUT, false));
        EditText e = input("Pega aquí", TXT_MULTI);
        e.setMinLines(6);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        box.addView(e);
        new AlertDialog.Builder(this).setTitle("Importar inquilinos").setView(box)
                .setPositiveButton("Importar", (dlg, w) -> {
                    int n = 0, skip = 0;
                    for (String line : e.getText().toString().split("\\r?\\n")) {
                        if (line.trim().isEmpty()) continue;
                        String[] c = line.contains("\t") ? line.split("\t") : line.split("[;,]");
                        if (c.length < 4) { skip++; continue; }
                        double rn = num(c[3]);
                        if (c[0].trim().isEmpty() || rn <= 0) { skip++; continue; }
                        JSONObject o = new JSONObject();
                        Store.put(o, "id", Store.nextId(this));
                        Store.put(o, "name", c[0].trim());
                        Store.put(o, "property", c[1].trim());
                        Store.put(o, "unit", c[2].trim());
                        Store.put(o, "rent", rn);
                        Store.put(o, "phone", c.length > 4 ? c[4].trim() : "");
                        int d = c.length > 5 ? (int) num(c[5]) : 0;
                        Store.put(o, "dueDay", d >= 1 && d <= 31 ? d : Store.getI(this, "dueDay", 1));
                        Store.put(o, "since", Store.thisMonth());
                        double dpi = c.length > 6 ? num(c[6]) : 0;
                        if (dpi > 0) { Store.put(o, "deposit", dpi); Store.put(o, "depPaid", true); }
                        tenants.add(o);
                        n++;
                    }
                    saveAll();
                    toast(n + " inquilinos importados" + (skip > 0 ? " · " + skip + " líneas no se pudieron leer" : ""));
                    openTab(1);
                }).setNegativeButton("Cancelar", null).show();
    }

    // ============================ QuickBooks Online ============================
    void qboDialog() {
        String[] ms = new String[13];
        for (int i = 0; i < 13; i++) ms[i] = Store.monthName(Store.addMonth(Store.thisMonth(), 1 - i));
        new AlertDialog.Builder(this).setTitle("Facturas de qué mes").setItems(ms, (dlg, w) -> exportQbo(Store.addMonth(Store.thisMonth(), 1 - w))).show();
    }

    static String csv(String v) {
        String x = v == null ? "" : v.replace("\r", " ").replace("\n", " ");
        return "\"" + x.replace("\"", "\"\"") + "\"";
    }

    static String csvLine(Object... cells) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < cells.length; i++) {
            if (i > 0) b.append(',');
            Object c = cells[i];
            if (c instanceof Number) b.append(String.format(Locale.US, "%.2f", ((Number) c).doubleValue()));
            else b.append(csv(c == null ? "" : c.toString()));
        }
        return b.append("\r\n").toString();
    }

    String qbDate(String iso) {
        try { return Store.f(Store.get(this, "qbDate", "MM/dd/yyyy")).format(Store.f("yyyy-MM-dd").parse(iso)); }
        catch (Exception e) { return iso; }
    }

    String qbName(JSONObject t) { return t.optString("name").trim().replaceAll("\\s+", " ").replace(":", " "); }

    void exportQbo(String m) {
        List<JSONObject> act = activeTenants(m);
        if (act.isEmpty()) { toast("No hay inquilinos en " + Store.monthName(m)); return; }
        Collections.sort(act, (x, y) -> where(x).compareToIgnoreCase(where(y)));
        String item = Store.get(this, "qbItem", "Renta"), tax = Store.get(this, "qbTax", "Exempt");
        String tag = m.replace("-", "");

        StringBuilder cu = new StringBuilder(csvLine("Name", "Email", "Phone", "Mobile", "Street", "City", "Province", "Postal Code", "Country", "Notes"));
        for (JSONObject t : act)
            cu.append(csvLine(qbName(t), t.optString("email"), t.optString("phone"), t.optString("phone"),
                    where(t), "", "", "", "Canada", "Inquilino Amigo Renta"));

        StringBuilder inv = new StringBuilder(csvLine("Invoice No", "Customer", "Invoice Date", "Due Date", "Memo",
                "Item(Product/Service)", "Item Description", "Item Quantity", "Item Rate", "Item Amount", "Item Tax Code"));
        String first = m + "-01";
        String mName = Store.monthName(m).toLowerCase(Store.ES);
        for (JSONObject t : act) {
            JSONObject r = Store.rec(recs, t.optInt("id"), m, false);
            double due = Store.due(t, r);
            if (due <= 0) continue;
            String no = "R" + tag.substring(2) + "-" + String.format(Locale.US, "%04d", t.optInt("id"));
            String desc = "Renta " + mName + " · " + where(t);
            inv.append(csvLine(no, qbName(t), qbDate(first), qbDate(Store.dueDate(t, m, this)), desc,
                    item, desc, 1, due, due, tax));
        }

        StringBuilder pay = new StringBuilder(csvLine("Payment Date", "Customer", "Amount", "Payment Method", "Reference No", "Invoice No", "Memo"));
        for (JSONObject t : act) {
            JSONObject r = Store.rec(recs, t.optInt("id"), m, false);
            JSONArray pa = r == null ? null : r.optJSONArray("payments");
            if (pa == null) continue;
            String no = "R" + tag.substring(2) + "-" + String.format(Locale.US, "%04d", t.optInt("id"));
            for (int i = 0; i < pa.length(); i++) {
                JSONObject x = pa.optJSONObject(i);
                if (x == null) continue;
                pay.append(csvLine(qbDate(Store.dayOf(x.optLong("date"))), qbName(t), x.optDouble("amount", 0), x.optString("method"),
                        x.optString("ref"), no, "Pago renta " + mName));
            }
        }

        if (Build.VERSION.SDK_INT < 29) { toast("Esta función necesita Android 10 o más nuevo"); return; }
        ArrayList<Uri> files = new ArrayList<>();
        String[][] parts = {{"QBO_1_Clientes_" + m + ".csv", cu.toString()}, {"QBO_2_Facturas_" + m + ".csv", inv.toString()},
                {"QBO_3_Pagos_" + m + ".csv", pay.toString()}};
        try {
            for (String[] f : parts) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, f[0]);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv");
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Amigo Renta QuickBooks");
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) throw new Exception("sin archivo");
                try (OutputStream os = getContentResolver().openOutputStream(u)) { os.write(f[1].getBytes(StandardCharsets.UTF_8)); }
                files.add(u);
            }
        } catch (Exception e) { toast("No se pudieron guardar los archivos"); return; }
        final ArrayList<Uri> fs = files;
        new AlertDialog.Builder(this)
                .setTitle("✅ Archivos listos")
                .setMessage("Se guardaron 3 archivos en Descargas → Amigo Renta QuickBooks:\n\n"
                        + "1. Clientes (" + act.size() + " inquilinos)\n2. Facturas de " + Store.monthName(m) + "\n3. Pagos (referencia)\n\n"
                        + "Envíatelos por correo para importarlos desde la computadora.")
                .setPositiveButton("Enviar / compartir", (dlg, w) -> {
                    Intent i = new Intent(Intent.ACTION_SEND_MULTIPLE);
                    i.setType("text/csv");
                    i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, fs);
                    i.putExtra(Intent.EXTRA_SUBJECT, "QuickBooks · Rentas " + Store.monthName(m));
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    launch(Intent.createChooser(i, "Enviar archivos"));
                })
                .setNegativeButton("Listo", null).show();
    }

    // ============================ Excel ============================
    void exportDialog() {
        String[] ms = new String[12];
        for (int i = 0; i < 12; i++) ms[i] = Store.monthName(Store.addMonth(Store.thisMonth(), -i));
        new AlertDialog.Builder(this).setTitle("¿De qué mes?").setItems(ms, (dlg, w) -> {
            exportMonth = Store.addMonth(Store.thisMonth(), -w);
            new AlertDialog.Builder(this).setTitle("Reporte de " + ms[w])
                    .setItems(new String[]{"📁 Guardar en Descargas", "📂 Elegir dónde guardarlo (Drive, etc.)"}, (d2, w2) -> {
                        if (w2 == 0) {
                            if (saveToDownloads(exportMonth)) toast("Guardado en Descargas → Amigo Renta Reportes ✅");
                            else toast("No se pudo guardar. Usa «Elegir dónde guardarlo».");
                        } else {
                            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                            i.addCategory(Intent.CATEGORY_OPENABLE);
                            i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                            i.putExtra(Intent.EXTRA_TITLE, "Rentas_" + exportMonth + ".xlsx");
                            try { startActivityForResult(i, REQ_EXPORT); } catch (Exception e) { toast("No se pudo abrir el selector"); }
                        }
                    }).show();
        }).show();
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (Backup.onResult(this, rq, rs, data, this::afterRestore)) return;
        if (rq == REQ_IMPORT) {
            if (rs == RESULT_OK && data != null && data.getData() != null) {
                try { readImportFile(data.getData()); } catch (Throwable e) { importError("No pude abrir el archivo.", e); }
            }
            return;
        }
        if (rq == REQ_PHOTO) {
            if (rs == RESULT_OK && pendingCap != null) setImage(pendingCap.toString());
            else if (pendingCap != null) try { getContentResolver().delete(pendingCap, null, null); } catch (Exception e) { }
            pendingCap = null;
            return;
        }
        if (rq == REQ_PICK) {
            if (rs == RESULT_OK && data != null && data.getData() != null) {
                try { getContentResolver().takePersistableUriPermission(data.getData(), Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception e) { }
                setImage(data.getData().toString());
            }
            return;
        }
        if (rq == REQ_EXPORT && rs == RESULT_OK && data != null && data.getData() != null) {
            try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                writeReport(os, exportMonth);
                toast("Excel guardado ✅");
            } catch (Exception e) { toast("No se pudo guardar el archivo"); }
        }
    }

    boolean saveToDownloads(String m) { return saveReportUri(m) != null; }

    Uri saveReportUri(String m) {
        if (Build.VERSION.SDK_INT < 29) return null;
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "Rentas_" + m + "_" + System.currentTimeMillis() % 100000 + ".xlsx");
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Amigo Renta Reportes");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u == null) return null;
            try (OutputStream os = getContentResolver().openOutputStream(u)) { writeReport(os, m); }
            return u;
        } catch (Exception e) { return null; }
    }

    void autoExport() {
        if (!Store.getB(this, "autoReport", true) || tenants.isEmpty()) return;
        String prev = Store.addMonth(Store.thisMonth(), -1);
        if (prev.equals(Store.get(this, "lastAuto", ""))) return;
        if (saveToDownloads(prev)) {
            Store.putS(this, "lastAuto", prev);
            toast("📊 Reporte de " + Store.monthName(prev) + " guardado en Descargas");
        }
    }

    void writeReport(OutputStream os, String m) throws Exception {
        List<String> names = new ArrayList<>();
        List<List<List<Object>>> sheets = new ArrayList<>();
        List<int[]> widths = new ArrayList<>();
        List<JSONObject> act = activeTenants(m);
        Collections.sort(act, (x, y) -> (x.optString("property") + x.optString("unit") + x.optString("name")).compareToIgnoreCase(y.optString("property") + y.optString("unit") + y.optString("name")));

        List<List<Object>> rows = new ArrayList<>();
        rows.add(row("Inquilino", "Propiedad", "Cuarto", "Renta", "Pagado", "Falta", "Estado", "Fecha de pago", "Pagó el", "Forma de pago",
                "Días de atraso", "Fecha prometida", "Depósito", "Depósito recibido", "Depósito devuelto", "Teléfono", "Notas"));
        List<List<Object>> pend = new ArrayList<>();
        pend.add(row("Inquilino", "Propiedad", "Cuarto", "Falta", "Estado", "Días de atraso", "Fecha prometida", "Teléfono", "Notas"));
        List<List<Object>> pays = new ArrayList<>();
        pays.add(row("Fecha", "Inquilino", "Propiedad", "Cuarto", "Monto", "Forma de pago", "Origen", "Referencia", "Comprobante"));
        double exp = 0, got = 0, depHeld = 0, depPending = 0;
        int[] cnt = new int[4];
        for (JSONObject t : act) {
            JSONObject r = Store.rec(recs, t.optInt("id"), m, false);
            double due = Store.due(t, r), pd = Store.paid(r), owed = Math.max(0, due - pd);
            int st = status(t, m);
            cnt[st]++;
            exp += due;
            got += Math.min(pd, due);
            String dd = Store.dueDate(t, m, this);
            int late = st == 3 ? Store.daysBetween(dd, Store.today()) : 0;
            long lp = lastPaymentDate(r);
            String methods = "";
            JSONArray pa = r == null ? null : r.optJSONArray("payments");
            if (pa != null) for (int i = 0; i < pa.length(); i++) {
                JSONObject x = pa.optJSONObject(i);
                if (x == null) continue;
                if (!methods.contains(x.optString("method"))) methods = methods.isEmpty() ? x.optString("method") : methods + ", " + x.optString("method");
                pays.add(row(Store.excelDate(x.optLong("date")), t.optString("name"), t.optString("property"), t.optString("unit"),
                        r2(x.optDouble("amount", 0)), x.optString("method"), x.optString("source").equals("auto") ? "Automático (correo)" : "Manual", x.optString("ref"),
                        x.optString("img").isEmpty() ? "No" : "Sí"));
            }
            String prom = r == null ? "" : r.optString("promise");
            String notes = r == null ? "" : r.optString("notes");
            rows.add(row(t.optString("name"), t.optString("property"), t.optString("unit"), r2(due), r2(pd), r2(owed), ST_NAMES[st], dd,
                    lp > 0 ? Store.dayOf(lp) : "", methods, late > 0 ? (Object) late : "", prom,
                    t.optDouble("deposit", 0) > 0 ? (Object) r2(t.optDouble("deposit", 0)) : "",
                    t.optDouble("deposit", 0) > 0 ? (t.optBoolean("depPaid") ? "Sí" + (t.optLong("depDate") > 0 ? " (" + Store.dayOf(t.optLong("depDate")) + ")" : "") : "No") : "",
                    t.optDouble("depReturned", 0) > 0 ? (Object) r2(t.optDouble("depReturned", 0)) : "",
                    t.optString("phone"), notes));
            if (t.optBoolean("depPaid")) depHeld += Math.max(0, t.optDouble("deposit", 0) - t.optDouble("depReturned", 0));
            else if (t.optDouble("deposit", 0) > 0) depPending += t.optDouble("deposit", 0);
            if (st != 0) pend.add(row(t.optString("name"), t.optString("property"), t.optString("unit"), r2(owed), ST_NAMES[st],
                    late > 0 ? (Object) late : "", prom, t.optString("phone"), notes));
        }
        List<List<Object>> res = new ArrayList<>();
        res.add(row("Reporte de rentas", Store.monthName(m)));
        res.add(row("Generado", Store.dateTime(System.currentTimeMillis())));
        res.add(row("Inquilinos", act.size()));
        res.add(row("Total esperado", r2(exp)));
        res.add(row("Total cobrado", r2(got)));
        res.add(row("Falta por cobrar", r2(exp - got)));
        res.add(row("% cobrado", exp > 0 ? r2(got * 100 / exp) : 0));
        for (int i = 0; i < 4; i++) res.add(row(ST_NAMES[i], cnt[i]));
        res.add(row("Depósitos en garantía (recibidos)", r2(depHeld)));
        res.add(row("Depósitos pendientes de entregar", r2(depPending)));
        names.add("Resumen"); sheets.add(res); widths.add(new int[]{34, 26});
        names.add("Rentas"); sheets.add(rows); widths.add(new int[]{26, 26, 14, 11, 11, 11, 11, 13, 12, 16, 12, 14, 11, 18, 14, 16, 30});
        names.add("Faltan por pagar"); sheets.add(pend); widths.add(new int[]{26, 26, 14, 11, 11, 12, 14, 16, 30});
        names.add("Pagos"); sheets.add(pays); widths.add(new int[]{17, 26, 26, 14, 11, 14, 18, 24, 12});
        List<List<Object>> ets = new ArrayList<>();
        ets.add(row("Fecha", "Nombre en el e-Transfer", "Monto", "Estado", "Inquilino", "Aplicado al mes"));
        for (JSONObject d : detected) {
            if (!Store.month(d.optLong("at")).equals(m) && !m.equals(d.optString("month"))) continue;
            JSONObject t = d.has("tid") ? Store.tenant(tenants, d.optInt("tid")) : null;
            ets.add(row(Store.excelDate(d.optLong("at")), d.optString("name"), r2(d.optDouble("amount", 0)), d.optString("status"),
                    t == null ? "" : t.optString("name"), d.optString("month").isEmpty() ? "" : Store.monthName(d.optString("month"))));
        }
        names.add("e-Transfers"); sheets.add(ets); widths.add(new int[]{17, 28, 11, 12, 26, 16});
        writeBook(os, names, sheets, widths);
    }

    static double r2(double v) { return Math.round(v * 100) / 100.0; }

    void writeBook(OutputStream os, List<String> names, List<List<List<Object>>> sheets, List<int[]> widths) throws Exception {
        ZipOutputStream z = new ZipOutputStream(os);
        String ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        String rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        String pk = "http://schemas.openxmlformats.org/package/2006/relationships";
        String hd = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n";
        StringBuilder ct = new StringBuilder(hd + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        StringBuilder wb = new StringBuilder(hd + "<workbook xmlns=\"" + ns + "\" xmlns:r=\"" + rel + "\"><sheets>");
        StringBuilder wr = new StringBuilder(hd + "<Relationships xmlns=\"" + pk + "\">");
        for (int i = 0; i < names.size(); i++) {
            ct.append("<Override PartName=\"/xl/worksheets/sheet").append(i + 1)
                    .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            wb.append("<sheet name=\"").append(xml(names.get(i))).append("\" sheetId=\"").append(i + 1).append("\" r:id=\"rId").append(i + 1).append("\"/>");
            wr.append("<Relationship Id=\"rId").append(i + 1).append("\" Type=\"").append(rel).append("/worksheet\" Target=\"worksheets/sheet").append(i + 1).append(".xml\"/>");
        }
        ct.append("</Types>");
        wb.append("</sheets></workbook>");
        wr.append("<Relationship Id=\"rId").append(names.size() + 1).append("\" Type=\"").append(rel).append("/styles\" Target=\"styles.xml\"/></Relationships>");
        zput(z, "[Content_Types].xml", ct.toString());
        zput(z, "_rels/.rels", hd + "<Relationships xmlns=\"" + pk + "\">"
                + "<Relationship Id=\"rId1\" Type=\"" + rel + "/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        zput(z, "xl/workbook.xml", wb.toString());
        zput(z, "xl/_rels/workbook.xml.rels", wr.toString());
        zput(z, "xl/styles.xml", hd + "<styleSheet xmlns=\"" + ns + "\">"
                + "<numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"#,##0.00\"/></numFmts>"
                + "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font>"
                + "<font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font></fonts>"
                + "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>"
                + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF0D3B7A\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>"
                + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                + "<cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
                + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/>"
                + "<xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/></cellXfs>"
                + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
                + "</styleSheet>");
        for (int i = 0; i < names.size(); i++) zput(z, "xl/worksheets/sheet" + (i + 1) + ".xml", sheetXml(ns, sheets.get(i), widths.get(i)));
        z.finish();
    }

    static List<Object> row(Object... cells) {
        List<Object> r = new ArrayList<>();
        Collections.addAll(r, cells);
        return r;
    }

    static void zput(ZipOutputStream z, String name, String content) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    static String colName(int i) {
        StringBuilder s = new StringBuilder();
        i++;
        while (i > 0) { int m = (i - 1) % 26; s.insert(0, (char) ('A' + m)); i = (i - 1) / 26; }
        return s.toString();
    }

    static String xml(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch == '&') b.append("&amp;");
            else if (ch == '<') b.append("&lt;");
            else if (ch == '>') b.append("&gt;");
            else if (ch == '"') b.append("&quot;");
            else if (ch < 0x20 && ch != '\n' && ch != '\t' && ch != '\r') b.append(' ');
            else b.append(ch);
        }
        return b.toString();
    }

    static String sheetXml(String ns, List<List<Object>> rows, int[] widths) {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n");
        s.append("<worksheet xmlns=\"").append(ns).append("\">");
        s.append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
        s.append("<cols>");
        for (int i = 0; i < widths.length; i++)
            s.append("<col min=\"").append(i + 1).append("\" max=\"").append(i + 1).append("\" width=\"").append(widths[i]).append("\" customWidth=\"1\"/>");
        s.append("</cols><sheetData>");
        for (int r = 0; r < rows.size(); r++) {
            s.append("<row r=\"").append(r + 1).append("\">");
            List<Object> row = rows.get(r);
            for (int c = 0; c < row.size(); c++) {
                Object v = row.get(c);
                String ref = colName(c) + (r + 1);
                if (v instanceof Number && r > 0) {
                    double d = ((Number) v).doubleValue();
                    boolean whole = Math.abs(d - Math.round(d)) < 1e-9;
                    s.append("<c r=\"").append(ref).append("\"").append(whole ? "" : " s=\"2\"").append("><v>")
                            .append(whole ? String.valueOf(Math.round(d)) : String.valueOf(d)).append("</v></c>");
                } else {
                    String str = v == null ? "" : v.toString();
                    if (str.isEmpty() && r > 0) continue;
                    s.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"").append(r == 0 ? " s=\"1\"" : "")
                            .append("><is><t xml:space=\"preserve\">").append(xml(str)).append("</t></is></c>");
                }
            }
            s.append("</row>");
        }
        s.append("</sheetData></worksheet>");
        return s.toString();
    }

    // ============================ propiedades y cuartos ============================
    static String room(JSONObject t) {
        String u = t.optString("unit").trim();
        if (u.isEmpty()) return "";
        return u.toLowerCase(Locale.US).startsWith("cuarto") || u.toLowerCase(Locale.US).startsWith("room") ? u : "Cuarto " + u;
    }

    static String where(JSONObject t) { return join(" · ", t.optString("property"), room(t)); }

    List<String> properties() {
        List<String> r = new ArrayList<>();
        List<String> seen = new ArrayList<>();
        for (JSONObject t : tenants) {
            String pr = t.optString("property").trim();
            if (pr.isEmpty() || seen.contains(Store.norm(pr))) continue;
            seen.add(Store.norm(pr));
            r.add(pr);
        }
        Collections.sort(r, String::compareToIgnoreCase);
        return r;
    }

    JSONObject roomTaken(String prop, String unit, int exceptId) {
        String np = Store.norm(prop), nu = Store.norm(unit).replace("CUARTO ", "").replace("ROOM ", "");
        if (np.isEmpty() || nu.isEmpty()) return null;
        for (JSONObject t : tenants) {
            if (t.optInt("id") == exceptId || t.optBoolean("inactive")) continue;
            String tu = Store.norm(t.optString("unit")).replace("CUARTO ", "").replace("ROOM ", "");
            if (Store.norm(t.optString("property")).equals(np) && tu.equals(nu)) return t;
        }
        return null;
    }

    // ============================ utilidades ============================
    static String qty(double q) {
        if (Math.abs(q - Math.round(q)) < 0.0001) return String.valueOf(Math.round(q));
        return String.format(Locale.US, "%.2f", q);
    }

    static double num(String s) {
        try { return Double.parseDouble(s.trim().replace("$", "").replace(",", "")); } catch (Exception e) { return 0; }
    }

    View kv(String k, String v) { return kv(k, v, TXT); }

    View kv(String k, String v, int color) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(4), 0, dp(4));
        r.addView(tv(k, 14, MUT, false), new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(tv(v, 15, color, true));
        return r;
    }

    View dateField(long[] date) {
        final TextView f = field("📅  " + Store.shortDate(Store.dayOf(date[0])));
        f.setOnClickListener(v -> pickDate(Store.dayOf(date[0]), iso -> {
            long base = Store.millisAt(iso, 12);
            if (base > 0) date[0] = base;
            f.setText("📅  " + Store.shortDate(iso));
        }));
        return labeled("Fecha", f);
    }

    void pickDate(String iso, Cb cb) {
        Calendar c = Store.cal();
        try { c.setTime(Store.f("yyyy-MM-dd").parse(iso)); } catch (Exception e) { }
        new DatePickerDialog(this, (dpk, y, m, d) -> cb.on(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)),
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    static String join(String sep, String... parts) {
        StringBuilder b = new StringBuilder();
        for (String p : parts) {
            if (p == null || p.trim().isEmpty()) continue;
            if (b.length() > 0) b.append(sep);
            b.append(p.trim());
        }
        return b.toString();
    }

    LinearLayout.LayoutParams weightLp(float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, w);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    void launch(Intent i) {
        try { startActivity(i); } catch (Exception e) { toast("No hay una app para abrir esto"); }
    }

    void afterRestore() {
        Store.scheduleAllPromises(this);
        recreate();
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ============================ Componentes visuales ============================
    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    GradientDrawable roundStroke(int color, float r, int stroke) {
        GradientDrawable g = round(color, r);
        g.setStroke(dp(1), stroke);
        return g;
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    LinearLayout card() {
        LinearLayout c = vbox();
        c.setBackground(round(Color.WHITE, 16));
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(6), dp(14), dp(6));
        c.setLayoutParams(lp);
        return c;
    }

    ScrollView scroll(LinearLayout inner) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        inner.setPadding(0, dp(6), 0, dp(100));
        s.addView(inner, new FrameLayout.LayoutParams(-1, -2));
        return s;
    }

    HorizontalScrollView hscroll(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }

    View sectionTitle(String t, String link, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(dp(18), dp(16), dp(18), dp(6));
        r.addView(tv(t, 17, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        if (link != null) {
            TextView k = tv(link, 14, PRI2, true);
            k.setOnClickListener(l);
            r.addView(k);
        }
        return r;
    }

    View empty(String s) {
        TextView t = tv(s, 14, MUT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundStroke(Color.WHITE, 14, BRD));
        t.setPadding(dp(14), dp(20), dp(14), dp(20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(4), dp(14), dp(4));
        t.setLayoutParams(lp);
        return t;
    }

    View divider() {
        View d = new View(this);
        d.setBackgroundColor(BRD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(10), 0, dp(10));
        d.setLayoutParams(lp);
        return d;
    }

    View gap(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    TextView chip(String text, boolean sel, View.OnClickListener l) {
        TextView t = tv(text, 14, TXT, true);
        t.setPadding(dp(16), dp(9), dp(16), dp(9));
        styleChip(t, sel);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    void styleChip(TextView t, boolean sel) {
        t.setBackground(sel ? round(PRI2, 20) : roundStroke(Color.WHITE, 20, BRD));
        t.setTextColor(sel ? Color.WHITE : TXT);
    }

    TextView avatar(String n, int color, int size) {
        String ini = n == null || n.trim().isEmpty() ? "?" : n.trim().substring(0, 1).toUpperCase(Store.ES);
        TextView t = tv(ini, size / 2.4f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return t;
    }

    View action(String ic, String label, int fg, int bg, View.OnClickListener l) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(bg, 14));
        b.setPadding(dp(2), dp(12), dp(2), dp(10));
        TextView i = tv(ic, 20, fg, false);
        i.setGravity(Gravity.CENTER);
        TextView t = tv(label, 10, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(1);
        t.setEllipsize(TextUtils.TruncateAt.END);
        b.addView(i);
        b.addView(t);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    TextView button(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 16, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(color, 14));
        b.setPadding(dp(14), dp(15), dp(14), dp(15));
        b.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(16), dp(14), dp(6));
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    TextView outline(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 15, color, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundStroke(Color.WHITE, 14, color));
        b.setPadding(dp(10), dp(13), dp(10), dp(13));
        b.setOnClickListener(l);
        return b;
    }

    LinearLayout.LayoutParams fieldLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, 0);
        return lp;
    }

    EditText input(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFFA0A8B5);
        e.setTextColor(TXT);
        e.setTextSize(15);
        e.setInputType(type);
        if ((type & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) {
            e.setMinLines(2);
            e.setGravity(Gravity.TOP | Gravity.START);
        }
        e.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        e.setPadding(dp(12), dp(11), dp(12), dp(11));
        e.setLayoutParams(fieldLp());
        return e;
    }

    TextView field(String text) {
        TextView t = tv(text, 15, TXT, false);
        t.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        t.setPadding(dp(12), dp(12), dp(12), dp(12));
        t.setLayoutParams(fieldLp());
        return t;
    }

    TextView picker(String[] opts, String cur) {
        String val = (cur == null || cur.isEmpty()) ? (opts.length > 0 ? opts[0] : "") : cur;
        final TextView t = field(val + "  ▾");
        t.setTag(val);
        t.setOnClickListener(v -> new AlertDialog.Builder(this).setItems(opts, (dlg, w) -> {
            t.setTag(opts[w]);
            t.setText(opts[w] + "  ▾");
        }).show());
        return t;
    }

    View label(String icon, String text, boolean req) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(14), 0, 0);
        r.addView(tv(icon + "  " + text, 13, MUT, true));
        if (req) r.addView(tv(" *", 13, RED, true));
        return r;
    }

    View labeled(String text, View v) {
        LinearLayout b = vbox();
        TextView l = tv(text, 13, MUT, true);
        l.setPadding(0, dp(14), 0, 0);
        b.addView(l);
        b.addView(v);
        return b;
    }

    View twoCols(View a, View b) {
        LinearLayout r = hbox();
        r.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1f);
        l1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1f);
        l2.setMargins(dp(6), 0, 0, 0);
        r.addView(a, l1);
        r.addView(b, l2);
        return r;
    }

}
