package com.amigorenta.rentas;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {

    static final int PRI = 0xFF0D3B7A, PRI2 = 0xFF1565C0, BG = 0xFFF3F6FB, TXT = 0xFF1A2433,
            MUT = 0xFF6B7585, BRD = 0xFFE1E7EF, RED = 0xFFDC2626, GRN = 0xFF16A34A, ORG = 0xFFEA580C, YEL = 0xFFB45309;
    static final String[] METHODS = {"e-Transfer", "Efectivo", "Cheque", "Depósito", "Otro"};
    static final int REQ_EXPORT = 91, REQ_PHOTO = 92, REQ_PICK = 93, REQ_IMPORT = 94;
    static final int TXT_CAP = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    static final int TXT_MULTI = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;
    static final int DEC = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL;

    interface Cb { void on(String s); }

    List<JSONObject> tenants, recs, detected;
    FrameLayout content;
    LinearLayout header, nav;
    TextView fab;
    final ArrayList<Runnable> stack = new ArrayList<>();
    int tabSel = 0;
    String month, filter = "Todos", search = "", tSearch = "", exportMonth, propFilter = "";
    // formulario de pago (se conserva al tomar la foto)
    String formKey = "", formAmt = null, formRef = "", formMethod = "e-Transfer", formImg = "", formRecv = null;
    static final String CASH = "Efectivo";
    long formDate = 0;
    int pendingPayId = -1;
    int pendingMailPid = -1;
    Uri pendingCap;

    // ============================ ciclo de vida ============================
    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        month = Store.thisMonth();
        if (!Store.getB(this, "qbMig", false)) { Store.markHistory(this); Store.putB(this, "qbMig", true); }
        reload();
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        LinearLayout col = vbox();
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        header = hbox();
        header.setBackgroundColor(PRI);
        header.setPadding(dp(16), dp(14), dp(16), dp(14));
        col.addView(header, new LinearLayout.LayoutParams(-1, -2));
        content = new FrameLayout(this);
        col.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = buildNav();
        col.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        fab = tv("", 15, Color.WHITE, true);
        fab.setBackground(round(PRI2, 28));
        fab.setPadding(dp(22), dp(14), dp(22), dp(14));
        fab.setElevation(dp(6));
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        fl.setMargins(0, 0, dp(16), dp(84));
        root.addView(fab, fl);
        setContentView(root);
        Backup.autoBackup(this);
        Sync.schedule(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        openTab(getIntent() != null ? getIntent().getIntExtra("tab", 0) : 0);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i != null && i.hasExtra("tab")) { reload(); openTab(i.getIntExtra("tab", 0)); }
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
        autoExport();
        if (!stack.isEmpty()) stack.get(stack.size() - 1).run();
        Sync.onChange = this::synced;
        Sync.hold = form;
        if (Sync.on(this) && System.currentTimeMillis() - Sync.lastRun > 20000) Sync.soon(this, 300);
        LIVE.removeCallbacks(liveTick);
        LIVE.postDelayed(liveTick, 15000);
        if (pendingRcpt >= 0) {
            final int pid = pendingRcpt;
            pendingRcpt = -1;
            content.postDelayed(() -> receiptBoth(pid), 400);
        } else if (pendingMailPid >= 0) {
            final int pid = pendingMailPid;
            pendingMailPid = -1;
            content.postDelayed(() -> new AlertDialog.Builder(this).setTitle("📧 Ahora por correo")
                    .setMessage("El recibo ya salió por WhatsApp. ¿Lo envío también por correo?")
                    .setPositiveButton("Enviar por correo", (d, w) -> receiptEmail(pid, null))
                    .setNegativeButton("No", null).show(), 400);
        }
    }

    boolean form = false, needReload = false;

    void formMode() { form = true; Sync.hold = true; }

    /** Llegaron cambios del equipo (pagos registrados por el Manager). */
    void synced() {
        if (form) { needReload = true; return; }
        reload();
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        LIVE.removeCallbacks(liveTick);
        Sync.onChange = null;
        Sync.hold = false;
    }

    /** Mientras la app está abierta: trae lo nuevo del Manager cada 15 segundos (si no estás llenando un formulario). */
    final android.os.Handler LIVE = new android.os.Handler(android.os.Looper.getMainLooper());
    final Runnable liveTick = new Runnable() {
        @Override
        public void run() {
            if (Sync.on(MainActivity.this) && !form && System.currentTimeMillis() - Sync.lastRun > 12000) Sync.soon(MainActivity.this, 0);
            LIVE.postDelayed(this, 15000);
        }
    };

    void reload() {
        tenants = Store.list(this, "tenants");
        recs = Store.list(this, "recs");
        detected = Store.list(this, "detected");
    }

    void saveAll() {
        Store.save(this, "tenants", tenants);
        Store.save(this, "recs", recs);
        Store.save(this, "detected", detected);
    }

    // ============================ navegación ============================
    void open(Runnable r) { stack.add(r); r.run(); }

    void openTab(int k) {
        tabSel = k;
        stack.clear();
        if (k == 0) open(this::monthScreen);
        else if (k == 1) open(this::tenantsScreen);
        else if (k == 2) open(this::etScreen);
        else if (k == 3) open(this::finScreen);
        else open(this::more);
    }

    void goBack() {
        if (stack.size() > 1) { stack.remove(stack.size() - 1); stack.get(stack.size() - 1).run(); }
        else if (tabSel != 0) openTab(0);
        else finish();
    }

    void refresh() { if (!stack.isEmpty()) stack.get(stack.size() - 1).run(); }

    @Override
    public void onBackPressed() { goBack(); }

    void setHeader(String title, String sub, String icon, boolean back) {
        header.removeAllViews();
        cobOn = "Ruta de cobranza".equals(title) ? "cob" : "";
        if (form) {
            form = false;
            Sync.hold = false;
            if (needReload) { needReload = false; reload(); }
            if (Sync.deferred) Sync.soon(this, 1500);
        }
        if (back) {
            TextView bk = tv("←", 24, Color.WHITE, true);
            bk.setPadding(dp(2), 0, dp(16), 0);
            bk.setOnClickListener(v -> goBack());
            header.addView(bk);
        } else if (icon != null) {
            TextView ic = tv(icon, 24, Color.WHITE, false);
            ic.setPadding(0, 0, dp(12), 0);
            header.addView(ic);
        }
        LinearLayout t = vbox();
        TextView tt = tv(title, 20, Color.WHITE, true);
        tt.setMaxLines(1);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        t.addView(tt);
        if (sub != null) t.addView(tv(sub, 13, 0xFFCFE0FF, false));
        header.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
    }

    void show(View body, boolean navOn, String fabText, Runnable fabAction) {
        content.removeAllViews();
        content.addView(body, new FrameLayout.LayoutParams(-1, -1));
        nav.setVisibility(navOn ? View.VISIBLE : View.GONE);
        if (fabText != null) {
            fab.setText(fabText);
            fab.setOnClickListener(v -> fabAction.run());
            fab.setVisibility(View.VISIBLE);
        } else fab.setVisibility(View.GONE);
        refreshNav();
    }

    static final String[][] TABS = {{"📅", "Mes"}, {"👥", "Inquilinos"}, {"📩", "e-Transfers"}, {"💰", "Finanzas"}, {"☰", "Más"}};

    LinearLayout buildNav() {
        LinearLayout n = hbox();
        n.setBackgroundColor(Color.WHITE);
        n.setElevation(dp(10));
        n.setPadding(dp(4), dp(4), dp(4), dp(4));
        for (int i = 0; i < TABS.length; i++) {
            final int k = i;
            LinearLayout it = vbox();
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, dp(6), 0, dp(6));
            TextView ic = tv(TABS[i][0], 19, TXT, false);
            ic.setGravity(Gravity.CENTER);
            TextView lb = tv(TABS[i][1], 11, MUT, false);
            lb.setGravity(Gravity.CENTER);
            it.addView(ic);
            it.addView(lb);
            it.setTag(lb);
            it.setOnClickListener(v -> openTab(k));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            n.addView(it, lp);
        }
        return n;
    }

    void refreshNav() {
        for (int i = 0; i < nav.getChildCount(); i++) {
            View it = nav.getChildAt(i);
            TextView lb = (TextView) it.getTag();
            boolean s = i == tabSel;
            lb.setTextColor(s ? PRI2 : MUT);
            lb.setTypeface(s ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            it.setBackground(s ? round(0xFFEAF1FF, 12) : null);
        }
    }

    // ============================ cálculos ============================
    String money(double v) { return Store.money(this, v); }

    List<JSONObject> activeTenants(String m) {
        List<JSONObject> r = new ArrayList<>();
        for (JSONObject t : tenants) if (Store.activeIn(t, m)) r.add(t);
        return r;
    }

    /** 0 pagado, 1 parcial (pagó una parte, aunque esté atrasado), 2 pendiente, 3 atrasado (no ha pagado nada) */
    int status(JSONObject t, String m) {
        JSONObject r = Store.rec(recs, t.optInt("id"), m, false);
        double due = Store.due(t, r), pd = Store.paid(r);
        if (pd >= due - 0.009) return 0;
        if (pd > 0.009) return 1;
        return lateDays(t, m) > 0 ? 3 : 2;
    }

    /** Días de atraso si todavía debe algo y ya pasó la fecha (más los días de gracia); 0 si no está atrasado. */
    int lateDays(JSONObject t, String m) {
        JSONObject r = Store.rec(recs, t.optInt("id"), m, false);
        if (Store.paid(r) >= Store.due(t, r) - 0.009) return 0;
        int d = Store.daysBetween(Store.dueDate(t, m, this), Store.today());
        return d > Store.getI(this, "grace", 0) ? d : 0;
    }

    static final String[] ST_NAMES = {"Pagado", "Parcial", "Pendiente", "Atrasado"};
    static final int[][] ST_COL = {{0xFFA16207, 0xFFFEF9C3}, {0xFF15803D, 0xFFDCFCE7}, {0xFFDC2626, 0xFFFEE2E2}, {0xFF991B1B, 0xFFFECACA}}; // amarillo = pagado completo, verde = parcial, rojo = no ha pagado (atrasado: rojo más fuerte)
    static final String[] ST_ICON = {"🟡", "🟢", "🔴", "⛔"};

    long lastPaymentDate(JSONObject r) {
        long l = 0;
        if (r == null) return 0;
        JSONArray p = r.optJSONArray("payments");
        if (p != null) for (int i = 0; i < p.length(); i++) { JSONObject x = p.optJSONObject(i); if (x != null) l = Math.max(l, x.optLong("date")); }
        return l;
    }

    String statusLine(JSONObject t, String m) {
        JSONObject r = Store.rec(recs, t.optInt("id"), m, false);
        int s = status(t, m);
        double owed = Store.due(t, r) - Store.paid(r);
        String dd = Store.dueDate(t, m, this);
        if (s == 0) return "✅ Pagado" + (lastPaymentDate(r) > 0 ? " el " + Store.shortDate(Store.dayOf(lastPaymentDate(r))) : "");
        if (s == 3) {
            int d = Store.daysBetween(dd, Store.today());
            return "🔴 Atrasado " + d + (d == 1 ? " día" : " días") + " · faltan " + money(owed);
        }
        if (s == 1) {
            int d = lateDays(t, m);
            return "🟡 Parcial · faltan " + money(owed) + (d > 0 ? " · atrasado " + d + (d == 1 ? " día" : " días") : "");
        }
        return "⏳ Vence el " + Store.shortDate(dd);
    }

    // ============================ pantalla del mes ============================
    void monthScreen() {
        List<JSONObject> act = activeTenants(month);
        setHeader("Rentas · " + Store.monthName(month), act.size() + " inquilinos", "📅", false);
        LinearLayout p = vbox();

        LinearLayout mn = hbox();
        mn.setPadding(dp(14), dp(10), dp(14), 0);
        TextView prev = tv("‹", 28, PRI2, true);
        prev.setPadding(dp(14), 0, dp(14), 0);
        prev.setOnClickListener(v -> { month = Store.addMonth(month, -1); monthScreen(); });
        TextView ml = tv(Store.monthName(month), 18, TXT, true);
        ml.setGravity(Gravity.CENTER);
        TextView next = tv("›", 28, PRI2, true);
        next.setPadding(dp(14), 0, dp(14), 0);
        next.setOnClickListener(v -> { month = Store.addMonth(month, 1); monthScreen(); });
        mn.addView(prev);
        mn.addView(ml, new LinearLayout.LayoutParams(0, -2, 1f));
        mn.addView(next);
        p.addView(mn);
        if (!month.equals(Store.thisMonth())) {
            TextView hoy = tv("Volver al mes actual", 13, PRI2, true);
            hoy.setGravity(Gravity.CENTER);
            hoy.setOnClickListener(v -> { month = Store.thisMonth(); monthScreen(); });
            p.addView(hoy, new LinearLayout.LayoutParams(-1, -2));
        }

        double exp = 0, got = 0, expU = 0;
        int[] cnt = new int[4];
        for (JSONObject t : act) {
            JSONObject r = Store.rec(recs, t.optInt("id"), month, false);
            exp += Store.due(t, r);
            expU += Store.utilDue(t, r);
            got += Math.min(Store.paid(r), Store.due(t, r));
            cnt[status(t, month)]++;
        }
        LinearLayout big = card();
        big.setBackground(round(PRI, 18));
        LinearLayout r1 = hbox();
        r1.addView(bigNum("Esperado", money(exp), Color.WHITE), new LinearLayout.LayoutParams(0, -2, 1f));
        r1.addView(bigNum("Cobrado", money(got), 0xFFFDE047), new LinearLayout.LayoutParams(0, -2, 1f));
        r1.addView(bigNum("Falta", money(exp - got), 0xFFFCA5A5), new LinearLayout.LayoutParams(0, -2, 1f));
        big.addView(r1);
        LinearLayout bar = hbox();
        bar.setBackground(round(0x33FFFFFF, 6));
        bar.setClipToOutline(true);
        float pct = exp > 0 ? (float) (got / exp) : 0;
        View fill = new View(this);
        fill.setBackgroundColor(0xFFFACC15);
        bar.addView(fill, new LinearLayout.LayoutParams(0, dp(10), Math.max(pct, 0.0001f)));
        bar.addView(new View(this), new LinearLayout.LayoutParams(0, dp(10), Math.max(1 - pct, 0.0001f)));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(10));
        bl.setMargins(0, dp(12), 0, dp(4));
        big.addView(bar, bl);
        big.addView(tv(Math.round(pct * 100) + "% cobrado" + (expU > 0 ? " · Renta " + money(exp - expU) + " + Utilidades " + money(expU) : ""), 12, 0xFFCFE0FF, true));
        p.addView(big);

        LinearLayout chips = hbox();
        chips.setPadding(dp(10), dp(4), dp(10), 0);
        String[] fs = {"Todos", "Faltan", "Pagado", "Parcial", "Pendiente", "Atrasado"};
        for (String o : fs) {
            String lbl = o;
            if (o.equals("Todos")) lbl = "Todos (" + act.size() + ")";
            else if (o.equals("Faltan")) lbl = "Faltan por pagar (" + (cnt[1] + cnt[2] + cnt[3]) + ")";
            else for (int i = 0; i < 4; i++) if (ST_NAMES[i].equals(o)) lbl = ST_ICON[i] + " " + o + " (" + cnt[i] + ")";
            chips.addView(chip(lbl, o.equals(filter), v -> { filter = o; monthScreen(); }));
        }
        p.addView(hscroll(chips));

        TextView pf = field("🏠  " + (propFilter.isEmpty() ? "Todas las propiedades" : propFilter) + "  ▾");
        ((LinearLayout.LayoutParams) pf.getLayoutParams()).setMargins(dp(14), dp(6), dp(14), 0);
        pf.setOnClickListener(x -> {
            List<String> ps = properties();
            ps.add(0, "Todas las propiedades");
            new AlertDialog.Builder(this).setTitle("Propiedad").setItems(ps.toArray(new String[0]), (dlg, w) -> {
                propFilter = w == 0 ? "" : ps.get(w);
                monthScreen();
            }).show();
        });
        p.addView(pf);
        EditText s = input("🔍  Buscar inquilino o cuarto", InputType.TYPE_CLASS_TEXT);
        s.setText(search);
        ((LinearLayout.LayoutParams) s.getLayoutParams()).setMargins(dp(14), dp(6), dp(14), dp(4));
        p.addView(s);
        final LinearLayout list = vbox();
        p.addView(list);
        final Runnable fillList = () -> {
            list.removeAllViews();
            String q = Store.norm(search);
            List<JSONObject> l = new ArrayList<>();
            for (JSONObject t : act) {
                int st = status(t, month);
                if (filter.equals("Faltan") && st == 0) continue;
                if (!filter.equals("Todos") && !filter.equals("Faltan") && !ST_NAMES[st].equals(filter)) continue;
                if (!propFilter.isEmpty() && !Store.norm(t.optString("property")).equals(Store.norm(propFilter))) continue;
                if (!q.isEmpty() && !Store.norm(t.optString("name") + " " + t.optString("property") + " " + room(t) + " " + t.optString("code")).contains(q)) continue;
                l.add(t);
            }
            Collections.sort(l, (x, y) -> {
                int a = order(status(x, month)), c = order(status(y, month));
                if (a != c) return Integer.compare(a, c);
                return (x.optString("property") + x.optString("unit") + x.optString("name"))
                        .compareToIgnoreCase(y.optString("property") + y.optString("unit") + y.optString("name"));
            });
            if (tenants.isEmpty()) list.addView(empty("Todavía no hay inquilinos.\nAgrégalos en 👥 Inquilinos, o pega tu lista desde Excel en Más → Importar lista."));
            else if (l.isEmpty()) list.addView(empty("No hay inquilinos con este filtro"));
            for (JSONObject t : l) list.addView(monthRow(t));
        };
        s.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable e) { search = e.toString(); fillList.run(); }
        });
        fillList.run();
        show(scroll(p), true, "＋  Registrar pago", () -> pickTenant(month, id -> open(() -> payScreen(Integer.parseInt(id), month))));
    }

    static int order(int st) { return st == 3 ? 0 : st == 1 ? 1 : st == 2 ? 2 : 3; }

    View bigNum(String label, String value, int color) {
        LinearLayout b = vbox();
        b.addView(tv(label, 12, 0xFFCFE0FF, true));
        TextView v = tv(value, 18, color, true);
        v.setMaxLines(1);
        b.addView(v);
        return b;
    }

    View monthRow(JSONObject t) {
        int st = status(t, month);
        JSONObject r = Store.rec(recs, t.optInt("id"), month, false);
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        TextView ic = tv(ST_ICON[st], 20, TXT, false);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(round(ST_COL[st][1], 12));
        c.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout v = vbox();
        v.setPadding(dp(12), 0, dp(6), 0);
        TextView nm = tv(t.optString("name"), 16, TXT, true);
        nm.setMaxLines(1);
        nm.setEllipsize(TextUtils.TruncateAt.END);
        v.addView(nm);
        String where = where(t);
        if (!where.isEmpty()) { TextView w = tv(where, 13, MUT, false); w.setMaxLines(1); w.setEllipsize(TextUtils.TruncateAt.END); v.addView(w); }
        v.addView(tv(statusLine(t, month), 13, ST_COL[st][0], true));
        if (r != null && !r.optString("promise").isEmpty() && st != 0)
            v.addView(tv("🤝 Prometió pagar el " + Store.shortDate(r.optString("promise")), 13, PRI2, true));
        c.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout g = vbox();
        g.setGravity(Gravity.END);
        g.addView(tv(money(Store.due(t, r)), 15, TXT, true));
        if (Store.paid(r) > 0.009 && st != 0) g.addView(tv("pagó " + money(Store.paid(r)), 12, GRN, true));
        c.addView(g);
        final int id = t.optInt("id");
        final String m = month;
        c.setOnClickListener(x -> open(() -> payScreen(id, m)));
        return c;
    }

    void pickTenant(String m, Cb cb) {
        List<JSONObject> l = activeTenants(m);
        if (l.isEmpty()) { toast("Primero agrega inquilinos"); return; }
        Collections.sort(l, (x, y) -> {
            int a = order(status(x, m)), b = order(status(y, m));
            return a != b ? Integer.compare(a, b) : x.optString("name").compareToIgnoreCase(y.optString("name"));
        });
        String[] names = new String[l.size()];
        for (int i = 0; i < names.length; i++) {
            JSONObject t = l.get(i);
            names[i] = ST_ICON[status(t, m)] + " " + t.optString("name") + (where(t).isEmpty() ? "" : " · " + where(t));
        }
        new AlertDialog.Builder(this).setTitle("Elige el inquilino")
                .setItems(names, (dlg, w) -> cb.on(String.valueOf(l.get(w).optInt("id")))).show();
    }

    // ============================ pago / seguimiento de un inquilino ============================
    void payScreen(int tid, String m) {
        final JSONObject t = Store.tenant(tenants, tid);
        if (t == null) { goBack(); return; }
        final JSONObject r0 = Store.rec(recs, tid, m, false);
        int st = status(t, m);
        double due = Store.due(t, r0), pd = Store.paid(r0), owed = Math.max(0, due - pd);
        setHeader(t.optString("name"), Store.monthName(m), null, true);
        formMode();
        LinearLayout p = vbox();

        LinearLayout c = card();
        c.setBackground(round(ST_COL[st][1], 16));
        c.addView(tv(statusLine(t, m), 17, ST_COL[st][0], true));
        String where = where(t);
        if (!where.isEmpty()) c.addView(tv("🏠 " + where, 14, TXT, false));
        c.addView(divider());
        double rd = Store.rentDue(t, r0), ud = Store.utilDue(t, r0);
        c.addView(kv("Renta", money(rd)));
        c.addView(kv("Utilidades", money(ud)));
        c.addView(kv("Total del mes", money(due), PRI));
        c.addView(kv("Pagado", money(pd), GRN));
        c.addView(kv("Falta", money(owed), owed > 0.009 ? RED : GRN));
        if (pd - due > 0.009) c.addView(kv("💚 Crédito a favor", money(pd - due), GRN));
        c.addView(kv("Fecha de pago", Store.shortDate(Store.dueDate(t, m, this))));
        TextView chg = tv("✏️ Cambiar renta o utilidades solo para este mes", 13, PRI2, true);
        chg.setPadding(0, dp(8), 0, 0);
        chg.setOnClickListener(v -> {
            EditText e = input("Renta", DEC);
            e.setText(qty(rd));
            EditText eu = input("Utilidades", DEC);
            eu.setText(qty(ud));
            LinearLayout box = vbox();
            box.setPadding(dp(20), dp(4), dp(20), 0);
            box.addView(labeled("Renta de " + Store.monthName(m).toLowerCase(Store.ES), e));
            box.addView(labeled("Utilidades de " + Store.monthName(m).toLowerCase(Store.ES), eu));
            new AlertDialog.Builder(this).setTitle("Montos solo de " + Store.monthName(m)).setView(box)
                    .setPositiveButton("Guardar", (dlg, w) -> {
                        JSONObject rr = Store.rec(recs, tid, m, true);
                        Store.put(rr, "due", num(e.getText().toString()));
                        Store.put(rr, "util", num(eu.getText().toString()));
                        saveAll();
                        refresh();
                    })
                    .setNeutralButton("Usar los montos normales", (dlg, w) -> {
                        JSONObject rr = Store.rec(recs, tid, m, false);
                        if (rr != null) { rr.remove("due"); rr.remove("util"); }
                        saveAll();
                        refresh();
                    })
                    .setNegativeButton("Cancelar", null).show();
        });
        c.addView(chg);
        p.addView(c);

        JSONArray pays = r0 == null ? null : r0.optJSONArray("payments");
        if (pays != null && pays.length() > 0) {
            p.addView(sectionTitle("Pagos de " + Store.monthName(m).toLowerCase(Store.ES), null, null));
            LinearLayout pc = card();
            for (int i = 0; i < pays.length(); i++) {
                final JSONObject x = pays.optJSONObject(i);
                if (x == null) continue;
                if (pc.getChildCount() > 0) pc.addView(divider());
                LinearLayout row = hbox();
                if (!x.optString("img").isEmpty()) {
                    ImageView th = new ImageView(this);
                    th.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    th.setBackground(round(0xFFE1E7EF, 10));
                    th.setClipToOutline(true);
                    LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(dp(46), dp(46));
                    tl.setMargins(0, 0, dp(10), 0);
                    row.addView(th, tl);
                    loadThumb(th, Uri.parse(x.optString("img")));
                }
                LinearLayout tx = vbox();
                tx.addView(tv((x.optString("source").equals("auto") ? "📩 " : "💵 ") + money(x.optDouble("amount", 0)) + " · " + x.optString("method"), 15, TXT, true));
                if (!x.optString("recv").isEmpty()) tx.addView(tv("🤝 Lo recibió " + x.optString("recv"), 13, 0xFF15803D, true));
                tx.addView(tv(Store.dateTime(x.optLong("date")) + (x.optString("ref").isEmpty() ? "" : " · " + x.optString("ref")), 12, MUT, false));
                tx.addView(tv(x.optString("img").isEmpty() ? "📷 Toca para agregar el comprobante" : "🧾 Con comprobante · toca para verlo", 12,
                        x.optString("img").isEmpty() ? PRI2 : 0xFF15803D, true));
                String sl = Store.qbo(this) ? Store.syncLabel(x.optString("syncStatus")) : "";
                if (!sl.isEmpty()) tx.addView(tv(sl, 12, x.optString("syncStatus").equals("error") ? RED : MUT, false));
                row.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
                row.setOnClickListener(v -> payMenu(x));
                pc.addView(row);
            }
            p.addView(pc);
        }

        String key = tid + "|" + m;
        if (!key.equals(formKey)) {
            formKey = key;
            formAmt = null;
            formRef = "";
            formMethod = METHODS[0];
            formImg = "";
            formRecv = null;
            formDate = System.currentTimeMillis();
        }
        p.addView(sectionTitle("💵 Registrar pago", null, null));
        LinearLayout f = card();
        EditText amt = input("Monto", DEC);
        amt.setText(formAmt != null ? formAmt : (owed > 0.009 ? qty(owed) : ""));
        final long[] date = {formDate};
        final String[] method = {formMethod};
        EditText ref = input("Referencia o nota (opcional)", InputType.TYPE_CLASS_TEXT);
        ref.setText(formRef);
        watch(amt, () -> formAmt = amt.getText().toString());
        watch(ref, () -> formRef = ref.getText().toString());
        // en efectivo: quién recibió el dinero
        LinearLayout cashBox = vbox();
        EditText recv = input("Nombre de quien recibió el efectivo", TXT_CAP);
        recv.setText(formRecv != null ? formRecv : Store.get(this, "lastRecv", ""));
        watch(recv, () -> formRecv = recv.getText().toString());
        cashBox.addView(label("🤝", "¿Quién recibió el efectivo?", true));
        cashBox.addView(recv);
        List<String> rn = recvNames();
        if (!rn.isEmpty()) {
            LinearLayout rc = hbox();
            for (String n : rn) rc.addView(chip(n, false, v -> { recv.setText(n); recv.setSelection(n.length()); }));
            cashBox.addView(hscroll(rc));
        }
        cashBox.setVisibility(CASH.equals(method[0]) ? View.VISIBLE : View.GONE);
        f.addView(twoCols(labeled("Monto (" + Store.get(this, "cur", "$") + ")", amt), dateField(date)));
        f.addView(label("💳", "Forma de pago", false));
        LinearLayout mr = hbox();
        final TextView[] mc = new TextView[METHODS.length];
        for (int i = 0; i < METHODS.length; i++) {
            final int j = i;
            mc[i] = chip(METHODS[i], METHODS[i].equals(method[0]), v -> {
                method[0] = METHODS[j];
                formMethod = METHODS[j];
                for (int k = 0; k < mc.length; k++) styleChip(mc[k], k == j);
                cashBox.setVisibility(CASH.equals(METHODS[j]) ? View.VISIBLE : View.GONE);
            });
            mr.addView(mc[i]);
        }
        f.addView(hscroll(mr));
        f.addView(cashBox);
        f.addView(ref);
        f.addView(label("🧾", "Comprobante (foto o captura del pago)", false));
        if (!formImg.isEmpty()) {
            LinearLayout ir = hbox();
            ImageView pv = new ImageView(this);
            pv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            pv.setBackground(round(0xFFE1E7EF, 12));
            pv.setClipToOutline(true);
            ir.addView(pv, new LinearLayout.LayoutParams(dp(90), dp(90)));
            loadThumb(pv, Uri.parse(formImg));
            pv.setOnClickListener(v -> viewImage(formImg));
            LinearLayout iv = vbox();
            iv.setPadding(dp(12), 0, 0, 0);
            iv.addView(tv("✅ Comprobante listo", 14, 0xFF15803D, true));
            TextView rm = tv("Quitar", 14, RED, true);
            rm.setPadding(0, dp(8), 0, 0);
            rm.setOnClickListener(v -> { formImg = ""; refresh(); });
            iv.addView(rm);
            ir.addView(iv, new LinearLayout.LayoutParams(0, -2, 1f));
            LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(-1, -2);
            il.setMargins(0, dp(6), 0, 0);
            f.addView(ir, il);
        } else {
            LinearLayout ib = hbox();
            ib.setPadding(0, dp(6), 0, 0);
            ib.addView(smallBtn("📷 Tomar foto", PRI2, v -> { pendingPayId = -1; movPhoto = false; formDate = date[0]; capture(); }), weightLp(1f));
            ib.addView(smallBtn("🖼️ De la galería", PRI2, v -> { pendingPayId = -1; movPhoto = false; formDate = date[0]; pickImage(); }), weightLp(1f));
            f.addView(ib);
        }
        p.addView(f);
        p.addView(button("💵  Guardar pago", GRN, v -> {
            double a = num(amt.getText().toString());
            if (a <= 0) { toast("Escribe el monto"); return; }
            String rv = recv.getText().toString().trim();
            if (CASH.equals(method[0]) && rv.isEmpty()) { toast("Escribe quién recibió el efectivo"); recv.requestFocus(); return; }
            JSONObject rr = Store.rec(recs, tid, m, true);
            JSONObject x = new JSONObject();
            Store.put(x, "id", Store.nextId(this));
            Store.put(x, "amount", a);
            Store.put(x, "date", date[0]);
            Store.put(x, "method", method[0]);
            Store.put(x, "source", "manual");
            Store.put(x, "ref", ref.getText().toString().trim());
            if (CASH.equals(method[0])) { Store.put(x, "recv", rv); rememberRecv(rv); }
            if (!formImg.isEmpty()) Store.put(x, "img", formImg);
            Store.stamp(this, x);
            rr.optJSONArray("payments").put(x);
            formKey = "";
            saveAll();
            if (Store.due(t, rr) - Store.paid(rr) <= 0.009) Store.cancelPromise(this, tid);
            toast("Pago guardado ✅");
            refresh();
            if (Store.getB(this, "askMgr", true)) afterPayment(x.optInt("id"));
        }));

        if (owed > 0.009) {
            p.addView(sectionTitle("📌 Seguimiento", null, null));
            LinearLayout sc = card();
            final String prom = r0 == null ? "" : r0.optString("promise");
            TextView pf = field(prom.isEmpty() ? "📅  ¿Cuándo dijo que pagará?" : "🤝  Pagará el " + Store.shortDate(prom) + "  (tocar para cambiar)");
            pf.setOnClickListener(v -> pickDate(prom.isEmpty() ? Store.today() : prom, iso -> {
                JSONObject rr = Store.rec(recs, tid, m, true);
                Store.put(rr, "promise", iso);
                saveAll();
                Store.schedulePromise(this, t, rr);
                toast("Te aviso ese día a las 9 AM 🔔");
                refresh();
            }));
            sc.addView(labeled("Fecha prometida", pf));
            if (!prom.isEmpty()) {
                TextView clr = tv("Quitar fecha prometida", 13, RED, true);
                clr.setPadding(0, dp(6), 0, 0);
                clr.setOnClickListener(v -> {
                    Store.put(r0, "promise", "");
                    Store.cancelPromise(this, tid);
                    saveAll();
                    refresh();
                });
                sc.addView(clr);
            }
            EditText notes = input("Notas del seguimiento (ej. pagará en dos partes)", TXT_MULTI);
            notes.setText(r0 == null ? "" : r0.optString("notes"));
            sc.addView(label("📝", "Notas de este mes", false));
            sc.addView(notes);
            TextView sv = tv("Guardar notas", 14, PRI2, true);
            sv.setPadding(0, dp(8), 0, 0);
            sv.setOnClickListener(v -> {
                JSONObject rr = Store.rec(recs, tid, m, true);
                Store.put(rr, "notes", notes.getText().toString().trim());
                saveAll();
                toast("Notas guardadas");
            });
            sc.addView(sv);
            p.addView(sc);
            LinearLayout b2 = hbox();
            b2.setPadding(dp(8), dp(6), dp(8), 0);
            final String phone = t.optString("phone");
            b2.addView(outline("💬  Recordar por WhatsApp", GRN, v -> {
                if (phone.replaceAll("[^0-9]", "").isEmpty()) { toast("Agrega el teléfono del inquilino"); return; }
                launch(Store.waIntent(this, phone, Store.reminderText(this, t, m, owed)));
            }), weightLp(1.4f));
            b2.addView(outline("📞  Llamar", PRI2, v -> {
                if (phone.isEmpty()) { toast("Agrega el teléfono del inquilino"); return; }
                launch(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone)));
            }), weightLp(1f));
            p.addView(b2);
        }
        TextView ficha = tv("👤  Ver ficha e historial del inquilino ›", 14, PRI2, true);
        ficha.setPadding(dp(18), dp(18), dp(18), 0);
        ficha.setOnClickListener(v -> open(() -> tenantDetail(tid)));
        p.addView(ficha);
        show(scroll(p), false, null, null);
    }

    // ============================ manager ============================
    String mgrName() { return Store.get(this, "mgrName", "Manager"); }

    void sendToManager(String text, Uri file, String mime) {
        String phone = Store.get(this, "mgrPhone", "+16047678650");
        if (phone.replaceAll("[^0-9]", "").isEmpty()) { toast("Agrega el WhatsApp del manager en Más → Ajustes"); return; }
        waSend(phone, text, file, mime);
    }

    /** WhatsApp con el texto y la foto: la persona elige a quién mandarlo. */
    void waShareAny(String text, Uri file) {
        String pref = Store.get(this, "waApp", "business").equals("business") ? "com.whatsapp.w4b" : "com.whatsapp";
        String pkg = Store.installed(this, pref) ? pref : Store.installed(this, "com.whatsapp") ? "com.whatsapp" : Store.installed(this, "com.whatsapp.w4b") ? "com.whatsapp.w4b" : null;
        Intent i = new Intent(Intent.ACTION_SEND);
        i.putExtra(Intent.EXTRA_TEXT, text);
        if (file != null) { i.setType("image/*"); i.putExtra(Intent.EXTRA_STREAM, file); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        else i.setType("text/plain");
        if (pkg != null) { Intent w = new Intent(i); w.setPackage(pkg); try { startActivity(w); return; } catch (Exception ignored) { } }
        launch(Intent.createChooser(i, "Compartir"));
    }

    /** Texto de un gasto o ingreso para compartir. */
    String movText(JSONObject x) {
        boolean out = !"in".equals(x.optString("type"));
        StringBuilder b = new StringBuilder(out ? "🔻 *Egreso*\n" : "🔺 *Ingreso*\n");
        b.append("💲 ").append(money(x.has("amount") ? x.optDouble("amount", 0) : num(x.optString("amountS")))).append("\n");
        if (!x.optString("date").isEmpty()) b.append("📅 ").append(Store.shortDate(x.optString("date"))).append("\n");
        if (!x.optString("cat").isEmpty()) b.append("🏷️ ").append(x.optString("cat")).append("\n");
        String pr = x.optString("prop").trim();
        b.append("🏠 ").append(!pr.isEmpty() ? pr : !x.optString("otherFor").isEmpty() ? x.optString("otherFor") : x.optString("owner", "General")).append("\n");
        if (!x.optString("method").isEmpty()) b.append("💳 ").append(x.optString("method")).append("\n");
        if (!x.optString("desc").trim().isEmpty()) b.append("📝 ").append(x.optString("desc").trim()).append("\n");
        if (!x.optString("img").isEmpty()) b.append("🧾 ").append(out ? "Recibo adjunto" : "Comprobante adjunto").append("\n");
        b.append("\n— Rentas Amigo Renta");
        return b.toString();
    }

    /** Abre el chat de WhatsApp de ese número con el texto y (si se puede) el archivo adjunto. Devuelve true si abrió WhatsApp. */
    boolean waSend(String phone, String text, Uri file, String mime) {
        String d = phone.replaceAll("[^0-9]", "");
        if (d.length() == 10) d = "1" + d;
        String pref = Store.get(this, "waApp", "business").equals("business") ? "com.whatsapp.w4b" : "com.whatsapp";
        String pkg = Store.installed(this, pref) ? pref : Store.installed(this, "com.whatsapp") ? "com.whatsapp" : Store.installed(this, "com.whatsapp.w4b") ? "com.whatsapp.w4b" : null;
        if (pkg != null) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setPackage(pkg);
            i.putExtra("jid", d + "@s.whatsapp.net");
            i.putExtra(Intent.EXTRA_TEXT, text);
            if (file != null) {
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, file);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } else i.setType("text/plain");
            try { startActivity(i); return true; } catch (Exception ignored) { }
        }
        if (file != null) toast("Se envía solo el texto. Comparte el archivo aparte.");
        launch(Store.waIntent(this, phone, text));
        return true;
    }

    // ============================ recibo al inquilino ============================
    void afterPayment(int pid) {
        List<String> o = new ArrayList<>();
        o.add("📄 Recibo PDF al inquilino (WhatsApp y correo)");
        o.add("👔 Datos del pago al " + mgrName());
        o.add("Las dos cosas");
        new AlertDialog.Builder(this).setTitle("Pago guardado ✅  ¿Qué envío?")
                .setItems(o.toArray(new String[0]), (d, w) -> {
                    if (w == 0) receiptBoth(pid);
                    else if (w == 1) sendPayment(pid);
                    else { sendPayment(pid); pendingRcpt = pid; }
                })
                .setNegativeButton("Nada por ahora", null).show();
    }
    int pendingRcpt = -1;

    Uri receiptUri(int pid) {
        JSONObject x = findPayment(pid), r = recOfPayment(pid);
        if (x == null || r == null) { toast("No encontré el pago"); return null; }
        JSONObject t = Store.tenant(tenants, r.optInt("tid"));
        if (t == null) { toast("No encontré el inquilino"); return null; }
        Uri u = Recibo.make(this, t, r, x);
        if (u == null) toast("No se pudo crear el PDF (necesita Android 10 o más nuevo)");
        return u;
    }

    String receiptText(int pid) {
        JSONObject x = findPayment(pid), r = recOfPayment(pid);
        JSONObject t = r == null ? null : Store.tenant(tenants, r.optInt("tid"));
        if (x == null || t == null) return "";
        double bal = Store.due(t, r) - Store.paid(r);
        String first = t.optString("name").trim().split("\\s+")[0];
        String m = Store.monthT(this, r.optString("month"));
        if (Store.en(this))
            return "Hi " + first + ", this is Amigo Renta. We have received your payment of " + money(x.optDouble("amount", 0))
                    + " for " + m + ". "
                    + (bal > 0.009 ? "Remaining balance: " + money(bal) + ". " : bal < -0.009 ? "Your rent is paid in full and you have a credit of " + money(-bal) + " that will be applied to your next invoice. " : "Your rent is paid in full. ")
                    + "Please find your receipt attached (PDF). Thank you!";
        return "Hola " + first + ", te escribimos de Amigo Renta. Recibimos tu pago de " + money(x.optDouble("amount", 0))
                + " de " + m + ". "
                + (bal > 0.009 ? "Saldo pendiente: " + money(bal) + ". " : bal < -0.009 ? "Tu renta quedó pagada y tienes " + money(-bal) + " de crédito a favor para la próxima factura. " : "Tu renta quedó pagada. ")
                + "Te adjuntamos el recibo en PDF. ¡Gracias!";
    }

    void receiptMenu(int pid) {
        String[] o = {"📲 WhatsApp y 📧 correo (las dos)", "📲 Solo WhatsApp", "📧 Solo correo", "👀 Ver el PDF"};
        new AlertDialog.Builder(this).setTitle("📄 Recibo PDF").setItems(o, (d, w) -> {
            if (w == 0) receiptBoth(pid);
            else if (w == 1) receiptWa(pid, null);
            else if (w == 2) receiptEmail(pid, null);
            else {
                Uri u = receiptUri(pid);
                if (u == null) return;
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(u, "application/pdf");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                launch(i);
            }
        }).show();
    }

    void receiptBoth(int pid) {
        JSONObject r = recOfPayment(pid);
        JSONObject t = r == null ? null : Store.tenant(tenants, r.optInt("tid"));
        if (t == null) { toast("No encontré el inquilino"); return; }
        boolean hasWa = !t.optString("phone").replaceAll("[^0-9]", "").isEmpty(), hasMail = t.optString("email").contains("@");
        if (!hasWa && !hasMail) { toast("Agrega el teléfono o el correo del inquilino"); return; }
        Uri u = receiptUri(pid);
        if (u == null) return;
        if (hasWa) {
            if (hasMail) pendingMailPid = pid;
            else toast("No tiene correo guardado: se envía solo por WhatsApp");
            receiptWa(pid, u);
        } else {
            toast("No tiene WhatsApp guardado: se envía solo por correo");
            receiptEmail(pid, u);
        }
    }

    void receiptWa(int pid, Uri u) {
        JSONObject r = recOfPayment(pid);
        JSONObject t = r == null ? null : Store.tenant(tenants, r.optInt("tid"));
        if (t == null) return;
        if (t.optString("phone").replaceAll("[^0-9]", "").isEmpty()) { toast("Agrega el teléfono del inquilino"); return; }
        if (u == null) u = receiptUri(pid);
        if (u == null) return;
        markSent(pid, "rcptWa");
        waSend(t.optString("phone"), receiptText(pid), u, "application/pdf");
    }

    void receiptEmail(int pid, Uri u) {
        JSONObject r = recOfPayment(pid);
        JSONObject t = r == null ? null : Store.tenant(tenants, r.optInt("tid"));
        if (t == null) return;
        if (!t.optString("email").contains("@")) { toast("Agrega el correo del inquilino"); return; }
        if (u == null) u = receiptUri(pid);
        if (u == null) return;
        JSONObject x = findPayment(pid);
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_EMAIL, new String[]{t.optString("email")});
        i.putExtra(Intent.EXTRA_SUBJECT, (Store.en(this) ? "Payment receipt " : "Recibo de pago ") + Recibo.number(x) + " · Amigo Renta · " + (Store.en(this) ? Store.monthNameEn(r.optString("month")) : Store.monthName(r.optString("month"))));
        i.putExtra(Intent.EXTRA_TEXT, receiptText(pid) + "\n\nAmigo Renta\n+1 604-767-8650 · amigorenta.com");
        i.putExtra(Intent.EXTRA_STREAM, u);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        markSent(pid, "rcptMail");
        launch(Intent.createChooser(i, "Enviar recibo por correo"));
    }

    void markSent(int pid, String k) {
        JSONObject x = findPayment(pid);
        if (x != null) { Store.put(x, k, System.currentTimeMillis()); Store.save(this, "recs", recs); }
    }

    void sendPayment(int pid) {
        String tx = payText(pid);
        if (tx == null) return;
        JSONObject x = findPayment(pid);
        boolean img = x != null && !x.optString("img").isEmpty();
        sendToManager(tx, img ? Uri.parse(x.optString("img")) : null, "image/*");
    }

    /** Texto del pago (para el Manager o para compartir por WhatsApp). */
    String payText(int pid) {
        JSONObject x = findPayment(pid);
        JSONObject r = recOfPayment(pid);
        if (x == null || r == null) { toast("No encontré el pago"); return null; }
        JSONObject t = Store.tenant(tenants, r.optInt("tid"));
        if (t == null) { toast("No encontré el inquilino"); return null; }
        String m = r.optString("month");
        double due = Store.due(t, r), pd = Store.paid(r), owed = due - pd;
        StringBuilder b = new StringBuilder("💵 *Pago recibido*\n");
        b.append("👤 ").append(t.optString("name")).append("\n");
        if (!where(t).isEmpty()) b.append("🏠 ").append(where(t)).append("\n");
        b.append("💲 ").append(money(x.optDouble("amount", 0))).append(" · ").append(x.optString("method"))
                .append(x.optString("source").equals("auto") ? " (automático)" : "").append("\n");
        if (!x.optString("recv").isEmpty()) b.append("🤝 Recibió el efectivo: ").append(x.optString("recv")).append("\n");
        b.append("📅 ").append(Store.dateTime(x.optLong("date"))).append("\n");
        b.append("🗓️ ").append(Store.monthName(m)).append(": renta ").append(money(Store.rentDue(t, r)))
                .append(Store.utilDue(t, r) > 0 ? " + utilidades " + money(Store.utilDue(t, r)) : "").append("\n");
        b.append("✔️ Pagado ").append(money(pd))
                .append(" de ").append(money(due)).append(owed <= 0.009 ? " ✅ completo" : " · falta " + money(owed)).append("\n");
        if (!x.optString("ref").isEmpty()) b.append("📝 ").append(x.optString("ref")).append("\n");
        boolean img = !x.optString("img").isEmpty();
        if (img) b.append("🧾 Comprobante adjunto\n");
        b.append("\n— Rentas Amigo Renta");
        return b.toString();
    }

    String tenantText(JSONObject t) {
        int tid = t.optInt("id");
        StringBuilder b = new StringBuilder("👤 *").append(t.optString("name")).append("*\n");
        if (!where(t).isEmpty()) b.append("🏠 ").append(where(t)).append("\n");
        b.append("💲 Renta: ").append(money(t.optDouble("rent", 0)))
                .append(t.optDouble("utilities", 0) > 0 ? " + utilidades " + money(t.optDouble("utilities", 0)) + " = " + money(Store.monthly(t)) : "")
                .append(" · paga el día ").append(t.optInt("dueDay", Store.getI(this, "dueDay", 1))).append("\n");
        if (!t.optString("phone").isEmpty()) b.append("📞 ").append(t.optString("phone")).append("\n");
        if (t.optDouble("deposit", 0) > 0)
            b.append("🔐 Depósito: ").append(money(t.optDouble("deposit", 0))).append(t.optBoolean("depPaid") ? " (recibido)" : " (pendiente)").append("\n");
        b.append("\n*Últimos meses:*\n");
        double debt = 0;
        String cm = Store.thisMonth();
        for (int i = 0; i < 4; i++) {
            String mm = Store.addMonth(cm, -i);
            if (!Store.activeIn(t, mm)) continue;
            JSONObject r = Store.rec(recs, tid, mm, false);
            int st = status(t, mm);
            double owed = Store.due(t, r) - Store.paid(r);
            if (st != 0 && i > 0) debt += Math.max(0, owed);
            b.append(ST_ICON[st]).append(" ").append(Store.monthName(mm)).append(": ")
                    .append(st == 0 ? "pagado " + money(Store.paid(r)) : "falta " + money(owed));
            if (r != null && !r.optString("promise").isEmpty() && st != 0) b.append(" (prometió el ").append(Store.shortDate(r.optString("promise"))).append(")");
            b.append("\n");
        }
        if (debt > 0.009) b.append("\n⚠️ Debe de meses anteriores: ").append(money(debt)).append("\n");
        b.append("\n— Rentas Amigo Renta");
        return b.toString();
    }

    String monthText(String m) {
        List<JSONObject> act = activeTenants(m);
        Collections.sort(act, (x, y) -> where(x).compareToIgnoreCase(where(y)));
        double exp = 0, got = 0;
        StringBuilder paid = new StringBuilder(), owe = new StringBuilder();
        int np = 0, no = 0;
        for (JSONObject t : act) {
            JSONObject r = Store.rec(recs, t.optInt("id"), m, false);
            double due = Store.due(t, r), pd = Store.paid(r);
            exp += due;
            got += Math.min(pd, due);
            int st = status(t, m);
            String line = "• " + t.optString("name") + (room(t).isEmpty() ? "" : " – " + room(t));
            if (st == 0) { np++; paid.append(line).append(" – ").append(money(pd)).append("\n"); }
            else {
                no++;
                owe.append(ST_ICON[st]).append(" ").append(t.optString("name")).append(room(t).isEmpty() ? "" : " – " + room(t))
                        .append(" – falta ").append(money(due - pd));
                if (r != null && !r.optString("promise").isEmpty()) owe.append(" (prometió el ").append(Store.shortDate(r.optString("promise"))).append(")");
                owe.append("\n");
            }
        }
        StringBuilder b = new StringBuilder("📊 *Rentas · ").append(Store.monthName(m)).append("*\n");
        if (!propFilter.isEmpty()) b.append("🏠 ").append(propFilter).append("\n");
        b.append("Esperado: ").append(money(exp)).append("\nCobrado: ").append(money(got))
                .append("\nFalta: ").append(money(exp - got)).append(exp > 0 ? " (" + Math.round(got * 100 / exp) + "% cobrado)" : "").append("\n");
        if (no > 0) b.append("\n*Faltan por pagar (").append(no).append("):*\n").append(owe);
        if (np > 0) b.append("\n*Pagados (").append(np).append("):*\n").append(paid);
        b.append("\n— Rentas Amigo Renta · ").append(Store.dateTime(System.currentTimeMillis()));
        return b.toString();
    }

    void managerMenu() {
        final String m = month;
        String[] items = {"📝 Resumen de " + Store.monthName(m) + " (texto)", "📊 Reporte de Excel de " + Store.monthName(m),
                "🔴 Solo los que faltan por pagar", "📅 Cambiar de mes en la pestaña Mes"};
        new AlertDialog.Builder(this).setTitle("👔 Enviar al " + mgrName()).setItems(items, (dlg, w) -> {
            if (w == 0) sendToManager(monthText(m), null, null);
            else if (w == 1) {
                Uri u = saveReportUri(m);
                if (u == null) { toast("No se pudo crear el Excel"); return; }
                sendToManager("📊 Reporte de rentas · " + Store.monthName(m) + "\n\n" + monthText(m).split("\\n\\*Faltan|\\n\\*Pagados")[0],
                        u, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            } else if (w == 2) {
                String full = monthText(m);
                int a = full.indexOf("*Faltan por pagar");
                int b = full.indexOf("\n*Pagados");
                String part = a < 0 ? "✅ Todos pagaron " + Store.monthName(m).toLowerCase(Store.ES) : full.substring(a, b > a ? b : full.indexOf("\n— Rentas"));
                sendToManager("🔴 *Pendientes · " + Store.monthName(m) + "*\n\n" + part + "\n\n— Rentas Amigo Renta", null, null);
            } else openTab(0);
        }).show();
    }

    // ============================ comprobantes ============================
    JSONObject findPayment(int pid) {
        for (JSONObject r : recs) {
            JSONArray p = r.optJSONArray("payments");
            if (p == null) continue;
            for (int i = 0; i < p.length(); i++) { JSONObject x = p.optJSONObject(i); if (x != null && x.optInt("id") == pid) return x; }
        }
        return null;
    }

    JSONObject recOfPayment(int pid) {
        for (JSONObject r : recs) {
            JSONArray p = r.optJSONArray("payments");
            if (p == null) continue;
            for (int i = 0; i < p.length(); i++) { JSONObject x = p.optJSONObject(i); if (x != null && x.optInt("id") == pid) return r; }
        }
        return null;
    }

    void payMenu(JSONObject x) {
        boolean has = !x.optString("img").isEmpty();
        List<String> o = new ArrayList<>();
        o.add("📄 Recibo PDF al inquilino");
        o.add("💬 Compartir por WhatsApp (elegir a quién)");
        o.add("👔 Enviar al " + mgrName());
        if (CASH.equals(x.optString("method"))) o.add(x.optString("recv").isEmpty() ? "🤝 Poner quién recibió el efectivo" : "🤝 Cambiar quién recibió (" + x.optString("recv") + ")");
        if (has) { o.add("🧾 Ver comprobante"); o.add("📤 Compartir comprobante"); }
        o.add(has ? "📷 Cambiar: tomar foto" : "📷 Agregar: tomar foto");
        o.add(has ? "🖼️ Cambiar: elegir de la galería" : "🖼️ Agregar: elegir de la galería");
        if (has) o.add("❌ Quitar comprobante");
        o.add("🗑️ Eliminar este pago");
        new AlertDialog.Builder(this).setTitle(money(x.optDouble("amount", 0)) + " · " + Store.dateTime(x.optLong("date")))
                .setItems(o.toArray(new String[0]), (dlg, w) -> {
                    String s = o.get(w);
                    if (s.startsWith("📄")) receiptMenu(x.optInt("id"));
                    else if (s.startsWith("👔")) sendPayment(x.optInt("id"));
                    else if (s.startsWith("🤝")) editRecv(x);
                    else if (s.startsWith("🧾")) viewImage(x.optString("img"));
                    else if (s.startsWith("📤")) {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("image/*");
                        i.putExtra(Intent.EXTRA_STREAM, Uri.parse(x.optString("img")));
                        i.putExtra(Intent.EXTRA_TEXT, "Comprobante de pago · " + money(x.optDouble("amount", 0)) + " · " + Store.dateTime(x.optLong("date")));
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        launch(Intent.createChooser(i, "Compartir comprobante"));
                    } else if (s.startsWith("📷")) { pendingPayId = x.optInt("id"); movPhoto = false; capture(); }
                    else if (s.startsWith("🖼️")) { pendingPayId = x.optInt("id"); movPhoto = false; pickImage(); }
                    else if (s.startsWith("❌")) { x.remove("img"); x.remove("imgId"); x.remove("imgFor"); x.remove("imgDl"); saveAll(); refresh(); }
                    else if (s.startsWith("💬")) { String tx = payText(x.optInt("id")); if (tx != null) waShareAny(tx, has ? Uri.parse(x.optString("img")) : null); }
                    else deletePayment(x);
                }).show();
    }

    void editRecv(JSONObject x) {
        EditText e = input("Nombre", TXT_CAP);
        e.setText(x.optString("recv"));
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(6), dp(20), 0);
        box.addView(e);
        List<String> rn = recvNames();
        if (!rn.isEmpty()) {
            LinearLayout rc = hbox();
            for (String n : rn) rc.addView(chip(n, false, v -> { e.setText(n); e.setSelection(n.length()); }));
            box.addView(hscroll(rc));
        }
        new AlertDialog.Builder(this).setTitle("¿Quién recibió el efectivo?").setView(box)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = e.getText().toString().trim();
                    if (n.isEmpty()) x.remove("recv"); else { Store.put(x, "recv", n); rememberRecv(n); }
                    Store.stamp(this, x);
                    saveAll();
                    refresh();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** Nombres usados antes para «recibió el efectivo» (el último primero). */
    List<String> recvNames() {
        List<String> l = new ArrayList<>();
        for (String n : Store.get(this, "recvNames", "").split("\\|")) if (!n.trim().isEmpty() && l.size() < 8) l.add(n.trim());
        return l;
    }

    void rememberRecv(String n) {
        List<String> l = recvNames();
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).equalsIgnoreCase(n)) l.remove(i);
        l.add(0, n);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < l.size() && i < 8; i++) b.append(i > 0 ? "|" : "").append(l.get(i).replace("|", " "));
        Store.putS(this, "recvNames", b.toString());
        Store.putS(this, "lastRecv", n);
    }

    void deletePayment(JSONObject x) {
        if (x.optString("syncStatus").equals("sincronizado")) {
            new AlertDialog.Builder(this).setTitle("Este pago ya está en QuickBooks")
                    .setMessage("Para corregirlo hay que anularlo o editarlo en QuickBooks. La app lo actualizará al sincronizar.")
                    .setPositiveButton("Entendido", null).show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("¿Eliminar este pago?")
                .setPositiveButton("Eliminar", (dlg, w) -> {
                    JSONObject r = recOfPayment(x.optInt("id"));
                    if (r != null) {
                        JSONArray pays = r.optJSONArray("payments");
                        JSONArray na = new JSONArray();
                        for (int j = 0; j < pays.length(); j++) { JSONObject y = pays.optJSONObject(j); if (y != null && y.optInt("id") != x.optInt("id")) na.put(y); }
                        Store.put(r, "payments", na);
                    }
                    int did = x.optInt("detId", -1);
                    for (JSONObject d : detected) if (d.optInt("id") == did) { Store.put(d, "status", "pendiente"); d.remove("month"); }
                    saveAll();
                    refresh();
                }).setNegativeButton("Cancelar", null).show();
    }

    void viewImage(String uri) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(Uri.parse(uri), "image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        launch(i);
    }

    void capture() {
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 9);
            toast("Acepta el permiso y vuelve a intentarlo");
            return;
        }
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "comprobante_" + System.currentTimeMillis() + ".jpg");
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
        if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Amigo Renta Comprobantes");
        Uri u = null;
        try { u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv); } catch (Exception e) { }
        if (u == null) { toast("No se pudo preparar la cámara"); return; }
        pendingCap = u;
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT, u);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(i, REQ_PHOTO); } catch (Exception e) { toast("No hay app de cámara"); }
    }

    void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        try { startActivityForResult(i, REQ_PICK); } catch (Exception e) { toast("No se pudo abrir la galería"); }
    }

    void setImage(String uri) {
        if (movPhoto) {
            movPhoto = false;
            if (mDraft != null) { Store.put(mDraft, "img", uri); toast("Foto agregada 🧾. Ahora toca «Guardar»."); }
            return;
        }
        if (pendingPayId >= 0) {
            JSONObject x = findPayment(pendingPayId);
            if (x != null) { Store.put(x, "img", uri); x.remove("imgFor"); x.remove("imgDl"); saveAll(); toast("Comprobante guardado 🧾"); }
        } else {
            formImg = uri;
            toast("Comprobante agregado. Ahora toca «Guardar pago».");
        }
        pendingPayId = -1;
    }

    void loadThumb(ImageView iv, Uri u) {
        new Thread(() -> {
            Bitmap b = null;
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
                int sz = 1;
                while (o.outWidth / (sz * 2) >= 200 && o.outHeight / (sz * 2) >= 200) sz *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = sz;
                try (InputStream in = getContentResolver().openInputStream(u)) { b = BitmapFactory.decodeStream(in, null, o2); }
                int rot = 0;
                try (InputStream in = getContentResolver().openInputStream(u)) {
                    int ori = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    rot = ori == ExifInterface.ORIENTATION_ROTATE_90 ? 90 : ori == ExifInterface.ORIENTATION_ROTATE_180 ? 180 : ori == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
                } catch (Exception e) { }
                if (b != null && rot != 0) {
                    Matrix mx = new Matrix();
                    mx.postRotate(rot);
                    b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), mx, true);
                }
            } catch (Exception e) { b = null; }
            final Bitmap fb = b;
            runOnUiThread(() -> { if (fb != null) iv.setImageBitmap(fb); });
        }).start();
    }

    void watch(EditText e, Runnable r) {
        e.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable ed) { r.run(); }
        });
    }

    TextView smallBtn(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 13, color, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundStroke(Color.WHITE, 12, color));
        b.setPadding(dp(6), dp(11), dp(6), dp(11));
        b.setMaxLines(1);
        b.setOnClickListener(l);
        return b;
    }

    // ============================ inquilinos ============================
    void tenantsScreen() {
        int act = 0;
        for (JSONObject t : tenants) if (!t.optBoolean("inactive")) act++;
        setHeader("Inquilinos", act + " activos", "👥", false);
        LinearLayout p = vbox();
        EditText s = input("🔍  Buscar por nombre, propiedad o cuarto", InputType.TYPE_CLASS_TEXT);
        s.setText(tSearch);
        ((LinearLayout.LayoutParams) s.getLayoutParams()).setMargins(dp(14), dp(10), dp(14), dp(4));
        p.addView(s);
        final LinearLayout list = vbox();
        p.addView(list);
        final Runnable fillList = () -> {
            list.removeAllViews();
            String q = Store.norm(tSearch);
            List<JSONObject> l = new ArrayList<>();
            for (JSONObject t : tenants)
                if (q.isEmpty() || Store.norm(t.optString("name") + " " + t.optString("property") + " " + t.optString("unit") + " " + t.optString("aliases")).contains(q)) l.add(t);
            Collections.sort(l, (x, y) -> {
                if (x.optBoolean("inactive") != y.optBoolean("inactive")) return x.optBoolean("inactive") ? 1 : -1;
                return (x.optString("property") + x.optString("unit") + x.optString("name")).compareToIgnoreCase(y.optString("property") + y.optString("unit") + y.optString("name"));
            });
            if (tenants.isEmpty()) list.addView(empty("Todavía no hay inquilinos.\nToca «＋ Inquilino» o pega tu lista en Más → Importar lista."));
            for (JSONObject t : l) {
                LinearLayout c = card();
                c.setOrientation(LinearLayout.HORIZONTAL);
                c.setGravity(Gravity.CENTER_VERTICAL);
                LinearLayout v = vbox();
                v.addView(tv(t.optString("name") + (t.optBoolean("inactive") ? "  (ya no vive)" : ""), 16, t.optBoolean("inactive") ? MUT : TXT, true));
                String where = where(t);
                if (!where.isEmpty()) v.addView(tv(where, 13, MUT, false));
                v.addView(tv("Paga el día " + t.optInt("dueDay", Store.getI(this, "dueDay", 1)) + (t.optString("phone").isEmpty() ? "" : " · 📞 " + t.optString("phone")), 12, MUT, false));
                if (t.optDouble("deposit", 0) > 0)
                    v.addView(tv("🔐 Depósito " + money(t.optDouble("deposit", 0)) + (t.optBoolean("depPaid") ? " ✅" : " ⏳ pendiente"),
                            12, t.optBoolean("depPaid") ? 0xFF15803D : YEL, true));
                c.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
                LinearLayout amt = vbox();
                amt.setGravity(Gravity.END);
                amt.addView(tv(money(Store.monthly(t)), 16, TXT, true));
                if (t.optDouble("utilities", 0) > 0) amt.addView(tv("renta + util.", 11, MUT, false));
                c.addView(amt);
                final int id = t.optInt("id");
                c.setOnClickListener(x -> open(() -> tenantDetail(id)));
                list.addView(c);
            }
        };
        s.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable e) { tSearch = e.toString(); fillList.run(); }
        });
        fillList.run();
        show(scroll(p), true, "＋  Inquilino", () -> open(() -> tenantForm(-1)));
    }

    void tenantDetail(int tid) {
        final JSONObject t = Store.tenant(tenants, tid);
        if (t == null) { goBack(); return; }
        setHeader(t.optString("name"), where(t), null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.addView(kv("Renta mensual", money(t.optDouble("rent", 0))));
        c.addView(kv("Utilidades mensuales", money(t.optDouble("utilities", 0))));
        c.addView(kv("Total mensual", money(Store.monthly(t)), PRI));
        c.addView(kv("Paga el día", String.valueOf(t.optInt("dueDay", Store.getI(this, "dueDay", 1)))));
        if (!t.optString("phone").isEmpty()) c.addView(kv("Teléfono", t.optString("phone")));
        if (!t.optString("email").isEmpty()) c.addView(kv("Correo", t.optString("email")));
        if (!t.optString("aliases").isEmpty()) c.addView(kv("Nombre en e-Transfer", t.optString("aliases")));
        if (!t.optString("since").isEmpty()) c.addView(kv("Desde", Store.monthName(t.optString("since"))));
        if (!t.optString("qboName").isEmpty()) c.addView(kv("Cliente en QuickBooks", t.optString("qboName")));
        double dp0 = t.optDouble("deposit", 0);
        if (dp0 > 0) {
            c.addView(divider());
            c.addView(kv("🔐 Depósito", money(dp0)));
            c.addView(kv("Estado", t.optBoolean("depPaid")
                    ? "✅ Recibido" + (t.optLong("depDate") > 0 ? " el " + Store.shortDate(Store.dayOf(t.optLong("depDate"))) : "")
                    : "⏳ Pendiente", t.optBoolean("depPaid") ? GRN : YEL));
            if (t.optDouble("depReturned", 0) > 0) c.addView(kv("Devuelto", money(t.optDouble("depReturned", 0)), PRI2));
        } else {
            c.addView(kv("🔐 Depósito", "No registrado", MUT));
        }
        if (t.optDouble("hold", 0) > 0) {
            c.addView(kv("🤝 Enganche", money(t.optDouble("hold", 0)) + (t.optLong("holdDate") > 0 ? " · " + Store.shortDate(Store.dayOf(t.optLong("holdDate"))) : ""), GRN));
            if (!t.optString("holdMethod").isEmpty()) c.addView(kv("Cómo lo pagó", t.optString("holdMethod") + (t.optString("holdRecv").isEmpty() ? "" : " · lo recibió " + t.optString("holdRecv"))));
            double tot = Store.monthly(t) + t.optDouble("deposit", 0);
            c.addView(kv("Al entrar (renta + depósito − enganche)", money(Math.max(0, tot - t.optDouble("hold", 0)))));
        }
        if (t.optBoolean("inactive")) c.addView(kv("Ya no vive desde", Store.monthName(Store.addMonth(t.optString("until"), 1)), RED));
        if (!t.optString("notes").isEmpty()) { c.addView(divider()); c.addView(tv("📝 " + t.optString("notes"), 14, TXT, false)); }
        p.addView(c);
        View extra = tableData(t);
        if (extra != null) { p.addView(sectionTitle("📋 Datos de la tabla", null, null)); p.addView(extra); }

        p.addView(sectionTitle("Historial (12 meses)", null, null));
        LinearLayout h = card();
        String m = Store.thisMonth();
        int shown = 0;
        double debt = 0;
        for (int i = 0; i < 12; i++) {
            String mm = Store.addMonth(m, -i);
            if (!Store.activeIn(t, mm)) continue;
            JSONObject r = Store.rec(recs, tid, mm, false);
            int st = status(t, mm);
            double owed = Store.due(t, r) - Store.paid(r);
            if (lateDays(t, mm) > 0) debt += Math.max(0, owed);
            if (h.getChildCount() > 0) h.addView(divider());
            LinearLayout row = hbox();
            row.addView(tv(ST_ICON[st] + "  " + Store.monthName(mm), 14, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
            row.addView(tv(st == 0 ? money(Store.paid(r)) : "falta " + money(owed), 14, ST_COL[st][0], true));
            final String fm = mm;
            row.setOnClickListener(x -> open(() -> payScreen(tid, fm)));
            h.addView(row);
            shown++;
        }
        if (shown == 0) h.addView(tv("Sin meses registrados", 14, MUT, false));
        p.addView(h);
        if (debt > 0.009) {
            TextView d = tv("⚠️ Debe en total " + money(debt) + " de meses anteriores", 15, RED, true);
            d.setPadding(dp(18), dp(8), dp(18), 0);
            p.addView(d);
        }
        LinearLayout b = hbox();
        b.setPadding(dp(8), dp(12), dp(8), 0);
        final String phone = t.optString("phone");
        b.addView(outline("💬  WhatsApp", GRN, v -> { if (!phone.isEmpty()) launch(Store.waIntent(this, phone, "")); else toast("Sin teléfono"); }), weightLp(1f));
        b.addView(outline("✏️  Editar", PRI2, v -> open(() -> tenantForm(tid))), weightLp(1f));
        p.addView(b);
        p.addView(button("👔  Enviar información al " + mgrName(), PRI2, v -> sendToManager(tenantText(t), null, null)));
        show(scroll(p), false, null, null);
    }

    /** Datos que vienen de la tabla mensual de clientes. */
    View tableData(JSONObject t) {
        String own = houseOwner(ownerMap(), t.optString("property"));
        String svc = join(" · ", t.optString("svcTelus").isEmpty() ? "" : "Telus/Rogers: " + t.optString("svcTelus"),
                t.optString("svcFortis").isEmpty() ? "" : "Fortis: " + t.optString("svcFortis"), t.optString("svcHydro").isEmpty() ? "" : "BC Hydro: " + t.optString("svcHydro"));
        String[][] rows = {
                {"Código de la unidad", t.optString("code")},
                {"Compañía", own.isEmpty() ? t.optString("company") : own},
                {"Dueño de la casa", t.optString("landlord")},
                {"Piso / clase", t.optString("level")},
                {"Tipo de unidad", t.optString("unitType")},
                {"Dirección completa", t.optString("address")},
                {"Código postal", t.optString("postal")},
                {"Ocupantes", t.optInt("occupants") > 0 ? String.valueOf(t.optInt("occupants")) : ""},
                {"Fecha de ingreso", t.optString("moveIn").isEmpty() ? "" : Store.shortDate(t.optString("moveIn")) + " " + t.optString("moveIn").substring(0, 4)},
                {"Fecha de salida", t.optString("moveOut").isEmpty() ? "" : Store.shortDate(t.optString("moveOut")) + " " + t.optString("moveOut").substring(0, 4)},
                {"Utilidades", !t.has("utilIncl") ? "" : t.optBoolean("utilIncl") ? "Incluidas en la renta" : "No incluidas"},
                {"Servicios", svc},
                {"Nota de utilidades", t.optString("utilNotes")},
                {"Forma de pago", t.optString("payMethod")},
                {"Morosidad", t.optString("payNote")},
                {"Estado de contrato", t.optString("contract")},
                {"Invoice", t.optString("invoice")},
                {"QuickBooks", t.optString("qbRef")},
                {"Depósito (nota)", t.optString("depNote")},
                {"Depósito de mascota", t.optDouble("petDeposit", 0) > 0 ? money(t.optDouble("petDeposit", 0)) : ""},
                {"Parking", t.optDouble("parking", 0) > 0 ? money(t.optDouble("parking", 0)) : ""},
                {"Limpieza", t.optDouble("cleaning", 0) > 0 ? money(t.optDouble("cleaning", 0)) : ""},
                {"Obs. de la unidad", t.optString("unitObs")}};
        LinearLayout c = card();
        for (String[] r : rows) {
            if (r[1] == null || r[1].trim().isEmpty()) continue;
            LinearLayout row = hbox();
            row.setGravity(Gravity.TOP);
            row.setPadding(0, dp(4), 0, dp(4));
            row.addView(tv(r[0], 14, MUT, false), new LinearLayout.LayoutParams(0, -2, 0.42f));
            TextView v = tv(r[1], 14, TXT, true);
            v.setGravity(Gravity.END);
            row.addView(v, new LinearLayout.LayoutParams(0, -2, 0.58f));
            c.addView(row);
        }
        return c.getChildCount() == 0 ? null : c;
    }

    void tenantForm(int tid) {
        final JSONObject old = tid < 0 ? null : Store.tenant(tenants, tid);
        setHeader(old == null ? "Nuevo inquilino" : "Editar inquilino", null, null, true);
        formMode();
        LinearLayout p = vbox();
        LinearLayout c = card();
        EditText name = input("Nombre completo", TXT_CAP);
        EditText aliases = input("Ej. JUAN PEREZ, MARIA LOPEZ", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        EditText phone = input("Ej. +1 604 555 1111", InputType.TYPE_CLASS_PHONE);
        EditText email = input("Correo (opcional)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText prop = input("Ej. 801 E Broadway, Vancouver", TXT_CAP);
        EditText unit = input("Ej. 3", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        EditText rent = input("Renta mensual", DEC);
        EditText util = input("0", DEC);
        EditText day = input("1", InputType.TYPE_CLASS_NUMBER);
        EditText notes = input("Notas (opcional)", TXT_MULTI);
        EditText qbn = input("Igual que el nombre del inquilino", TXT_CAP);
        EditText dep = input("Ej. 475", DEC);
        EditText depRet = input("0", DEC);
        final long[] depDate = {old != null && old.optLong("depDate") > 0 ? old.optLong("depDate") : System.currentTimeMillis()};
        // enganche para apartar la habitación (al dar de alta a un inquilino nuevo)
        EditText hold = input("Ej. 200", DEC);
        final long[] holdDate = {old != null && old.optLong("holdDate") > 0 ? old.optLong("holdDate") : System.currentTimeMillis()};
        final boolean showHold = old == null || old.optDouble("hold", 0) > 0;
        if (old != null && old.optDouble("hold", 0) > 0) hold.setText(qty(old.optDouble("hold", 0)));
        final String[] holdMethod = {old != null ? old.optString("holdMethod") : ""};
        EditText holdRecv = input("Nombre de quien recibió el efectivo", TXT_CAP);
        if (old != null) holdRecv.setText(old.optString("holdRecv"));
        Switch depPaid = new Switch(this);
        depPaid.setText("✅  Ya entregó el depósito");
        depPaid.setTextSize(15);
        depPaid.setTextColor(TXT);
        depPaid.setPadding(0, dp(12), 0, dp(4));
        final String[] since = {old != null && !old.optString("since").isEmpty() ? old.optString("since") : Store.thisMonth()};
        final TextView sinceF = field("📅  " + Store.monthName(since[0]));
        sinceF.setOnClickListener(v -> pickDate(since[0] + "-01", iso -> { since[0] = iso.substring(0, 7); sinceF.setText("📅  " + Store.monthName(since[0])); }));
        Switch active = new Switch(this);
        active.setText("✅  Vive actualmente (se incluye cada mes)");
        active.setTextSize(15);
        active.setTextColor(TXT);
        active.setPadding(0, dp(14), 0, dp(4));
        active.setChecked(old == null || !old.optBoolean("inactive"));
        if (old != null) {
            name.setText(old.optString("name"));
            aliases.setText(old.optString("aliases"));
            phone.setText(old.optString("phone"));
            email.setText(old.optString("email"));
            prop.setText(old.optString("property"));
            unit.setText(old.optString("unit"));
            rent.setText(qty(old.optDouble("rent", 0)));
            if (old.optDouble("utilities", 0) > 0) util.setText(qty(old.optDouble("utilities", 0)));
            day.setText(String.valueOf(old.optInt("dueDay", Store.getI(this, "dueDay", 1))));
            notes.setText(old.optString("notes"));
            qbn.setText(old.optString("qboName"));
            if (old.optDouble("deposit", 0) > 0) dep.setText(qty(old.optDouble("deposit", 0)));
            if (old.optDouble("depReturned", 0) > 0) depRet.setText(qty(old.optDouble("depReturned", 0)));
            depPaid.setChecked(old.optBoolean("depPaid"));
        } else day.setText(String.valueOf(Store.getI(this, "dueDay", 1)));
        c.addView(label("👤", "Nombre del inquilino", true));
        c.addView(name);
        c.addView(label("📩", "Nombre como aparece en el e-Transfer", false));
        c.addView(aliases);
        c.addView(tv("Si paga otra persona o el banco usa otro nombre, escríbelo aquí (varios separados por coma).", 12, MUT, false));
        p.addView(c);
        LinearLayout pc = card();
        pc.addView(tv("🏠  ¿Qué renta?", 16, TXT, true));
        pc.addView(label("🏠", "Propiedad", true));
        pc.addView(prop);
        List<String> props = properties();
        if (!props.isEmpty()) {
            LinearLayout chipsP = hbox();
            for (String pr : props) chipsP.addView(chip(pr, false, x -> prop.setText(pr)));
            pc.addView(hscroll(chipsP));
        }
        pc.addView(labeled("Número de cuarto", unit));
        pc.addView(twoCols(labeled("Renta mensual (" + Store.get(this, "cur", "$") + ")", rent), labeled("Utilidades mensuales", util)));
        final TextView totalTv = tv("", 16, PRI, true);
        totalTv.setPadding(0, dp(8), 0, 0);
        pc.addView(totalTv);
        Runnable calcTot = () -> {
            double a = num(rent.getText().toString()), u2 = num(util.getText().toString());
            totalTv.setText(a + u2 > 0 ? "💲 Total mensual a pagar: " + money(a + u2) : "");
        };
        watch(rent, calcTot);
        watch(util, calcTot);
        calcTot.run();
        final TextView roomInfo = tv("", 13, YEL, true);
        roomInfo.setPadding(0, dp(6), 0, 0);
        pc.addView(roomInfo);
        Runnable checkRoom = () -> {
            JSONObject other = roomTaken(prop.getText().toString(), unit.getText().toString(), tid, old == null ? null : old.optString("level"));
            roomInfo.setText(other == null ? "" : "⚠️ En ese cuarto ya está " + other.optString("name"));
        };
        TextWatcher tw = new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable e) { checkRoom.run(); }
        };
        prop.addTextChangedListener(tw);
        unit.addTextChangedListener(tw);
        p.addView(pc);
        c = card();
        c.addView(twoCols(labeled("Paga el día", day), labeled("Desde el mes", sinceF)));
        c.addView(label("📞", "Teléfono / WhatsApp", false));
        c.addView(phone);
        c.addView(label("📧", "Correo", false));
        c.addView(email);
        p.addView(c);
        if (showHold) {
            LinearLayout hc = card();
            hc.addView(tv("🤝  Enganche para apartar la habitación", 16, TXT, true));
            hc.addView(twoCols(labeled("Monto del enganche (" + Store.get(this, "cur", "$") + ")", hold), dateField(holdDate, "Día que lo dio")));
            hc.addView(label("💳", "¿Cómo lo pagó?", false));
            final String[] HM = {"Efectivo (cash)", "Transferencia", "Tarjeta de crédito"};
            final TextView[] hmc = new TextView[HM.length];
            final LinearLayout recvBox = vbox();
            LinearLayout hmr = hbox();
            for (int i = 0; i < HM.length; i++) {
                final int j = i;
                hmc[i] = chip(HM[i], HM[i].equals(holdMethod[0]), v -> {
                    holdMethod[0] = HM[j].equals(holdMethod[0]) ? "" : HM[j];
                    for (int k = 0; k < hmc.length; k++) styleChip(hmc[k], HM[k].equals(holdMethod[0]));
                    recvBox.setVisibility(holdMethod[0].startsWith("Efectivo") ? View.VISIBLE : View.GONE);
                });
                hmr.addView(hmc[i]);
            }
            hc.addView(hscroll(hmr));
            recvBox.addView(label("🤝", "¿Quién recibió el efectivo?", true));
            recvBox.addView(holdRecv);
            List<String> rn = recvNames();
            if (!rn.isEmpty()) {
                LinearLayout rc = hbox();
                for (String nn : rn) rc.addView(chip(nn, false, v -> { holdRecv.setText(nn); holdRecv.setSelection(nn.length()); }));
                recvBox.addView(hscroll(rc));
            }
            recvBox.setVisibility(holdMethod[0].startsWith("Efectivo") ? View.VISIBLE : View.GONE);
            hc.addView(recvBox);
            final TextView sum = tv("", 14, PRI, true);
            sum.setPadding(0, dp(10), 0, 0);
            hc.addView(sum);
            Runnable calc = () -> {
                double r0 = num(rent.getText().toString()) + num(util.getText().toString()), d0 = num(dep.getText().toString()), h0 = num(hold.getText().toString());
                if (r0 + d0 + h0 <= 0) { sum.setText(""); return; }
                sum.setText("💲 Renta: " + money(r0) + "\n🔐 Depósito: " + money(d0) + "\n🤝 Enganche: " + money(h0)
                        + "\n────────────\nTotal al entrar: " + money(r0 + d0) + (h0 > 0 ? "\nMenos el enganche: falta " + money(Math.max(0, r0 + d0 - h0)) : ""));
            };
            watch(rent, calc); watch(util, calc); watch(dep, calc); watch(hold, calc);
            calc.run();
            hc.addView(tv("El enganche es lo que dio para apartar el cuarto antes de entrar.", 12, MUT, false));
            p.addView(hc);
        }
        LinearLayout dc = card();
        dc.addView(tv("🔐  Depósito", 16, TXT, true));
        dc.addView(twoCols(labeled("Monto del depósito (" + Store.get(this, "cur", "$") + ")", dep), dateField(depDate)));
        dc.addView(depPaid);
        dc.addView(labeled("Depósito devuelto al mudarse (" + Store.get(this, "cur", "$") + ")", depRet));
        dc.addView(tv("Llénalo solo cuando se le devuelva todo o parte del depósito.", 12, MUT, false));
        p.addView(dc);
        LinearLayout qc = card();
        qc.addView(tv("🟢  QuickBooks", 16, TXT, true));
        qc.addView(labeled("Nombre del cliente en QuickBooks", qbn));
        qc.addView(tv("Escríbelo solo si en QuickBooks aparece distinto (ej. sin segundo apellido). Cada inquilino es un cliente."
                + (old != null && !old.optString("qboCustomerId").isEmpty() ? "\n✅ Enlazado con QuickBooks (ID " + old.optString("qboCustomerId") + ")" : ""), 12, MUT, false));
        p.addView(qc);
        LinearLayout c2 = card();
        c2.addView(active);
        c2.addView(label("📝", "Notas", false));
        c2.addView(notes);
        p.addView(c2);
        final Runnable[] doSave = new Runnable[1];
        p.addView(button("Guardar inquilino", PRI2, v -> {
            String n = name.getText().toString().trim();
            double rn = num(rent.getText().toString());
            if (n.isEmpty()) { toast("Escribe el nombre"); return; }
            if (prop.getText().toString().trim().isEmpty()) { toast("Escribe la propiedad"); return; }
            if (unit.getText().toString().trim().isEmpty()) { toast("Escribe el número de cuarto"); return; }
            if (rn <= 0) { toast("Escribe la renta mensual"); return; }
            if (showHold && num(hold.getText().toString()) > 0 && holdMethod[0].startsWith("Efectivo") && holdRecv.getText().toString().trim().isEmpty()) { toast("Escribe quién recibió el efectivo del enganche"); holdRecv.requestFocus(); return; }
            JSONObject other = active.isChecked() ? roomTaken(prop.getText().toString(), unit.getText().toString(), tid, old == null ? null : old.optString("level")) : null;
            if (other != null) {
                new AlertDialog.Builder(this).setTitle("Cuarto ocupado")
                        .setMessage("En " + where(other) + " ya está " + other.optString("name") + ". ¿Guardar de todas formas? (por ejemplo, si comparten el cuarto)")
                        .setPositiveButton("Guardar", (dlg, w) -> doSave[0].run())
                        .setNegativeButton("Revisar", null).show();
            } else doSave[0].run();
        }));
        doSave[0] = () -> {
            String n = name.getText().toString().trim();
            double rn = num(rent.getText().toString());
            JSONObject o = old != null ? old : new JSONObject();
            if (old == null) Store.put(o, "id", Store.nextId(this));
            Store.put(o, "name", n);
            Store.put(o, "aliases", aliases.getText().toString().trim());
            Store.put(o, "phone", phone.getText().toString().trim());
            Store.put(o, "email", email.getText().toString().trim());
            Store.put(o, "property", prop.getText().toString().trim());
            Store.put(o, "unit", unit.getText().toString().trim());
            Store.put(o, "rent", rn);
            Store.put(o, "utilities", num(util.getText().toString()));
            int d = (int) num(day.getText().toString());
            Store.put(o, "dueDay", d < 1 || d > 31 ? 1 : d);
            Store.put(o, "since", since[0]);
            Store.put(o, "notes", notes.getText().toString().trim());
            Store.put(o, "qboName", qbn.getText().toString().trim());
            Store.put(o, "deposit", num(dep.getText().toString()));
            Store.put(o, "depPaid", depPaid.isChecked());
            Store.put(o, "depDate", depPaid.isChecked() ? depDate[0] : 0);
            Store.put(o, "depReturned", num(depRet.getText().toString()));
            if (showHold) {
                double h1 = num(hold.getText().toString());
                Store.put(o, "hold", h1);
                Store.put(o, "holdDate", h1 > 0 ? holdDate[0] : 0);
                Store.put(o, "holdMethod", h1 > 0 ? holdMethod[0] : "");
                String hr = holdMethod[0].startsWith("Efectivo") && h1 > 0 ? holdRecv.getText().toString().trim() : "";
                Store.put(o, "holdRecv", hr);
                if (!hr.isEmpty()) rememberRecv(hr);
            }
            boolean wasInactive = o.optBoolean("inactive");
            if (!active.isChecked()) {
                if (!wasInactive) Store.put(o, "until", Store.thisMonth());
                Store.put(o, "inactive", true);
            } else { if (wasInactive) o.remove("until"); Store.put(o, "inactive", false); }
            if (old == null) tenants.add(o);
            saveAll();
            toast("Inquilino guardado ✅");
            goBack();
        };
        if (old != null) {
            p.addView(button("🗑️  Eliminar inquilino", RED, v -> new AlertDialog.Builder(this)
                    .setTitle("Eliminar a " + old.optString("name"))
                    .setMessage("Se borra con todo su historial de pagos. Si solo se mudó, mejor desmarca «Vive actualmente».")
                    .setPositiveButton("Eliminar", (dlg, w) -> {
                        tenants.remove(old);
                        for (int i = recs.size() - 1; i >= 0; i--) if (recs.get(i).optInt("tid") == tid) recs.remove(i);
                        Store.cancelPromise(this, tid);
                        saveAll();
                        openTab(1);
                    }).setNegativeButton("Cancelar", null).show()));
        }
        show(scroll(p), false, null, null);
    }

    // ============================ e-Transfers ============================
    boolean listenerOn() {
        String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(new ComponentName(this, PagosListener.class).flattenToString());
    }

    void etScreen() {
        int pend = 0;
        for (JSONObject d : detected) if (d.optString("status").equals("pendiente")) pend++;
        setHeader("e-Transfers recibidos", pend + " por asignar", "📩", false);
        LinearLayout p = vbox();
        boolean on = listenerOn();
        LinearLayout c = card();
        c.setBackground(round(on ? 0xFFE3F6E8 : 0xFFFDE6E6, 16));
        c.addView(tv(on ? "🟢  Lectura automática ACTIVA" : "🔴  Lectura automática desactivada", 17, on ? 0xFF15803D : 0xFFB91C1C, true));
        c.addView(tv(on
                ? "Cuando llegue al correo de este teléfono un aviso de INTERAC e-Transfer, la app lo lee, busca al inquilino y marca el pago."
                : "Actívala para que la app lea los avisos de INTERAC e-Transfer que llegan al correo de este teléfono.", 14, TXT, false));
        if (!on) {
            c.addView(tv("\nPasos:\n1. Toca «Activar» y busca «Rentas Amigo Renta» → actívalo.\n2. Si sale «Ajuste restringido»: ve a Ajustes → Aplicaciones → Rentas Amigo Renta → ⋮ (arriba) → «Permitir ajustes restringidos», y vuelve a intentar.\n3. En la app de correo (Outlook/Gmail) deja activadas las notificaciones de la cuenta donde llegan los e-Transfers.", 13, TXT, false));
            TextView bt = button("Activar", RED, v -> {
                try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
                catch (Exception e) { toast("Abre Ajustes → Notificaciones → Acceso a notificaciones"); }
            });
            ((LinearLayout.LayoutParams) bt.getLayoutParams()).setMargins(0, dp(12), 0, 0);
            c.addView(bt);
        }
        p.addView(c);

        LinearLayout opts = card();
        Switch auto = new Switch(this);
        auto.setText("Marcar el pago automáticamente cuando el nombre coincide");
        auto.setTextSize(14);
        auto.setTextColor(TXT);
        auto.setChecked(Store.getB(this, "autoApply", true));
        auto.setOnCheckedChangeListener((bv, ck) -> Store.putB(this, "autoApply", ck));
        opts.addView(auto);
        p.addView(opts);

        p.addView(button("📋  Pegar el texto de un e-Transfer", PRI2, v -> pasteDialog()));

        p.addView(sectionTitle("Recibidos", null, null));
        List<JSONObject> l = new ArrayList<>(detected);
        Collections.sort(l, (x, y) -> Long.compare(y.optLong("at"), x.optLong("at")));
        if (l.isEmpty()) p.addView(empty("Todavía no ha llegado ningún aviso de e-Transfer"));
        for (int i = 0; i < l.size() && i < 200; i++) p.addView(detRow(l.get(i)));
        show(scroll(p), true, null, null);
    }

    View detRow(JSONObject d) {
        String stt = d.optString("status");
        JSONObject t = d.has("tid") ? Store.tenant(tenants, d.optInt("tid")) : null;
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        boolean ok = stt.equals("aplicado"), ign = stt.equals("ignorado");
        TextView ic = tv(ok ? "✅" : ign ? "🚫" : "❓", 20, TXT, false);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(round(ok ? 0xFFE3F6E8 : ign ? 0xFFEEF0F3 : 0xFFFFF1DB, 12));
        c.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout v = vbox();
        v.setPadding(dp(12), 0, dp(6), 0);
        v.addView(tv(d.optString("name").isEmpty() ? "Nombre no visible" : d.optString("name"), 15, TXT, true));
        v.addView(tv(Store.dateTime(d.optLong("at")) + (d.optString("source").equals("manual") ? " · pegado" : ""), 12, MUT, false));
        String line = ok ? "Aplicado a " + (t != null ? t.optString("name") : "inquilino") + " · " + Store.monthName(d.optString("month"))
                : ign ? "Ignorado" : (t != null ? "¿Es de " + t.optString("name") + "? Toca para confirmar" : "Toca para asignarlo a un inquilino");
        v.addView(tv(line, 13, ok ? 0xFF15803D : ign ? MUT : YEL, true));
        c.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(tv(d.optDouble("amount", 0) > 0 ? money(d.optDouble("amount", 0)) : "—", 15, TXT, true));
        c.setOnClickListener(x -> detMenu(d));
        return c;
    }

    void detMenu(JSONObject d) {
        String stt = d.optString("status");
        List<String> o = new ArrayList<>();
        JSONObject sug = d.has("tid") ? Store.tenant(tenants, d.optInt("tid")) : null;
        if (!stt.equals("aplicado")) {
            if (sug != null) o.add("✅ Confirmar: es de " + sug.optString("name"));
            o.add("👤 Asignar a un inquilino…");
            if (!stt.equals("ignorado")) o.add("🚫 Ignorar (no es de renta)");
        } else {
            o.add("👔 Enviar al " + mgrName());
            o.add("↩️ Deshacer (quitar el pago)");
        }
        o.add("📄 Ver texto del aviso");
        new AlertDialog.Builder(this).setTitle((d.optString("name").isEmpty() ? "e-Transfer" : d.optString("name")) + (d.optDouble("amount", 0) > 0 ? " · " + money(d.optDouble("amount", 0)) : ""))
                .setItems(o.toArray(new String[0]), (dlg, w) -> {
                    String s = o.get(w);
                    if (s.startsWith("✅")) { applyTo(d, sug, false); }
                    else if (s.startsWith("👤")) {
                        pickTenant(Store.month(d.optLong("at")), id -> {
                            JSONObject t = Store.tenant(tenants, Integer.parseInt(id));
                            if (t == null) return;
                            String nm = d.optString("name");
                            boolean known = Store.match(Collections.singletonList(t), nm, 0) != null;
                            if (!nm.isEmpty() && !known) {
                                new AlertDialog.Builder(this).setTitle("¿Recordar este nombre?")
                                        .setMessage("La próxima vez que llegue un e-Transfer de «" + nm + "» se aplicará a " + t.optString("name") + " automáticamente.")
                                        .setPositiveButton("Sí, recordar", (d2, w2) -> applyTo(d, t, true))
                                        .setNegativeButton("Solo esta vez", (d2, w2) -> applyTo(d, t, false)).show();
                            } else applyTo(d, t, false);
                        });
                    } else if (s.startsWith("🚫")) { Store.put(d, "status", "ignorado"); saveAll(); refresh(); }
                    else if (s.startsWith("↩️")) { undo(d); }
                    else if (s.startsWith("👔")) {
                        JSONObject px = null;
                        for (JSONObject r : recs) {
                            JSONArray pa = r.optJSONArray("payments");
                            if (pa != null) for (int i = 0; i < pa.length(); i++) {
                                JSONObject y = pa.optJSONObject(i);
                                if (y != null && y.optInt("detId", -1) == d.optInt("id")) px = y;
                            }
                        }
                        if (px != null) sendPayment(px.optInt("id")); else toast("No encontré el pago");
                    }
                    else new AlertDialog.Builder(this).setTitle("Texto del aviso").setMessage(d.optString("raw")).setPositiveButton("OK", null).show();
                }).show();
    }

    void applyTo(JSONObject d, JSONObject t, boolean remember) {
        if (t == null) return;
        if (remember) {
            String a = t.optString("aliases").trim();
            Store.put(t, "aliases", a.isEmpty() ? d.optString("name") : a + ", " + d.optString("name"));
        }
        String m = Store.apply(this, d, t, recs);
        saveAll();
        toast("Aplicado a " + t.optString("name") + " · " + Store.monthName(m) + " ✅");
        refresh();
    }

    void undo(JSONObject d) {
        int did = d.optInt("id");
        for (JSONObject r : recs) {
            JSONArray p = r.optJSONArray("payments");
            if (p == null) continue;
            JSONArray na = new JSONArray();
            for (int i = 0; i < p.length(); i++) { JSONObject x = p.optJSONObject(i); if (x != null && x.optInt("detId", -1) != did) na.put(x); }
            Store.put(r, "payments", na);
        }
        Store.put(d, "status", "pendiente");
        d.remove("month");
        saveAll();
        toast("Pago quitado");
        refresh();
    }

    // ============================ recibos a una carpeta ============================
    void receiptsFolderDialog() {
        String[] ms = new String[13];
        for (int i = 0; i < 13; i++) ms[i] = Store.monthName(Store.addMonth(Store.thisMonth(), -i));
        new AlertDialog.Builder(this).setTitle("¿Recibos de qué mes?").setItems(ms, (dlg, w) -> saveReceiptsFolder(Store.addMonth(Store.thisMonth(), -w))).show();
    }

    static String fileSafe(String s) {
        String n = java.text.Normalizer.normalize(s == null ? "" : s, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        n = n.replaceAll("[^A-Za-z0-9]+", "-").replaceAll("^-+|-+$", "");
        return n.length() > 40 ? n.substring(0, 40) : n;
    }

    /** Copia las fotos de comprobantes (pagos de renta) y recibos (gastos e ingresos) del mes a Imágenes → Amigo Renta Recibos → AAAA-MM. */
    void saveReceiptsFolder(String m) {
        if (Build.VERSION.SDK_INT < 29) { toast("Necesita Android 10 o más nuevo"); return; }
        List<String[]> todo = new ArrayList<>(); // {uri, nombre}
        for (JSONObject r : recs) {
            JSONArray a = r.optJSONArray("payments");
            if (a == null) continue;
            JSONObject t = Store.tenant(tenants, r.optInt("tid"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject p = a.optJSONObject(i);
                if (p == null || p.optString("img").isEmpty() || !Store.month(p.optLong("date")).equals(m)) continue;
                todo.add(new String[]{p.optString("img"), Store.f("yyyy-MM-dd").format(new java.util.Date(p.optLong("date"))) + "_Renta_" + fileSafe(t == null ? "" : t.optString("name")) + "_" + Math.round(p.optDouble("amount", 0))});
            }
        }
        for (JSONObject x : movs()) {
            if (x.optString("img").isEmpty() || !x.optString("date").startsWith(m)) continue;
            todo.add(new String[]{x.optString("img"), x.optString("date") + "_" + ("in".equals(x.optString("type")) ? "Ingreso" : "Egreso") + "_" + fileSafe(x.optString("desc").isEmpty() ? x.optString("cat") : x.optString("desc")) + "_" + Math.round(x.optDouble("amount", 0))});
        }
        if (todo.isEmpty()) { toast("No hay fotos de recibos en " + Store.monthName(m)); return; }
        toast("Guardando " + todo.size() + " fotos…");
        final String folder = Environment.DIRECTORY_PICTURES + "/Amigo Renta Recibos/" + m;
        new Thread(() -> {
            int ok = 0;
            java.util.Set<String> used = new java.util.HashSet<>();
            for (String[] f : todo) {
                String name = f[1], k = name; int j = 2;
                while (used.contains(k)) k = name + "-" + (j++);
                used.add(k);
                try (InputStream in = getContentResolver().openInputStream(Uri.parse(f[0]))) {
                    if (in == null) continue;
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, k + ".jpg");
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, folder);
                    Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                    if (u == null) continue;
                    try (OutputStream os = getContentResolver().openOutputStream(u)) {
                        byte[] buf = new byte[16384]; int n;
                        while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                    }
                    ok++;
                } catch (Exception ignored) { }
            }
            final int done = ok, miss = todo.size() - ok;
            runOnUiThread(() -> new AlertDialog.Builder(this).setTitle("Listo ✅")
                    .setMessage(done + " fotos guardadas en:\nImágenes → Amigo Renta Recibos → " + m + (miss > 0 ? "\n\n" + miss + " no se pudieron copiar (la foto original ya no está en el teléfono)." : "") + "\n\nLas ves en la Galería, en el álbum «" + m + "».")
                    .setPositiveButton("OK", null).show());
        }).start();
    }

    void pasteDialog() {
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(4), dp(20), 0);
        EditText e = input("Pega aquí el texto del correo de INTERAC e-Transfer", TXT_MULTI);
        e.setMinLines(5);
        box.addView(e);
        new AlertDialog.Builder(this).setTitle("Pegar e-Transfer").setView(box)
                .setPositiveButton("Leer", (dlg, w) -> {
                    JSONObject d = Store.handleIncoming(this, e.getText().toString(), System.currentTimeMillis(), "manual");
                    reload();
                    if (d == null) toast("No encontré un e-Transfer en ese texto");
                    else toast(d.optString("status").equals("aplicado") ? "Pago aplicado ✅" : "Leído. Asígnalo a un inquilino.");
                    refresh();
                }).setNegativeButton("Cancelar", null).show();
    }

    // ============================ más ============================
    void more() {
        setHeader("Más", null, "☰", false);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.addView(menuRow("🚗", "Ruta de cobranza", "Checklist del día: por dónde pasar a cobrar y quién ya pagó", v -> open(this::cobScreen)));
        c.addView(divider());
        c.addView(menuRow("📣", "Mensaje a inquilinos", "A todos los de Amigo, de Callao o todos · por WhatsApp o correo", v -> open(this::bcScreen)));
        c.addView(divider());
        c.addView(menuRow("👔", "Enviar al " + mgrName(), "Resumen del mes o reporte de Excel por WhatsApp", v -> managerMenu()));
        c.addView(divider());
        c.addView(menuRow("📊", "Exportar reporte a Excel", "Elige el mes y dónde guardarlo", v -> exportDialog()));
        c.addView(divider());
        c.addView(menuRow("🟢", "Exportar para QuickBooks Online", Store.qbo(this) ? "Clientes y pagos (las facturas se hacen en QuickBooks)" : "Clientes y facturas del mes listos para importar", v -> qboDialog()));
        c.addView(divider());
        c.addView(menuRow("🧾", "Guardar los recibos en una carpeta", "Fotos de pagos, egresos e ingresos del mes · Imágenes → Amigo Renta Recibos", v -> receiptsFolderDialog()));
        c.addView(menuRow("📗", "Cargar la tabla del mes (Excel)", "Clientes, unidades, rentas, Amigo o Callao · .xlsx o .csv", v -> pickImportFile()));
        c.addView(divider());
        c.addView(menuRow("📤", "Exportar inquilinos en el formato de mi tabla", "Las mismas columnas de tu Excel del mes, con los que agregaste a mano", v -> tableExportDialog()));
        c.addView(divider());
        c.addView(menuRow("📥", "Pegar lista de inquilinos", "Pega filas copiadas desde Excel", v -> importDialog()));
        c.addView(divider());
        c.addView(menuRow(Sync.on(this) ? "🌐" : "⚪", "Compartir con el Manager y el equipo", teamSub(), v -> open(this::teamScreen)));
        c.addView(divider());
        c.addView(menuRow("⚙️", "Ajustes", "Día de pago, días de gracia, correo para e-Transfer", v -> open(this::settings)));
        c.addView(divider());
        c.addView(menuRow("💾", "Copia de seguridad", "Guardar, enviar o restaurar tus datos", v -> Backup.menu(this)));
        c.addView(divider());
        c.addView(menuRow("ℹ️", "Acerca de", "Rentas Amigo Renta · versión 4.0", null));
        p.addView(c);
        TextView info = tv("📁 Cada mes, al abrir la app, se guarda solo el reporte del mes anterior en Descargas → Amigo Renta Reportes" + (Store.getB(this, "autoReport", true) ? "." : " (desactivado en Ajustes)."), 13, MUT, false);
        info.setPadding(dp(18), dp(10), dp(18), 0);
        p.addView(info);
        show(scroll(p), true, null, null);
    }

    String teamSub() {
        if (!Sync.on(this)) return "Desactivado · toca para que el Manager vea las rentas y registre pagos";
        long ok = Store.sp(this).getLong("lastSyncOk", 0);
        return ok > 0 ? "Sincronizado " + Store.dateTime(ok) : "Conectado · aún sin sincronizar";
    }

    void teamScreen() {
        setHeader("Compartir con el Manager", Sync.on(this) ? "Conectado" : "Desactivado", null, true);
        formMode();
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.addView(tv("🌐  Rentas en el iPhone del Manager", 16, TXT, true));
        c.addView(tv("Con esto los inquilinos, los meses y los pagos se comparten con la app web del Manager. Él ve quién pagó y quién debe, y puede registrar pagos; esos pagos te llegan aquí solos con un aviso.", 13, MUT, false));
        EditText url = input("https://amigorentacliente.muddy-pine-c15e.workers.dev", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setText(Store.get(this, "srvUrl", ""));
        EditText key = input("La misma clave del servidor de Clientes", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        key.setText(Store.get(this, "srvKey", ""));
        c.addView(labeled("Dirección del servidor del equipo", url));
        c.addView(labeled("Clave", key));
        c.addView(tv("Es el servidor de Clientes y Citas, no el de QuickBooks.", 12, MUT, false));
        long ok = Store.sp(this).getLong("lastSyncOk", 0);
        final TextView st = tv(ok > 0 ? "Última sincronización: " + Store.dateTime(ok) : "Todavía no se ha sincronizado", 13, MUT, false);
        st.setPadding(0, dp(10), 0, 0);
        c.addView(st);
        p.addView(c);
        p.addView(button("Probar y sincronizar", PRI2, v -> {
            String u = url.getText().toString().trim(), k = key.getText().toString().trim();
            if (u.isEmpty() || k.isEmpty()) { toast("Escribe la dirección y la clave"); return; }
            Store.putS(this, "srvUrl", u);
            Store.putS(this, "srvKey", k);
            st.setText("⏳ Conectando… (la primera vez sube todos los inquilinos y pagos)");
            st.setTextColor(MUT);
            final android.content.Context app = getApplicationContext();
            new Thread(() -> {
                TeamNet.Res r = TeamNet.request(app, "GET", "/api/ping", null, null, null);
                String err = r.error != null || r.code != 200 ? TeamNet.errorOf(r.code, r.body, r.error) : null;
                if (err == null) err = Sync.run(app);
                final String e = err;
                runOnUiThread(() -> {
                    if (e == null) {
                        st.setText("✅ Sincronizado");
                        st.setTextColor(GRN);
                        Sync.schedule(app);
                        needReload = true;
                    } else {
                        st.setText("⚠️ " + e);
                        st.setTextColor(RED);
                    }
                });
            }).start();
        }));
        LinearLayout h = card();
        h.addView(tv("ℹ️  Cómo funciona", 15, TXT, true));
        h.addView(tv("• Se sincroniza sola cuando cambias algo, al abrir la app y cada 15 minutos.\n"
                + "• El Manager entra desde el iPhone a la dirección del servidor + /m, con la misma clave y su nombre.\n"
                + "• Los pagos que él registre te llegan con un aviso 💵 y quedan en el mes del inquilino; desde aquí puedes mandar el recibo.\n"
                + "• Las fotos de comprobante que suba el Manager se bajan solas a Imágenes → Amigo Renta Comprobantes y quedan en el pago.\n"
                + "• La clave no se guarda en las copias de seguridad.", 13, MUT, false));
        LinearLayout h2 = card();
        h2.addView(tv("👥  Otra persona del equipo con Android", 15, TXT, true));
        h2.addView(tv("1. Instala en su teléfono esta misma app (versión 3.8 o más nueva).\n"
                + "2. Antes de agregar o importar nada, entra a ☰ → Compartir con el Manager y el equipo, pon la misma dirección y la clave, y toca «Probar y sincronizar». Le llegan todos los inquilinos y pagos.\n"
                + "3. Desde ahí los dos pueden agregar inquilinos y registrar pagos a la vez: cada teléfono numera los suyos aparte y no se pisan.\n"
                + "• Que no importe tu Excel por su cuenta: si lo hace antes de sincronizar se duplicarían los inquilinos.\n"
                + "• La clave dásela en privado: con ella ve todos los inquilinos y montos.", 13, MUT, false));
        p.addView(h2);
        if (Sync.on(this)) {
            TextView off = tv("Dejar de compartir", 14, RED, true);
            off.setPadding(0, dp(12), 0, 0);
            off.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("¿Dejar de compartir?")
                    .setMessage("El Manager deja de ver los cambios nuevos. Los datos de este teléfono no se tocan.")
                    .setPositiveButton("Dejar de compartir", (d, w) -> {
                        Store.putS(this, "srvKey", "");
                        Store.sp(this).edit().remove("syncSnap").remove("teamPull").apply();
                        goBack();
                    }).setNegativeButton("Cancelar", null).show());
            h.addView(off);
        }
        p.addView(h);
        show(scroll(p), false, null, null);
    }


    // ============================ 🚗 Ruta de cobranza (compartida con el Manager y Customer Service) ============================
    String cobDate = null;
    List<JSONObject> cobAll = null;
    boolean cobBusy = false;

    static String isoAdd(String iso, int days) { try { return java.time.LocalDate.parse(iso).plusDays(days).toString(); } catch (Exception e) { return iso; } }
    static String dayLabel(String iso) {
        try { java.time.LocalDate d = java.time.LocalDate.parse(iso); String s = d.format(java.time.format.DateTimeFormatter.ofPattern("EEE d MMM", new Locale("es"))); return s.substring(0, 1).toUpperCase(new Locale("es")) + s.substring(1); } catch (Exception e) { return iso; }
    }

    List<JSONObject> cobCache() {
        List<JSONObject> r = new ArrayList<>();
        try { JSONArray a = new JSONArray(Store.get(this, "cobCache", "[]")); for (int i = 0; i < a.length(); i++) r.add(a.getJSONObject(i)); } catch (Exception e) { }
        return r;
    }
    void cobSaveCache() { JSONArray a = new JSONArray(); if (cobAll != null) for (JSONObject x : cobAll) a.put(x); Store.putS(this, "cobCache", a.toString()); }

    void cobLoad() {
        if (cobBusy || !TeamNet.ready(this)) return;
        cobBusy = true;
        cobFlush();
        TeamNet.call(this, "GET", "/api/changes?kinds=rcob&since=0", null, null, null, (code, body, err) -> {
            cobBusy = false;
            if (err != null || code != 200) { toast("⚠️ " + TeamNet.errorOf(code, body, err)); return; }
            try {
                JSONArray in = new JSONObject(TeamNet.text(body)).getJSONArray("records");
                List<JSONObject> l = new ArrayList<>();
                String old = isoAdd(Store.today(), -60);
                for (int i = 0; i < in.length(); i++) { JSONObject r = in.getJSONObject(i), d = r.getJSONObject("data"); if (d.optBoolean("deleted") || d.optString("date").compareTo(old) < 0) continue; d.put("_id", r.optString("id")); l.add(d); }
                cobAll = l; cobSaveCache();
                if (!stack.isEmpty() && "cob".equals(cobOn)) refresh();
            } catch (Exception e) { }
        });
    }
    String cobOn = "";

    /** Guarda un cambio: se ve al momento y se manda al servidor (si no hay internet, queda en cola). */
    void cobPush(String id, JSONObject set) {
        if (cobAll == null) cobAll = cobCache();
        JSONObject cur = null; for (JSONObject x : cobAll) if (x.optString("_id").equals(id)) cur = x;
        if (cur == null) { cur = new JSONObject(); Store.put(cur, "_id", id); cobAll.add(cur); }
        for (java.util.Iterator<String> it = set.keys(); it.hasNext(); ) { String k = it.next(); Store.put(cur, k, set.opt(k)); }
        if (set.optBoolean("deleted")) cobAll.remove(cur);
        cobSaveCache();
        try {
            JSONArray q = new JSONArray(Store.get(this, "cobQ", "[]"));
            q.put(new JSONObject().put("kind", "rcob").put("id", id).put("set", set));
            Store.putS(this, "cobQ", q.toString());
        } catch (Exception e) { }
        cobFlush();
    }

    void cobFlush() {
        String q = Store.get(this, "cobQ", "[]");
        if (q.equals("[]") || !TeamNet.ready(this)) return;
        try {
            byte[] b = new JSONObject().put("records", new JSONArray(q)).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
            TeamNet.call(this, "POST", "/api/push", b, "application/json", null, (code, body, err) -> {
                if (err == null && code == 200) {
                    try { JSONArray now = new JSONArray(Store.get(this, "cobQ", "[]")), sent = new JSONArray(q), rest = new JSONArray(); for (int i = sent.length(); i < now.length(); i++) rest.put(now.get(i)); Store.putS(this, "cobQ", rest.toString()); } catch (Exception e) { }
                }
            });
        } catch (Exception e) { }
    }

    List<JSONObject> cobDay(String d) {
        List<JSONObject> r = new ArrayList<>();
        if (cobAll == null) cobAll = cobCache();
        for (JSONObject x : cobAll) if (d.equals(x.optString("date")) && !x.optBoolean("deleted")) r.add(x);
        Collections.sort(r, (a, b) -> {
            int da = a.optString("st").isEmpty() ? 0 : 1, db = b.optString("st").isEmpty() ? 0 : 1;
            if (da != db) return da - db;
            String ta = a.optString("time", "99"), tb = b.optString("time", "99");
            if (ta.isEmpty()) ta = "99"; if (tb.isEmpty()) tb = "99";
            int c = ta.compareTo(tb); if (c != 0) return c;
            return (a.optString("property") + a.optString("name")).compareToIgnoreCase(b.optString("property") + b.optString("name"));
        });
        return r;
    }

    double owedNow(JSONObject t) { JSONObject r = Store.rec(recs, t.optInt("id"), Store.thisMonth(), false); return Math.max(0, Store.due(t, r) - Store.paid(r)); }

    /** 🥧 Gráfico de pastel: cobrado (amarillo) y falta por cobrar (rojo), con el % de avance en el centro. */
    class Pie extends View {
        double a, b;
        Pie(double cobrado, double falta) { super(MainActivity.this); a = cobrado; b = falta; }
        @Override protected void onDraw(android.graphics.Canvas c) {
            float w = getWidth(), h = getHeight(), d = Math.min(w, h) - dp(8), x0 = (w - d) / 2, y0 = (h - d) / 2;
            android.graphics.RectF r = new android.graphics.RectF(x0, y0, x0 + d, y0 + d);
            android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            double tot = a + b; float sa = tot <= 0 ? 0 : (float) (360 * a / tot);
            p.setColor(0xFFE5E7EB); c.drawArc(r, 0, 360, true, p);
            if (tot > 0) { p.setColor(PAY_FULL); c.drawArc(r, -90, sa, true, p); p.setColor(PAY_NONE); c.drawArc(r, -90 + sa, 360 - sa, true, p); }
            p.setColor(Color.WHITE); c.drawCircle(w / 2, h / 2, d * 0.31f, p);
            p.setColor(TXT); p.setTextAlign(android.graphics.Paint.Align.CENTER); p.setFakeBoldText(true); p.setTextSize(dp(20));
            c.drawText((tot <= 0 ? 0 : Math.round(100 * a / tot)) + "%", w / 2, h / 2 + dp(4), p);
            p.setFakeBoldText(false); p.setTextSize(dp(10)); p.setColor(MUT); c.drawText("avance", w / 2, h / 2 + dp(17), p);
        }
    }
    String cobPay = "todos";

    static final String[][] COB_ST = {{"cobrado", "✅", "Cobrado"}, {"noestaba", "🚫", "No estaba"}, {"otrodia", "📅", "Pasar otro día"}};
    static String[] cobSt(String k) { for (String[] x : COB_ST) if (x[0].equals(k)) return x; return null; }

    void cobScreen() {
        cobOn = "cob";
        if (cobDate == null) cobDate = Store.today();
        if (cobAll == null) { cobAll = cobCache(); cobLoad(); }
        List<JSONObject> L = cobDay(cobDate);
        int done = 0; double got = 0, exp = 0;
        for (JSONObject x : L) { if (!x.optString("st").isEmpty()) done++; got += x.optDouble("paid", 0); double am = x.optDouble("amount", 0); if (am <= 0) { JSONObject t0 = Store.tenant(tenants, x.optInt("tid", -1)); if (t0 != null) am = owedNow(t0) + x.optDouble("paid", 0); } exp += am; }
        setHeader("Ruta de cobranza", dayLabel(cobDate) + " · " + done + " de " + L.size(), null, true);
        LinearLayout p = vbox();
        if (!TeamNet.ready(this)) p.addView(empty("Para compartir la ruta con el Manager y Customer Service, conecta la app con el servidor (Más → Ajustes → Servidor del equipo). Mientras tanto se guarda solo en este teléfono."));
        LinearLayout dc = hbox();
        String td = Store.today();
        dc.addView(chip("Hoy", cobDate.equals(td), v -> { cobDate = td; refresh(); }));
        dc.addView(chip("Mañana", cobDate.equals(isoAdd(td, 1)), v -> { cobDate = isoAdd(td, 1); refresh(); }));
        dc.addView(chip(dayLabel(isoAdd(td, 2)), cobDate.equals(isoAdd(td, 2)), v -> { cobDate = isoAdd(td, 2); refresh(); }));
        boolean other = !cobDate.equals(td) && !cobDate.equals(isoAdd(td, 1)) && !cobDate.equals(isoAdd(td, 2));
        dc.addView(chip(other ? "📅 " + dayLabel(cobDate) : "📅 Otro día", other, v -> pickDate(cobDate, d -> { cobDate = d; refresh(); })));
        LinearLayout dcw = vbox(); dcw.setPadding(dp(10), dp(6), dp(10), 0); dcw.addView(hscroll(dc)); p.addView(dcw);
        // 👤 quién cobra este día (Hugo por defecto): le sale la ruta en su App Operativa
        String cw = cobWhoOf(L);
        LinearLayout wr = hbox();
        wr.addView(tv("  👤 Cobra: ", 14, TXT, true));
        List<String> cl = new ArrayList<>(java.util.Arrays.asList("Hugo"));
        try { JSONArray a = new JSONArray(Store.get(this, "cobWhoList", "[]")); for (int i = 0; i < a.length(); i++) if (!cl.contains(a.getString(i))) cl.add(a.getString(i)); } catch (Exception e) { }
        for (String n : cl) wr.addView(chip(n, n.equals(cw), v -> cobSetWho(n)));
        wr.addView(chip("＋ Otro", false, v -> askText("¿Quién cobra?", "Nombre", "", s2 -> { String n = s2.trim(); if (n.isEmpty()) return; try { JSONArray a = new JSONArray(Store.get(this, "cobWhoList", "[]")); a.put(n); Store.putS(this, "cobWhoList", a.toString()); } catch (Exception e) { } cobSetWho(n); })));
        LinearLayout wrw = vbox(); wrw.setPadding(dp(10), 0, dp(10), 0); wrw.addView(hscroll(wr)); p.addView(wrw);

        LinearLayout top = card();
        top.addView(tv(L.isEmpty() ? "No hay paradas este día" : done + " de " + L.size() + " visitados", 17, TXT, true));
        if (!L.isEmpty()) {
            double falta = Math.max(0, exp - got);
            LinearLayout pr = hbox();
            pr.addView(new Pie(got, falta), new LinearLayout.LayoutParams(dp(130), dp(130)));
            LinearLayout lg = vbox(); lg.setPadding(dp(14), 0, 0, 0);
            lg.addView(tv("● Cobrado", 13, PAY_FULL, true)); lg.addView(tv(money(got), 18, TXT, true));
            lg.addView(gap(6));
            lg.addView(tv("● Falta por cobrar", 13, PAY_NONE, true)); lg.addView(tv(money(falta), 18, TXT, true));
            lg.addView(gap(6));
            lg.addView(tv("Esperado " + money(exp), 12, MUT, false));
            pr.addView(lg, new LinearLayout.LayoutParams(0, -2, 1f));
            top.addView(pr);
        }
        p.addView(top);
        if (!L.isEmpty()) {
            LinearLayout pf = hbox();
            String[][] F = {{"todos", "Todos"}, {"etransfer", "💳 e-Transfer"}, {"cash", "💵 Cash"}};
            for (String[] fx : F) pf.addView(chip(fx[1], cobPay.equals(fx[0]), v -> { cobPay = fx[0]; refresh(); }));
            LinearLayout pfw = vbox(); pfw.setPadding(dp(10), 0, dp(10), 0); pfw.addView(hscroll(pf));
            LinearLayout leg = hbox(); for (int st2 = 2; st2 >= 0; st2--) leg.addView(tv("● " + payLbl(st2) + "   ", 12, payCol(st2), true));
            pfw.addView(hscroll(leg));
            p.addView(pfw);
        }

        if (!L.isEmpty()) {
            LinearLayout c = card();
            String lastProp = null;
            for (JSONObject x : L) {
                String[] st = cobSt(x.optString("st"));
                JSONObject tx = Store.tenant(tenants, x.optInt("tid", -1));
                String pk = tx != null ? payKind(tx) : x.optString("pay", "otro");
                if (!cobPay.equals("todos") && !pk.equals(cobPay)) continue;
                int ps = tx != null ? payState(tx) : 0;
                LinearLayout r = hbox();
                r.setPadding(dp(8), dp(9), dp(8), dp(9));
                r.setBackground(round(payBg(ps), 12));
                TextView ck = tv(st == null ? "⬜" : st[1], 24, TXT, false);
                ck.setPadding(0, 0, dp(12), 0);
                r.addView(ck);
                LinearLayout tt = vbox();
                tt.addView(tv((x.optString("time").isEmpty() ? "" : "🕐 " + slotLbl(x.optString("time")) + " · ") + x.optString("name"), 16, st == null ? TXT : MUT, true));
                tt.addView(tv("● " + payLbl(ps) + " · " + payKindLbl(pk), 12, payCol(ps), true));
                tt.addView(tv(x.optString("property") + (x.optString("unit").isEmpty() ? "" : " · " + x.optString("unit")) + (x.optDouble("amount", 0) > 0 ? " · " + money(x.optDouble("amount", 0)) : ""), 13, MUT, false));
                if (st != null) tt.addView(tv(st[2] + (x.optDouble("paid", 0) > 0 ? " " + money(x.optDouble("paid", 0)) : "") + (x.optString("method").isEmpty() ? "" : " · " + x.optString("method")) + (x.optString("by").isEmpty() ? "" : " · " + x.optString("by")), 13, st[0].equals("cobrado") ? GRN : st[0].equals("noestaba") ? RED : YEL, true));
                if (!x.optString("note").isEmpty()) tt.addView(tv("📝 " + x.optString("note"), 13, TXT, false));
                if ("cs".equals(x.optString("src"))) tt.addView(tv("💬 Lo pidió por Customer Service", 12, PRI2, false));
                r.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
                r.setOnClickListener(v -> cobMark(x));
                ck.setOnClickListener(v -> { if (cobSt(x.optString("st")) == null) cobPaid(x); else cobMark(x); });
                c.addView(r);
                c.addView(gap(6));
            }
            p.addView(c);
            p.addView(tv("   Toca el cuadrito para marcar cobrado, o la fila para más opciones.", 12, MUT, false));
        }
        p.addView(button("＋ Agregar inquilinos a este día", PRI2, v -> cobAdd(false)));
        p.addView(outline("＋ Agregar a los que deben de " + Store.monthName(Store.thisMonth()).replaceAll("\\s+\\d{4}$", ""), PRI2, v -> cobAdd(true)));
        if (!L.isEmpty()) p.addView(outline("💬 Mandar la ruta por WhatsApp (a quien cobra)", GRN, v -> waShareAny(cobText(L), null)));
        p.addView(outline("🔄 Actualizar", MUT, v -> { cobLoad(); toast("Actualizando…"); }));
        show(scroll(p), false, null, null);
    }

    /** Quién cobra el día: el que tengan las paradas o, si no, el último elegido (Hugo). */
    String cobWhoOf(List<JSONObject> L) { for (JSONObject x : L) if (!x.optString("cob").isEmpty()) return x.optString("cob"); return Store.get(this, "cobWho", "Hugo"); }
    void cobSetWho(String n) {
        Store.putS(this, "cobWho", n);
        for (JSONObject x : cobDay(cobDate)) if (!n.equals(x.optString("cob"))) { JSONObject set = new JSONObject(); Store.put(set, "cob", n); cobPush(x.optString("_id"), set); }
        toast("Cobra: " + n); refresh();
    }
    String cobText(List<JSONObject> L) {
        StringBuilder b = new StringBuilder("🚗 *Ruta de cobro* – " + dayLabel(cobDate) + " · cobra " + cobWhoOf(L) + "\n");
        int i = 1;
        for (JSONObject x : L) {
            String[] st = cobSt(x.optString("st"));
            b.append("\n").append(i++).append(". ").append(st == null ? "⬜" : st[1]).append(" ").append(x.optString("time").isEmpty() ? "" : slotLbl(x.optString("time")) + " ")
                    .append(x.optString("name")).append(" · ").append(x.optString("property")).append(x.optString("unit").isEmpty() ? "" : " " + x.optString("unit"))
                    .append(x.optDouble("amount", 0) > 0 ? " · " + money(x.optDouble("amount", 0)) : "").append(x.optString("note").isEmpty() ? "" : " (" + x.optString("note") + ")");
        }
        return b.append("\n\nMarca cada uno en la app (Rentas → Ruta de cobranza) o en la página del Manager.").toString();
    }

    // ---- colores del estado de pago del mes: amarillo = completo, verde = parcial, rojo = no ha pagado
    static final int PAY_FULL = 0xFFEAB308, PAY_FULL_BG = 0xFFFEF9C3, PAY_PART = 0xFF16A34A, PAY_PART_BG = 0xFFDCFCE7, PAY_NONE = 0xFFDC2626, PAY_NONE_BG = 0xFFFEE2E2;
    /** 0 = no ha pagado, 1 = parcial, 2 = completo (del mes actual). */
    int payState(JSONObject t) {
        if (t == null) return 0;
        JSONObject r = Store.rec(recs, t.optInt("id"), Store.thisMonth(), false);
        double due = Store.due(t, r), paid = Store.paid(r);
        if (paid <= 0.5) return due <= 0.5 ? 2 : 0;
        return paid + 0.5 >= due ? 2 : 1;
    }
    static int payCol(int st) { return st == 2 ? PAY_FULL : st == 1 ? PAY_PART : PAY_NONE; }
    static int payBg(int st) { return st == 2 ? PAY_FULL_BG : st == 1 ? PAY_PART_BG : PAY_NONE_BG; }
    static String payLbl(int st) { return st == 2 ? "Pago completo" : st == 1 ? "Pago parcial" : "No ha pagado"; }

    /** Cómo paga normalmente: la «Forma de pago» de la tabla o, si no, la de su último pago. «etransfer», «cash» u «otro». */
    String payKind(JSONObject t) {
        String m = t.optString("payMethod");
        if (m.trim().isEmpty()) {
            long best = -1;
            for (JSONObject r : recs) {
                if (r.optInt("tid", -1) != t.optInt("id")) continue;
                JSONArray p = r.optJSONArray("payments");
                for (int i = 0; p != null && i < p.length(); i++) { JSONObject x = p.optJSONObject(i); if (x != null && x.optLong("date") >= best) { best = x.optLong("date"); m = x.optString("method"); } }
            }
        }
        String n = Store.norm(m);
        if (n.contains("TRANS") || n.contains("E-T") || n.contains("ETRANS") || n.contains("INTERAC")) return "etransfer";
        if (n.contains("CASH") || n.contains("EFECT")) return "cash";
        return "otro";
    }
    static String payKindLbl(String k) { return k.equals("etransfer") ? "💳 e-Transfer" : k.equals("cash") ? "💵 Cash" : "❔ Sin forma de pago"; }

    /** Horarios para pasar a cobrar: lunes a viernes 3–9 pm y fines de semana 12–9 pm. {valor, texto} */
    static String[][] cobSlots(String iso) {
        int dow = 1; try { dow = java.time.LocalDate.parse(iso).getDayOfWeek().getValue(); } catch (Exception e) { }
        if (dow >= 6) return new String[][]{{"12:00-14:00", "12–2 pm"}, {"14:00-16:00", "2–4 pm"}, {"16:00-18:00", "4–6 pm"}, {"18:00-21:00", "6–9 pm"}};
        return new String[][]{{"15:00-17:00", "3–5 pm"}, {"17:00-19:00", "5–7 pm"}, {"19:00-21:00", "7–9 pm"}};
    }
    static String slotLbl(String v) {
        if (v == null) return "";
        for (String[][] L : new String[][][]{cobSlots("2026-10-19"), cobSlots("2026-10-24")}) for (String[] x : L) if (x[0].equals(v)) return x[1];
        return v;
    }
    /** Fila de horarios para elegir (con «Otra hora»). */
    View slotPicker(String iso, String cur, String[] out) {
        LinearLayout box = vbox();
        LinearLayout row = hbox();
        String[][] sl = cobSlots(iso);
        TextView[] cs = new TextView[sl.length + 1];
        EditText other = input("Otra hora (opcional)", InputType.TYPE_CLASS_TEXT);
        boolean known = false; for (String[] x : sl) if (x[0].equals(cur)) known = true;
        other.setVisibility(!known && cur != null && !cur.isEmpty() ? View.VISIBLE : View.GONE);
        if (!known && cur != null) other.setText(cur);
        out[0] = cur == null ? "" : cur;
        for (int i = 0; i <= sl.length; i++) {
            final int k = i;
            String lbl = i < sl.length ? sl[i][1] : "✏️ Otra";
            cs[i] = chip(lbl, i < sl.length ? sl[i][0].equals(cur) : (!known && cur != null && !cur.isEmpty()), v -> {
                for (int j = 0; j < cs.length; j++) styleChip(cs[j], j == k);
                if (k < sl.length) { out[0] = sl[k][0]; other.setVisibility(View.GONE); } else { other.setVisibility(View.VISIBLE); out[0] = other.getText().toString().trim(); }
            });
            row.addView(cs[i]);
        }
        other.addTextChangedListener(new TextWatcher() { public void beforeTextChanged(CharSequence a, int b, int d, int e) { } public void onTextChanged(CharSequence a, int b, int d, int e) { } public void afterTextChanged(Editable e) { if (other.getVisibility() == View.VISIBLE) out[0] = e.toString().trim(); } });
        box.addView(tv((java.time.LocalDate.parse(iso).getDayOfWeek().getValue() >= 6 ? "Fin de semana" : "Lunes a viernes") + " · horario de cobro", 12, MUT, true));
        box.addView(hscroll(row));
        box.addView(other);
        return box;
    }

    /** Elegir inquilinos para la ruta: buscador por nombre o casa, filtro e-Transfer / Cash y colores del pago del mes. */
    void cobAdd(boolean owing) {
        java.util.Set<Integer> already = new java.util.HashSet<>();
        for (JSONObject x : cobDay(cobDate)) already.add(x.optInt("tid"));
        List<JSONObject> act = new ArrayList<>();
        for (JSONObject t : tenants) if (!t.optBoolean("inactive") && !t.optString("name").trim().isEmpty() && (!owing || owedNow(t) > 0.5)) act.add(t);
        Collections.sort(act, (a, b) -> (a.optString("property") + a.optString("name")).compareToIgnoreCase(b.optString("property") + b.optString("name")));
        if (act.isEmpty()) { toast(owing ? "Nadie debe este mes 🎉" : "No hay inquilinos"); return; }
        java.util.Set<Integer> sel = new java.util.HashSet<>();
        if (owing) for (JSONObject t : act) if (!already.contains(t.optInt("id"))) sel.add(t.optInt("id"));
        final String[] q = {""}, mf = {"todos"};
        LinearLayout root = vbox(); root.setPadding(dp(14), dp(6), dp(14), 0);
        EditText search = input("🔍 Buscar por nombre o propiedad", InputType.TYPE_CLASS_TEXT);
        root.addView(search);
        LinearLayout fr = hbox();
        String[][] F = {{"todos", "Todos"}, {"etransfer", "💳 e-Transfer"}, {"cash", "💵 Cash"}};
        TextView[] fc = new TextView[F.length];
        LinearLayout list = vbox();
        TextView count = tv("", 13, PRI2, true);
        Runnable[] draw = {null};
        for (int i = 0; i < F.length; i++) { final int k = i; fc[i] = chip(F[i][1], i == 0, v -> { mf[0] = F[k][0]; for (int j = 0; j < F.length; j++) styleChip(fc[j], j == k); draw[0].run(); }); fr.addView(fc[i]); }
        root.addView(hscroll(fr));
        LinearLayout leg = hbox();
        for (int st = 2; st >= 0; st--) { TextView d = tv("● " + payLbl(st) + "   ", 12, payCol(st), true); leg.addView(d); }
        root.addView(hscroll(leg));
        root.addView(count);
        ScrollView sv = new ScrollView(this); sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, dp(340)));
        draw[0] = () -> {
            list.removeAllViews();
            String qq = Store.norm(q[0]); int shown = 0;
            for (JSONObject t : act) {
                if (!qq.isEmpty() && !Store.norm(t.optString("name") + " " + t.optString("property") + " " + t.optString("unit")).contains(qq)) continue;
                if (!mf[0].equals("todos") && !payKind(t).equals(mf[0])) continue;
                shown++;
                int st = payState(t), id = t.optInt("id");
                LinearLayout r = hbox();
                r.setPadding(dp(8), dp(8), dp(8), dp(8));
                r.setBackground(round(payBg(st), 10));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(3), 0, dp(3)); r.setLayoutParams(lp);
                android.widget.CheckBox cb = new android.widget.CheckBox(this);
                cb.setChecked(sel.contains(id));
                cb.setOnCheckedChangeListener((b, on) -> { if (on) sel.add(id); else sel.remove(id); count.setText(sel.size() + " elegidos"); });
                r.addView(cb);
                LinearLayout tt = vbox();
                tt.addView(tv(t.optString("name") + (already.contains(id) ? "  (ya está en la ruta)" : ""), 15, TXT, true));
                tt.addView(tv(t.optString("property") + (t.optString("unit").isEmpty() ? "" : " · " + t.optString("unit")) + " · " + payKindLbl(payKind(t)), 12, MUT, false));
                tt.addView(tv("● " + payLbl(st) + (owedNow(t) > 0.5 ? " · debe " + money(owedNow(t)) : ""), 12, payCol(st), true));
                r.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
                r.setOnClickListener(v -> cb.toggle());
                list.addView(r);
            }
            if (shown == 0) list.addView(tv("Nadie con ese filtro.", 14, MUT, false));
            count.setText(sel.size() + " elegidos · " + shown + " en la lista");
        };
        search.addTextChangedListener(new TextWatcher() { public void beforeTextChanged(CharSequence a, int b, int d, int e) { } public void onTextChanged(CharSequence a, int b, int d, int e) { } public void afterTextChanged(Editable e) { q[0] = e.toString(); draw[0].run(); } });
        draw[0].run();
        new AlertDialog.Builder(this).setTitle(owing ? "Los que deben · " + dayLabel(cobDate) : "¿A quién visitar el " + dayLabel(cobDate) + "?").setView(root)
                .setPositiveButton("Siguiente", (d, w) -> {
                    List<JSONObject> pick = new ArrayList<>(); for (JSONObject t : act) if (sel.contains(t.optInt("id"))) pick.add(t);
                    if (pick.isEmpty()) { toast("No elegiste a nadie"); return; }
                    String[] slot = {""};
                    EditText nt = input("Nota (opcional), ej. dejar en el buzón", TXT_MULTI);
                    LinearLayout box = vbox(); box.setPadding(dp(16), dp(8), dp(16), 0); box.addView(slotPicker(cobDate, "", slot)); box.addView(nt);
                    new AlertDialog.Builder(this).setTitle(pick.size() + " a la ruta del " + dayLabel(cobDate)).setView(box)
                            .setPositiveButton("Agregar", (d2, w2) -> {
                                for (JSONObject t : pick) {
                                    JSONObject set = new JSONObject();
                                    Store.put(set, "tid", t.optInt("id")); Store.put(set, "name", t.optString("name")); Store.put(set, "phone", t.optString("phone"));
                                    Store.put(set, "property", t.optString("property")); Store.put(set, "unit", t.optString("unit")); Store.put(set, "date", cobDate);
                                    Store.put(set, "time", slot[0]); Store.put(set, "note", nt.getText().toString().trim()); Store.put(set, "pay", payKind(t));
                                    Store.put(set, "amount", Math.round(owedNow(t) * 100) / 100.0); Store.put(set, "src", "app"); Store.put(set, "cob", cobWhoOf(cobDay(cobDate))); Store.put(set, "deleted", false); Store.put(set, "created", System.currentTimeMillis());
                                    cobPush("cob-" + cobDate + "-" + t.optInt("id"), set);
                                }
                                toast("Agregados ✅"); refresh();
                            }).setNegativeButton("Cancelar", null).show();
                }).setNegativeButton("Cancelar", null).show();
    }

    /** ✅ Cobrado: cuánto y cómo; después se puede registrar el pago en la app. */
    void cobPaid(JSONObject x) {
        EditText am = input("¿Cuánto cobró?", DEC);
        if (x.optDouble("amount", 0) > 0) am.setText(String.valueOf(x.optDouble("amount", 0)).replaceAll("\\.0$", ""));
        String[] m = {"Efectivo", "Cheque", "e-Transfer", "Otro"}; final String[] pick = {m[0]};
        LinearLayout box = vbox(); box.setPadding(dp(16), dp(8), dp(16), 0); box.addView(am);
        LinearLayout ms = hbox(); TextView[] cs = new TextView[m.length];
        for (int i = 0; i < m.length; i++) { final int k = i; cs[i] = chip(m[i], i == 0, v -> { pick[0] = m[k]; for (int j = 0; j < m.length; j++) styleChip(cs[j], j == k); }); ms.addView(cs[i]); }
        box.addView(hscroll(ms));
        new AlertDialog.Builder(this).setTitle("✅ Cobrado · " + x.optString("name")).setView(box)
                .setPositiveButton("Guardar", (d, w) -> {
                    JSONObject set = new JSONObject();
                    Store.put(set, "st", "cobrado"); Store.put(set, "paid", num(am.getText().toString())); Store.put(set, "method", pick[0]);
                    Store.put(set, "doneAt", System.currentTimeMillis()); Store.put(set, "by", "Oficina");
                    cobPush(x.optString("_id"), set); refresh();
                    int tid = x.optInt("tid", -1);
                    if (tid >= 0 && Store.tenant(tenants, tid) != null)
                        new AlertDialog.Builder(this).setMessage("¿Registrar también el pago de " + x.optString("name") + " en Rentas?").setPositiveButton("Sí, registrar", (d2, w2) -> open(() -> payScreen(tid, Store.thisMonth()))).setNegativeButton("Después", null).show();
                }).setNegativeButton("Cancelar", null).show();
    }

    void cobMark(JSONObject x) {
        String[] opts = {"✅ Cobrado", "🚫 No estaba", "📅 Pasar a otro día", "↩️ Desmarcar", "💬 Escribirle por WhatsApp", "📞 Llamar", "🗺️ Abrir en el mapa", "🕐 Cambiar horario o nota", "🗑️ Quitar de la ruta"};
        new AlertDialog.Builder(this).setTitle(x.optString("name") + " · " + x.optString("property")).setItems(opts, (d, w) -> {
            String id = x.optString("_id"); JSONObject set = new JSONObject();
            switch (w) {
                case 0: cobPaid(x); return;
                case 1: Store.put(set, "st", "noestaba"); Store.put(set, "doneAt", System.currentTimeMillis()); Store.put(set, "by", "Oficina"); break;
                case 2: pickDate(isoAdd(cobDate, 1), nd -> {
                            JSONObject n = new JSONObject(); for (java.util.Iterator<String> it = x.keys(); it.hasNext(); ) { String k = it.next(); if (!k.startsWith("_") && !k.equals("st") && !k.equals("paid") && !k.equals("method") && !k.equals("doneAt") && !k.equals("by")) Store.put(n, k, x.opt(k)); }
                            Store.put(n, "date", nd); Store.put(n, "note", (x.optString("note") + " (pasado del " + dayLabel(cobDate) + ")").trim());
                            cobPush("cob-" + nd + "-" + x.optInt("tid", (int) (System.currentTimeMillis() % 100000)), n);
                            JSONObject o = new JSONObject(); Store.put(o, "st", "otrodia"); Store.put(o, "doneAt", System.currentTimeMillis()); cobPush(id, o); refresh(); toast("Pasado al " + dayLabel(nd)); });
                        return;
                case 3: Store.put(set, "st", ""); Store.put(set, "paid", 0); Store.put(set, "method", ""); break;
                case 4: launch(Store.waIntent(this, x.optString("phone"), "Hola " + x.optString("name").trim().split("\\s+")[0] + " 👋 ")); return;
                case 5: launch(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + x.optString("phone").replaceAll("[^0-9+]", "")))); return;
                case 6: launch(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(x.optString("property") + ", BC")))); return;
                case 7: {
                    String[] slot = {x.optString("time")};
                    EditText nt = input("Nota", TXT_MULTI); nt.setText(x.optString("note"));
                    LinearLayout box = vbox(); box.setPadding(dp(16), dp(8), dp(16), 0); box.addView(slotPicker(cobDate, x.optString("time"), slot)); box.addView(nt);
                    new AlertDialog.Builder(this).setView(box).setPositiveButton("Guardar", (d2, w2) -> { JSONObject s2 = new JSONObject(); Store.put(s2, "time", slot[0]); Store.put(s2, "note", nt.getText().toString().trim()); cobPush(id, s2); refresh(); }).setNegativeButton("Cancelar", null).show();
                    return;
                }
                case 8: Store.put(set, "deleted", true); break;
            }
            cobPush(id, set); refresh();
        }).show();
    }

    // ============================ 📣 Mensaje a un grupo de inquilinos ============================
    String bcGroup = "Amigo", bcChan = "wa", bcText = null, bcSubject = "", bcTextEn = null, bcSubjectEn = "", bcLang = "es";
    /** {botón, texto en español, asunto en español, texto en inglés, asunto en inglés} */
    static final String[][] BC_TPL = {
            {"🧾 Factura enviada", "Hola {nombre} 👋 Te escribimos de Amigo Renta. Te informamos que ya enviamos tu factura de {mes} a tu correo. Si no la ves, revisa la carpeta de correo no deseado (spam). Cualquier duda, escríbenos. ¡Gracias!", "Tu factura de {mes} – Amigo Renta",
                    "Hi {nombre} 👋 This is Amigo Renta. We have sent your {month} invoice to your email. If you don't see it, please check your spam folder. Any questions, just message us. Thank you!", "Your {month} invoice – Amigo Renta"},
            {"🚗 Horario de cobro", "Hola {nombre} 👋 Te escribimos de Amigo Renta. Te avisamos que pasaremos a recoger la renta el día ____ entre las ____ y las ____. Por favor ten tu pago listo. Si pagas por e-Transfer, no hace falta. ¡Gracias!", "Horario de cobro de la renta – Amigo Renta",
                    "Hi {nombre} 👋 This is Amigo Renta. We will come by to collect the rent on ____ between ____ and ____. Please have your payment ready. If you pay by e-Transfer, no need. Thank you!", "Rent collection schedule – Amigo Renta"},
            {"📅 Recordatorio de pago", "Hola {nombre} 👋 Te recordamos que la renta de {mes} vence pronto. Puedes pagar por e-Transfer o en efectivo cuando pasemos. ¡Gracias! – Amigo Renta", "Recordatorio: renta de {mes} – Amigo Renta",
                    "Hi {nombre} 👋 Friendly reminder that your {month} rent is due soon. You can pay by e-Transfer or in cash when we come by. Thank you! – Amigo Renta", "Reminder: {month} rent – Amigo Renta"},
            {"✍️ Mensaje propio", "Hola {nombre} 👋 ", "Aviso de Amigo Renta", "Hi {nombre} 👋 ", "Notice from Amigo Renta"}};

    /** El mensaje final según el idioma elegido: español, inglés o los dos (primero español). */
    String bcCompose(boolean subject) {
        String es = subject ? bcSubject : bcText, en = subject ? bcSubjectEn : bcTextEn;
        if (en == null) en = "";
        if (bcLang.equals("en")) return en;
        if (bcLang.equals("both")) return subject ? es + " / " + en : es.trim() + "\n\n— English —\n" + en.trim();
        return es;
    }

    /** De quién es el inquilino: la compañía de la tabla (Amigo/Callao) o, si no, la de su casa. */
    String tenantOwner(JSONObject t) {
        String o = ownerOfCompany(t.optString("company"));
        if (o.isEmpty()) o = houseOwner(ownerMap(), t.optString("property"));
        return o.equals("Amigo") || o.equals("Callao") ? o : "";
    }

    List<JSONObject> bcList(String g) {
        List<JSONObject> r = new ArrayList<>();
        for (JSONObject t : tenants) {
            if (t.optBoolean("inactive") || t.optString("name").trim().isEmpty()) continue;
            String o = tenantOwner(t);
            if (g.equals("Todos") || (g.equals("Sin marcar") ? o.isEmpty() : o.equals(g))) r.add(t);
        }
        Collections.sort(r, (x, y) -> (x.optString("property") + x.optString("name")).compareToIgnoreCase(y.optString("property") + y.optString("name")));
        return r;
    }

    static boolean hasPhone(JSONObject t) { return t.optString("phone").replaceAll("[^0-9]", "").length() >= 8; }
    static boolean hasEmail(JSONObject t) { return t.optString("email").contains("@"); }

    String bcFill(String text, JSONObject t) {
        String first = t == null ? "" : t.optString("name").trim().split("\\s+")[0];
        String r = text.replace("{mes}", Store.monthName(Store.today().substring(0, 7)).replaceAll("\\s+\\d{4}$", ""))
                .replace("{month}", java.time.LocalDate.now().getMonth().getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH));
        r = t == null ? r.replace(" {nombre}", "").replace("{nombre}", "") : r.replace("{nombre}", first);
        if (t != null) r = r.replace("{casa}", t.optString("property")).replace("{cuarto}", t.optString("unit"));
        return r;
    }

    void bcScreen() {
        setHeader("Mensaje a inquilinos", "Amigo, Callao o todos", null, true);
        if (bcText == null) { bcText = BC_TPL[0][1]; bcSubject = BC_TPL[0][2]; bcTextEn = BC_TPL[0][3]; bcSubjectEn = BC_TPL[0][4]; }
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.addView(tv("1. ¿A quiénes?", 15, TXT, true));
        LinearLayout gr = hbox();
        java.util.List<String> groups = new ArrayList<>(java.util.Arrays.asList("Amigo", "Callao", "Todos"));
        if (!bcList("Sin marcar").isEmpty()) groups.add("Sin marcar");
        for (String g : groups) gr.addView(chip((g.equals("Amigo") ? "🏠 " : g.equals("Callao") ? "🏢 " : g.equals("Todos") ? "👥 " : "❔ ") + g + " · " + bcList(g).size(), g.equals(bcGroup), v -> { bcGroup = g; refresh(); }));
        c.addView(hscroll(gr));
        if (bcGroup.equals("Sin marcar")) c.addView(tv("Son inquilinos cuya casa no está marcada como Amigo o Callao (Más → Casas: Amigo o Callao).", 12, MUT, false));
        p.addView(c);

        LinearLayout c2 = card();
        c2.addView(tv("2. ¿Por dónde?", 15, TXT, true));
        List<JSONObject> L = bcList(bcGroup);
        int nPh = 0, nEm = 0; for (JSONObject t : L) { if (hasPhone(t)) nPh++; if (hasEmail(t)) nEm++; }
        LinearLayout ch = hbox();
        ch.addView(chip("💬 WhatsApp · " + nPh, bcChan.equals("wa"), v -> { bcChan = "wa"; refresh(); }));
        ch.addView(chip("✉️ Correo · " + nEm, bcChan.equals("mail"), v -> { bcChan = "mail"; refresh(); }));
        c2.addView(hscroll(ch));
        c2.addView(tv(bcChan.equals("wa")
                ? "WhatsApp no deja mandar a muchos de un solo golpe desde un teléfono. La app te abre cada chat ya escrito y con su nombre: tocas ➤ Enviar y vuelves por el siguiente."
                : "Se abre tu correo con un solo mensaje para todos, en copia oculta (nadie ve los correos de los demás). Solo tocas Enviar.", 12, MUT, false));
        int miss = bcChan.equals("wa") ? L.size() - nPh : L.size() - nEm;
        if (miss > 0) c2.addView(tv("⚠️ " + miss + " no tienen " + (bcChan.equals("wa") ? "WhatsApp" : "correo") + " anotado; se saltan.", 12, YEL, true));
        p.addView(c2);

        LinearLayout c3 = card();
        c3.addView(tv("3. El mensaje", 15, TXT, true));
        LinearLayout tp = hbox();
        for (String[] x : BC_TPL) tp.addView(chip(x[0], false, v -> { bcText = x[1]; bcSubject = x[2]; bcTextEn = x[3]; bcSubjectEn = x[4]; refresh(); }));
        c3.addView(hscroll(tp));
        c3.addView(tv("Idioma", 13, MUT, true));
        LinearLayout lg = hbox();
        String[][] LG = {{"es", "🇪🇸 Español"}, {"en", "🇬🇧 English"}, {"both", "🇪🇸🇬🇧 Los dos"}};
        for (String[] x : LG) lg.addView(chip(x[1], bcLang.equals(x[0]), v -> { bcLang = x[0]; refresh(); }));
        c3.addView(hscroll(lg));
        boolean showEs = !bcLang.equals("en"), showEn = !bcLang.equals("es");
        if (showEs) {
            if (bcLang.equals("both")) c3.addView(tv("🇪🇸 En español", 14, TXT, true));
            if (bcChan.equals("mail")) {
                EditText sj = input("Asunto del correo", TXT_CAP);
                sj.setText(bcSubject);
                sj.addTextChangedListener(new TextWatcher() { public void beforeTextChanged(CharSequence a, int b, int d, int e) { } public void onTextChanged(CharSequence a, int b, int d, int e) { } public void afterTextChanged(Editable e) { bcSubject = e.toString(); } });
                c3.addView(sj);
            }
            EditText tx = input("Escribe el mensaje", TXT_MULTI);
            tx.setMinLines(5);
            tx.setText(bcText);
            tx.addTextChangedListener(new TextWatcher() { public void beforeTextChanged(CharSequence a, int b, int d, int e) { } public void onTextChanged(CharSequence a, int b, int d, int e) { } public void afterTextChanged(Editable e) { bcText = e.toString(); } });
            c3.addView(tx);
        }
        if (showEn) {
            if (bcLang.equals("both")) c3.addView(tv("🇬🇧 In English", 14, TXT, true));
            if (bcChan.equals("mail")) {
                EditText sj2 = input("Email subject", TXT_CAP);
                sj2.setText(bcSubjectEn);
                sj2.addTextChangedListener(new TextWatcher() { public void beforeTextChanged(CharSequence a, int b, int d, int e) { } public void onTextChanged(CharSequence a, int b, int d, int e) { } public void afterTextChanged(Editable e) { bcSubjectEn = e.toString(); } });
                c3.addView(sj2);
            }
            EditText tx2 = input("Write the message", TXT_MULTI);
            tx2.setMinLines(5);
            tx2.setText(bcTextEn);
            tx2.addTextChangedListener(new TextWatcher() { public void beforeTextChanged(CharSequence a, int b, int d, int e) { } public void onTextChanged(CharSequence a, int b, int d, int e) { } public void afterTextChanged(Editable e) { bcTextEn = e.toString(); } });
            c3.addView(tx2);
        }
        if (bcLang.equals("both")) c3.addView(tv("Se manda un solo mensaje: primero en español y debajo en inglés.", 12, MUT, false));
        c3.addView(tv(bcChan.equals("wa") ? "{nombre} se cambia por el nombre de cada uno. También puedes usar {mes} ({month} en inglés), {casa} y {cuarto}." : "En el correo, {nombre} se quita (es un solo correo para todos). {mes} sí se cambia.", 12, MUT, false));
        p.addView(c3);

        p.addView(button(bcChan.equals("wa") ? "💬 Empezar a enviar por WhatsApp (" + nPh + ")" : "✉️ Abrir el correo para " + nEm, bcChan.equals("wa") ? GRN : PRI2, v -> {
            if (bcCompose(false).trim().length() < 5 || (bcLang.equals("both") && (bcText.trim().length() < 5 || bcTextEn == null || bcTextEn.trim().length() < 5))) { toast("Escribe el mensaje" + (bcLang.equals("both") ? " en los dos idiomas" : "")); return; }
            if (bcChan.equals("mail")) bcMail(); else bcStart();
        }));
        show(scroll(p), false, null, null);
    }

    void bcMail() {
        List<String> to = new ArrayList<>();
        for (JSONObject t : bcList(bcGroup)) if (hasEmail(t)) { String e = t.optString("email").trim(); if (!to.contains(e)) to.add(e); }
        if (to.isEmpty()) { toast("Nadie de este grupo tiene correo anotado"); return; }
        Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
        String mine = Store.get(this, "etEmail", "");
        if (mine.contains("@")) i.putExtra(Intent.EXTRA_EMAIL, new String[]{mine});
        i.putExtra(Intent.EXTRA_BCC, to.toArray(new String[0]));
        i.putExtra(Intent.EXTRA_SUBJECT, bcFill(bcCompose(true), null));
        i.putExtra(Intent.EXTRA_TEXT, bcFill(bcCompose(false), null));
        launch(Intent.createChooser(i, "Enviar con…"));
    }

    /** Envío por WhatsApp uno por uno: se guarda el avance por si se cierra la app. */
    void bcStart() {
        JSONArray q = new JSONArray();
        for (JSONObject t : bcList(bcGroup)) if (hasPhone(t)) q.put(t.optInt("id"));
        if (q.length() == 0) { toast("Nadie de este grupo tiene WhatsApp anotado"); return; }
        JSONObject st = new JSONObject();
        Store.put(st, "group", bcGroup); Store.put(st, "text", bcCompose(false)); Store.put(st, "q", q); Store.put(st, "sent", new JSONArray()); Store.put(st, "at", System.currentTimeMillis());
        Store.putS(this, "bcast", st.toString());
        open(this::bcQueue);
    }

    JSONObject bcState() { try { return new JSONObject(Store.get(this, "bcast", "{}")); } catch (Exception e) { return new JSONObject(); } }

    JSONObject tenantById(int id) { for (JSONObject t : tenants) if (t.optInt("id") == id) return t; return null; }

    void bcQueue() {
        JSONObject st = bcState();
        JSONArray q = st.optJSONArray("q"), sent = st.optJSONArray("sent");
        if (q == null) { goBack(); return; }
        java.util.Set<Integer> done = new java.util.HashSet<>();
        for (int i = 0; sent != null && i < sent.length(); i++) done.add(sent.optInt(i));
        setHeader("Enviando por WhatsApp", done.size() + " de " + q.length() + " · " + st.optString("group"), null, true);
        LinearLayout p = vbox();
        JSONObject next = null;
        for (int i = 0; i < q.length(); i++) { JSONObject t = tenantById(q.optInt(i)); if (t != null && !done.contains(t.optInt("id"))) { next = t; break; } }
        LinearLayout top = card();
        android.widget.ProgressBar pb = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(q.length()); pb.setProgress(done.size());
        top.addView(pb);
        if (next != null) {
            top.addView(tv("Siguiente: " + next.optString("name"), 17, TXT, true));
            top.addView(tv(next.optString("property") + (next.optString("unit").isEmpty() ? "" : " · " + next.optString("unit")), 13, MUT, false));
            final JSONObject nx = next;
            top.addView(button("💬 Abrir WhatsApp de " + next.optString("name").trim().split("\\s+")[0] + "  (" + (done.size() + 1) + " de " + q.length() + ")", GRN, v -> bcSend(nx)));
            top.addView(tv("Se abre el chat con el mensaje ya escrito: toca ➤ Enviar y vuelve aquí; queda marcado y sigue el próximo.", 12, MUT, false));
        } else {
            top.addView(tv("✅ ¡Listo! Se envió a los " + q.length() + ".", 17, GRN, true));
            top.addView(button("Terminar", PRI2, v -> { Store.putS(this, "bcast", "{}"); goBack(); }));
        }
        p.addView(top);
        p.addView(sectionTitle("Lista", null, null));
        LinearLayout c = card();
        for (int i = 0; i < q.length(); i++) {
            JSONObject t = tenantById(q.optInt(i)); if (t == null) continue;
            boolean ok = done.contains(t.optInt("id"));
            LinearLayout r = hbox();
            r.setPadding(0, dp(8), 0, dp(8));
            LinearLayout tt = vbox();
            tt.addView(tv((ok ? "✅ " : "⬜ ") + t.optString("name"), 15, ok ? MUT : TXT, true));
            tt.addView(tv(t.optString("property") + (t.optString("unit").isEmpty() ? "" : " · " + t.optString("unit")), 12, MUT, false));
            r.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView b = tv(ok ? "Otra vez" : "Enviar", 14, ok ? MUT : GRN, true);
            b.setPadding(dp(10), dp(6), dp(4), dp(6));
            b.setOnClickListener(v -> bcSend(t));
            r.addView(b);
            c.addView(r);
        }
        p.addView(c);
        show(scroll(p), false, null, null);
    }

    void bcSend(JSONObject t) {
        JSONObject st = bcState();
        JSONArray sent = st.optJSONArray("sent"); if (sent == null) sent = new JSONArray();
        boolean in = false; for (int i = 0; i < sent.length(); i++) if (sent.optInt(i) == t.optInt("id")) in = true;
        if (!in) sent.put(t.optInt("id"));
        Store.put(st, "sent", sent);
        Store.putS(this, "bcast", st.toString());
        launch(Store.waIntent(this, t.optString("phone"), bcFill(st.optString("text"), t)));
    }

    View menuRow(String ic, String title, String sub, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(6), 0, dp(6));
        TextView i = tv(ic, 22, TXT, false);
        i.setPadding(0, 0, dp(14), 0);
        r.addView(i);
        LinearLayout t = vbox();
        t.addView(tv(title, 16, TXT, true));
        t.addView(tv(sub, 13, MUT, false));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (l != null) { r.addView(tv("›", 22, MUT, false)); r.setOnClickListener(l); }
        return r;
    }

    void settings() {
        setHeader("Ajustes", null, null, true);
        formMode();
        LinearLayout p = vbox();
        LinearLayout c = card();
        EditText day = input("1", InputType.TYPE_CLASS_NUMBER);
        day.setText(String.valueOf(Store.getI(this, "dueDay", 1)));
        EditText grace = input("0", InputType.TYPE_CLASS_NUMBER);
        grace.setText(String.valueOf(Store.getI(this, "grace", 0)));
        EditText et = input("Ej. pagos@amigorenta.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        et.setText(Store.get(this, "etEmail", ""));
        EditText cur = input("$", InputType.TYPE_CLASS_TEXT);
        cur.setText(Store.get(this, "cur", "$"));
        final String[] waOpts = {"WhatsApp Business", "WhatsApp normal"};
        TextView wa = picker(waOpts, Store.get(this, "waApp", "business").equals("business") ? waOpts[0] : waOpts[1]);
        Switch rep = new Switch(this);
        rep.setText("📁 Guardar solo el reporte del mes anterior en Descargas");
        rep.setTextColor(TXT);
        rep.setTextSize(14);
        rep.setPadding(0, dp(14), 0, dp(4));
        rep.setChecked(Store.getB(this, "autoReport", true));
        c.addView(twoCols(labeled("Día de pago (por defecto)", day), labeled("Días de gracia", grace)));
        c.addView(tv("Después de los días de gracia el pago aparece como 🔴 atrasado.", 12, MUT, false));
        c.addView(label("📩", "Correo para recibir e-Transfers", false));
        c.addView(et);
        c.addView(tv("Aparece en el recordatorio de WhatsApp a los inquilinos.", 12, MUT, false));
        c.addView(twoCols(labeled("Moneda", cur), labeled("Abrir WhatsApp con", wa)));
        c.addView(rep);
        p.addView(c);
        LinearLayout mg = card();
        mg.addView(tv("👔  Manager", 16, TXT, true));
        EditText mName = input("Manager", TXT_CAP);
        mName.setText(mgrName());
        EditText mPhone = input("+1 604 767 8650", InputType.TYPE_CLASS_PHONE);
        mPhone.setText(Store.get(this, "mgrPhone", "+16047678650"));
        Switch ask = new Switch(this);
        ask.setText("Al guardar un pago, preguntar si envío el recibo al inquilino o el aviso al manager");
        ask.setTextColor(TXT);
        ask.setTextSize(14);
        ask.setPadding(0, dp(12), 0, dp(4));
        ask.setChecked(Store.getB(this, "askMgr", true));
        mg.addView(twoCols(labeled("Nombre", mName), labeled("WhatsApp", mPhone)));
        mg.addView(ask);
        p.addView(mg);
        LinearLayout q = card();
        q.addView(tv("🟢  QuickBooks Online", 16, TXT, true));
        EditText qItem = input("Renta", InputType.TYPE_CLASS_TEXT);
        qItem.setText(Store.get(this, "qbItem", "Renta"));
        EditText qTax = input("Exempt", InputType.TYPE_CLASS_TEXT);
        qTax.setText(Store.get(this, "qbTax", "Exempt"));
        final String[] dfs = {"MM/dd/yyyy", "dd/MM/yyyy"};
        TextView qDf = picker(dfs, Store.get(this, "qbDate", "MM/dd/yyyy"));
        q.addView(twoCols(labeled("Producto o servicio (renta)", qItem), labeled("Código de impuesto", qTax)));
        EditText qUtil = input("Utilidades", InputType.TYPE_CLASS_TEXT);
        qUtil.setText(Store.get(this, "qbUtilItem", "Utilidades"));
        EditText qUtilTax = input("Exempt", InputType.TYPE_CLASS_TEXT);
        qUtilTax.setText(Store.get(this, "qbUtilTax", Store.get(this, "qbTax", "Exempt")));
        q.addView(twoCols(labeled("Producto o servicio (utilidades)", qUtil), labeled("Impuesto utilidades", qUtilTax)));
        q.addView(tv("Deben llamarse igual que en tu QuickBooks. La renta residencial normalmente está exenta (Exempt).", 12, MUT, false));
        q.addView(labeled("Formato de fecha", qDf));
        p.addView(q);
        LinearLayout qm = card();
        qm.addView(tv("🔗  Conexión con QuickBooks", 16, TXT, true));
        Switch qMode = new Switch(this);
        qMode.setText("Modo QuickBooks (las facturas se hacen en QuickBooks)");
        qMode.setTextColor(TXT);
        qMode.setTextSize(14);
        qMode.setPadding(0, dp(10), 0, dp(4));
        qMode.setChecked(Store.qbo(this));
        qm.addView(qMode);
        qm.addView(tv("Apagado, la app funciona igual que siempre. Encendido: no se crea el archivo de facturas y cada pago nuevo queda listo para enviarse a QuickBooks cuando la conexión esté lista. Los pagos anteriores quedan como histórico y nunca se envían.", 12, MUT, false));
        EditText cut = input("20", InputType.TYPE_CLASS_NUMBER);
        cut.setText(String.valueOf(Store.getI(this, "qbCutoff", 20)));
        qm.addView(labeled("Las facturas hechas desde el día… son del mes siguiente", cut));
        qm.addView(tv("Ej. con 20: una factura del 21 de octubre es la renta de noviembre.", 12, MUT, false));
        qm.addView(kv("Cuenta de depósito", "Undeposited Funds"));
        EditText srv = input("Se llena cuando el servidor esté listo", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        srv.setText(Store.get(this, "serverUrl", ""));
        EditText dkey = input("Clave del dispositivo", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        dkey.setText(Store.get(this, "deviceKey", ""));
        qm.addView(labeled("Dirección del servidor", srv));
        qm.addView(labeled("Clave del dispositivo", dkey));
        qm.addView(tv(Store.get(this, "serverUrl", "").isEmpty() ? "⏳ Todavía sin conexión: falta que Amigo Renta active la cuenta de Intuit Developer y el servidor." : "Servidor configurado.", 12, YEL, true));
        p.addView(qm);
        p.addView(button("Guardar", PRI2, v -> {
            Store.putS(this, "qbItem", qItem.getText().toString().trim().isEmpty() ? "Renta" : qItem.getText().toString().trim());
            Store.putS(this, "qbTax", qTax.getText().toString().trim());
            Store.putS(this, "qbUtilItem", qUtil.getText().toString().trim().isEmpty() ? "Utilidades" : qUtil.getText().toString().trim());
            Store.putS(this, "qbUtilTax", qUtilTax.getText().toString().trim());
            Store.putS(this, "qbDate", (String) qDf.getTag());
            int d = (int) num(day.getText().toString());
            Store.putI(this, "dueDay", d < 1 || d > 31 ? 1 : d);
            Store.putI(this, "grace", Math.max(0, (int) num(grace.getText().toString())));
            Store.putS(this, "etEmail", et.getText().toString().trim());
            Store.putS(this, "cur", cur.getText().toString().trim().isEmpty() ? "$" : cur.getText().toString().trim());
            Store.putS(this, "waApp", ((String) wa.getTag()).equals(waOpts[0]) ? "business" : "normal");
            Store.putB(this, "autoReport", rep.isChecked());
            Store.putS(this, "mgrName", mName.getText().toString().trim().isEmpty() ? "Manager" : mName.getText().toString().trim());
            Store.putS(this, "mgrPhone", mPhone.getText().toString().trim());
            Store.putB(this, "askMgr", ask.isChecked());
            int cd = (int) num(cut.getText().toString());
            Store.putI(this, "qbCutoff", cd < 1 || cd > 31 ? 20 : cd);
            Store.putS(this, "serverUrl", srv.getText().toString().trim());
            Store.putS(this, "deviceKey", dkey.getText().toString().trim());
            if (qMode.isChecked() && !Store.qbo(this)) Store.markHistory(this);
            Store.putB(this, "qboMode", qMode.isChecked());
            reload();
            toast("Ajustes guardados ✅");
            goBack();
        }));
        show(scroll(p), false, null, null);
    }

    // ============================ tabla maestra (Excel / CSV) ============================
    List<List<String>> impRows;
    List<String> impHeaders;
    int[] impMap;
    String impMonth = "", impSheet = "";
    boolean impShowAll = false;
    // Los 11 primeros son los de siempre; los demás son las columnas de la tabla mensual de clientes (10.2026_clientes.xlsx)
    static final String[] IMP_FIELDS = {"name", "property", "unit", "rent", "phone", "email", "dueDay", "deposit", "aliases", "notes", "utilities",
            "code", "company", "landlord", "level", "unitType", "address", "postal", "unitObs", "qboName", "invoice",
            "contract", "payNote", "occupants", "moveIn", "moveOut", "utilIncl", "payMethod", "depDateTx", "qbRef", "petDeposit",
            "parking", "cleaning", "svcTelus", "svcFortis", "svcHydro", "uInternet", "uGas", "uElec", "utilNotes"};
    static final String[] IMP_LABELS = {"Nombre del inquilino (CLIENTS) *", "Propiedad / ubicación (LOCATION) *", "Número de cuarto (UNIT)", "Renta mensual (TENANT RENT) *", "Teléfono / WhatsApp",
            "Correo", "Día de pago", "Depósito (Security Deposit)", "Nombre en el e-Transfer", "Notas (obs.2)", "Utilidades mensuales",
            "Código de la unidad (Project)", "Compañía: Amigo o Callao (Company)", "Dueño de la casa (OWNER)", "Piso / clase (Class)", "Tipo de unidad (Unit Type)",
            "Dirección completa (DIRECCIÓN)", "Código postal", "Observación de la unidad (obs.)", "Nombre en QuickBooks", "Invoice",
            "Estado de contrato", "Morosidad", "Número de ocupantes", "Fecha de ingreso", "Fecha de salida", "Utilidades incluidas (Utilities Payments)",
            "Forma de pago (Method payment)", "Fecha del depósito", "QuickBooks (referencia)", "Depósito de mascota",
            "Parking", "Limpieza (Cleaning)", "Telus / Rogers", "Fortis", "BC Hydro", "Internet", "Gas", "Electricidad", "Nota de utilidades (OBS)"};
    static final String[][] IMP_SYN = {
            {"nombre", "inquilino", "tenant", "nombre completo", "nombre y apellido", "nombre inquilino", "cliente", "clientes", "client", "clients", "name", "full name", "residente"},
            {"propiedad", "location", "ubicacion", "direccion", "casa", "property", "address", "edificio", "building", "propiedades"},
            {"cuarto", "habitacion", "room", "unidad", "unit", "numero de cuarto", "hab", "no cuarto", "n cuarto", "room number", "cuarto numero", "suite"},
            {"renta", "tenant rent", "alquiler", "rent", "precio", "monto", "mensualidad", "renta mensual", "monthly rent", "pago mensual", "cuota"},
            {"telefono", "tel", "celular", "phone", "whatsapp", "movil", "cel", "numero de telefono", "phone number"},
            {"correo", "email", "e mail", "mail", "correo electronico"},
            {"dia de pago", "dia", "due day", "fecha de pago", "pago dia", "dia pago", "payment day"},
            {"deposito", "deposit", "garantia", "security deposit", "security deposit amount", "damage deposit"},
            {"e transfer", "etransfer", "nombre e transfer", "nombre en e transfer", "interac", "pagador"},
            {"notas", "notes", "comentarios", "observaciones", "nota", "comments", "obs 2"},
            {"utilidades", "utilities", "servicios", "util", "utility", "luz y agua", "luz agua internet", "servicios publicos", "utilidad"},
            {"project", "proyecto", "codigo", "code", "codigo unidad", "id unidad"},
            {"company", "compania", "empresa"},
            {"owner", "dueno", "propietario", "landlord", "dueno de la casa"},
            {"class", "piso", "nivel", "floor", "level", "clase"},
            {"unit type", "tipo de unidad", "tipo unidad", "tipo"},
            {"direccion", "direccion completa", "full address"},
            {"postal code", "codigo postal", "postal"},
            {"obs", "obs 1", "observacion unidad"},
            {"nombre quickbooks", "nombre en quickbooks", "quickbooks name", "cliente quickbooks"},
            {"invoice", "factura", "no factura"},
            {"estado de contrato", "contrato", "contract"},
            {"morosidad", "comportamiento de pago"},
            {"n of occupants", "occupants", "ocupantes", "numero de ocupantes", "personas"},
            {"fecha de ingreso", "move in", "fecha entrada", "ingreso", "entrada"},
            {"fecha de salida", "move out", "salida"},
            {"utilities payments", "utilidades incluidas", "utilities included"},
            {"method payment", "payment method", "metodo de pago", "forma de pago", "metodo pago"},
            {"security deposit date", "fecha deposito", "fecha del deposito"},
            {"quickbooks"},
            {"pet deposit", "pet deposit amount", "deposito mascota", "deposito de mascota"},
            {"parking", "estacionamiento"},
            {"cleaning", "limpieza"},
            {"telus roger", "telus rogers", "telus", "rogers"},
            {"fortis"},
            {"bc hydro", "hydro"},
            {"internet"},
            {"gas"},
            {"electricity", "electricidad", "luz"},
            {"obs", "obs utilidades", "nota utilidades"}};
    static final int CORE_FIELDS = 11;

    void pickImportFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "text/csv", "text/comma-separated-values", "text/plain", "application/vnd.ms-excel", "application/octet-stream"});
        try { startActivityForResult(i, REQ_IMPORT); } catch (Exception e) { toast("No se pudo abrir el selector de archivos"); }
    }

    void readImportFile(Uri u) {
        byte[] bytes;
        try (InputStream in = getContentResolver().openInputStream(u)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            bytes = bo.toByteArray();
        } catch (Throwable e) { importError("No se pudo leer el archivo desde el teléfono.", e); return; }
        if (bytes.length > 2 && bytes[0] == 'P' && bytes[1] == 'K') {
            try {
                final java.util.LinkedHashMap<String, List<List<String>>> sheets = readXlsx(bytes);
                if (sheets.isEmpty()) { toast("El Excel no tiene hojas con datos"); return; }
                if (sheets.size() == 1) { impSheet = sheets.keySet().iterator().next(); prepareImport(sheets.values().iterator().next()); return; }
                final String[] names = sheets.keySet().toArray(new String[0]);
                new AlertDialog.Builder(this).setTitle("¿Qué hoja tiene los inquilinos?")
                        .setItems(names, (dlg, w) -> { impSheet = names[w]; prepareImport(sheets.get(names[w])); }).show();
            } catch (Throwable e) { importError("No pude leer ese Excel.", e); }
        } else if (bytes.length > 4 && (bytes[0] & 0xFF) == 0xD0 && (bytes[1] & 0xFF) == 0xCF) {
            importError("Este archivo es un Excel antiguo (.xls) o está protegido (con contraseña o etiqueta de confidencialidad de la empresa).\n\n"
                    + "Solución: ábrelo en Excel → Archivo → Guardar como → «CSV UTF-8 (delimitado por comas)» o un .xlsx nuevo sin protección, y cárgalo otra vez.", null);
        } else {
            String text = new String(bytes, StandardCharsets.UTF_8);
            if (text.startsWith("\uFEFF")) text = text.substring(1);
            impSheet = "";
            prepareImport(parseCsv(text));
        }
    }

    static List<List<String>> parseCsv(String text) {
        String first = text.split("\\r?\\n", 2)[0];
        int tabs = first.split("\t", -1).length, semis = first.split(";", -1).length, commas = first.split(",", -1).length;
        char sep = tabs >= semis && tabs >= commas ? '\t' : semis > commas ? ';' : ',';
        List<List<String>> rows = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (q) {
                if (ch == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') { cell.append('"'); i++; }
                    else q = false;
                } else cell.append(ch);
            } else if (ch == '"') q = true;
            else if (ch == sep) { row.add(cell.toString().trim()); cell.setLength(0); }
            else if (ch == '\n' || ch == '\r') {
                if (ch == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') i++;
                row.add(cell.toString().trim()); cell.setLength(0);
                rows.add(row); row = new ArrayList<>();
            } else cell.append(ch);
        }
        if (cell.length() > 0 || !row.isEmpty()) { row.add(cell.toString().trim()); rows.add(row); }
        return rows;
    }

    static java.util.LinkedHashMap<String, List<List<String>>> readXlsx(byte[] bytes) throws Exception {
        java.util.HashMap<String, byte[]> files = new java.util.HashMap<>();
        try (java.util.zip.ZipInputStream z = new java.util.zip.ZipInputStream(new java.io.ByteArrayInputStream(bytes))) {
            java.util.zip.ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String n = e.getName();
                if (n.startsWith("/")) n = n.substring(1);
                if (!(n.startsWith("xl/") && n.endsWith(".xml") || n.endsWith(".rels"))) continue;
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int k;
                while ((k = z.read(buf)) > 0) bo.write(buf, 0, k);
                files.put(n, bo.toByteArray());
            }
        }
        // textos compartidos
        List<String> shared = new ArrayList<>();
        byte[] ss = files.get("xl/sharedStrings.xml");
        if (ss != null) {
            org.xmlpull.v1.XmlPullParser x = android.util.Xml.newPullParser();
            x.setFeature(org.xmlpull.v1.XmlPullParser.FEATURE_PROCESS_NAMESPACES, true);
            x.setInput(new java.io.ByteArrayInputStream(ss), "UTF-8");
            StringBuilder cur = null;
            boolean inT = false, inRph = false;
            for (int ev = x.getEventType(); ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT; ev = x.next()) {
                String tag = x.getName();
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG) {
                    if ("si".equals(tag)) cur = new StringBuilder();
                    else if ("t".equals(tag)) inT = true;
                    else if ("rPh".equals(tag)) inRph = true;
                } else if (ev == org.xmlpull.v1.XmlPullParser.END_TAG) {
                    if ("si".equals(tag)) { shared.add(cur == null ? "" : cur.toString()); cur = null; }
                    else if ("t".equals(tag)) inT = false;
                    else if ("rPh".equals(tag)) inRph = false;
                } else if (ev == org.xmlpull.v1.XmlPullParser.TEXT && inT && !inRph && cur != null) cur.append(x.getText());
            }
        }
        // hojas: nombre -> archivo
        java.util.HashMap<String, String> relTarget = new java.util.HashMap<>();
        byte[] rels = files.get("xl/_rels/workbook.xml.rels");
        if (rels != null) {
            org.xmlpull.v1.XmlPullParser x = android.util.Xml.newPullParser();
            x.setFeature(org.xmlpull.v1.XmlPullParser.FEATURE_PROCESS_NAMESPACES, true);
            x.setInput(new java.io.ByteArrayInputStream(rels), "UTF-8");
            for (int ev = x.getEventType(); ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT; ev = x.next())
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG && "Relationship".equals(x.getName())) {
                    String t = x.getAttributeValue(null, "Target");
                    if (t == null) continue;
                    if (t.startsWith("/")) t = t.substring(1); else t = "xl/" + t;
                    relTarget.put(x.getAttributeValue(null, "Id"), t);
                }
        }
        java.util.LinkedHashMap<String, String> sheetFiles = new java.util.LinkedHashMap<>();
        byte[] wb = files.get("xl/workbook.xml");
        if (wb != null) {
            org.xmlpull.v1.XmlPullParser x = android.util.Xml.newPullParser();
            x.setFeature(org.xmlpull.v1.XmlPullParser.FEATURE_PROCESS_NAMESPACES, true);
            x.setInput(new java.io.ByteArrayInputStream(wb), "UTF-8");
            for (int ev = x.getEventType(); ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT; ev = x.next())
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG && "sheet".equals(x.getName())) {
                    String rid = null;
                    for (int a = 0; a < x.getAttributeCount(); a++) if (x.getAttributeName(a).endsWith("id")) rid = x.getAttributeValue(a);
                    String target = rid == null ? null : relTarget.get(rid);
                    if (target != null && files.containsKey(target)) sheetFiles.put(x.getAttributeValue(null, "name"), target);
                }
        }
        if (sheetFiles.isEmpty()) for (String k : files.keySet()) if (k.startsWith("xl/worksheets/sheet")) sheetFiles.put(k.replace("xl/worksheets/", "").replace(".xml", ""), k);
        java.util.LinkedHashMap<String, List<List<String>>> out = new java.util.LinkedHashMap<>();
        for (java.util.Map.Entry<String, String> sf : sheetFiles.entrySet()) {
            List<List<String>> rows = new ArrayList<>();
            org.xmlpull.v1.XmlPullParser x = android.util.Xml.newPullParser();
            x.setFeature(org.xmlpull.v1.XmlPullParser.FEATURE_PROCESS_NAMESPACES, true);
            x.setInput(new java.io.ByteArrayInputStream(files.get(sf.getValue())), "UTF-8");
            List<String> row = null;
            String type = null, ref = null;
            StringBuilder val = null;
            boolean inV = false, inT = false;
            for (int ev = x.getEventType(); ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT; ev = x.next()) {
                String tag = x.getName();
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG) {
                    if ("row".equals(tag)) row = new ArrayList<>();
                    else if ("c".equals(tag)) { type = x.getAttributeValue(null, "t"); ref = x.getAttributeValue(null, "r"); val = new StringBuilder(); }
                    else if ("v".equals(tag)) inV = true;
                    else if ("t".equals(tag)) inT = true;
                } else if (ev == org.xmlpull.v1.XmlPullParser.TEXT) {
                    if ((inV || inT) && val != null) val.append(x.getText());
                } else if (ev == org.xmlpull.v1.XmlPullParser.END_TAG) {
                    if ("v".equals(tag)) inV = false;
                    else if ("t".equals(tag)) inT = false;
                    else if ("c".equals(tag) && row != null) {
                        String v = val == null ? "" : val.toString();
                        if ("s".equals(type)) { try { v = shared.get(Integer.parseInt(v.trim())); } catch (Exception e) { v = ""; } }
                        else if ("b".equals(type)) v = "1".equals(v) ? "Sí" : "No";
                        else if (type == null || "n".equals(type)) {
                            try { double d = Double.parseDouble(v); v = Math.abs(d - Math.round(d)) < 1e-9 ? String.valueOf(Math.round(d)) : String.valueOf(d); } catch (Exception ignored) { }
                        }
                        int col = row.size();
                        if (ref != null) {
                            int c = 0;
                            for (char ch : ref.toCharArray()) { if (ch >= 'A' && ch <= 'Z') c = c * 26 + (ch - 'A' + 1); else break; }
                            if (c > 0) col = c - 1;
                        }
                        while (row.size() < col) row.add("");
                        if (col < row.size()) row.set(col, v.trim()); else row.add(v.trim());
                        val = null;
                    } else if ("row".equals(tag) && row != null) { rows.add(row); row = null; }
                }
            }
            boolean any = false;
            for (List<String> r : rows) for (String v : r) if (!v.isEmpty()) { any = true; break; }
            if (any) out.put(sf.getKey(), rows);
        }
        return out;
    }

    static String normH(String s) { return Store.norm(s).toLowerCase(Locale.US).replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim(); }

    /** Campos posibles para un título de columna: primero los que coinciden exacto, luego los parecidos (el más largo primero). */
    List<Integer> detectFields(String header) {
        List<Integer> r = new ArrayList<>();
        String h = normH(header);
        if (h.isEmpty()) return r;
        for (int f = 0; f < IMP_SYN.length; f++) for (String syn : IMP_SYN[f]) if (h.equals(syn) && !r.contains(f)) r.add(f);
        if (!r.isEmpty()) return r;
        List<int[]> part = new ArrayList<>(); // {campo, largo}
        for (int f = 0; f < IMP_SYN.length; f++) {
            int best = 0;
            for (String syn : IMP_SYN[f]) if (syn.length() >= 4 && (h.startsWith(syn) || h.contains(" " + syn))) best = Math.max(best, syn.length());
            if (best > 0) part.add(new int[]{f, best});
        }
        Collections.sort(part, (a, b) -> b[1] - a[1]);
        for (int[] x : part) r.add(x[0]);
        return r;
    }

    int detectField(String header) { List<Integer> l = detectFields(header); return l.isEmpty() ? -1 : l.get(0); }

    void importError(String msg, Throwable e) {
        String det = e == null ? "" : "\n\nDetalle técnico: " + e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
        new AlertDialog.Builder(this).setTitle("⚠️ No se pudo cargar")
                .setMessage(msg + (e != null ? "\n\nPrueba guardarlo como «CSV UTF-8» desde Excel y cárgalo de nuevo." : "") + det)
                .setPositiveButton("OK", null).show();
    }

    void prepareImport(List<List<String>> rows) {
        try { prepareImportSafe(rows); } catch (Throwable e) { importError("Ocurrió un error al leer las filas.", e); }
    }

    /** "10.2026", "10-2026", "2026-10", "Octubre 2026"… → "2026-10" */
    static String monthFromName(String s) {
        if (s == null) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?<!\\d)(\\d{1,2})[.\\-_/ ](\\d{4})(?!\\d)").matcher(s);
        if (m.find()) { int mo = Integer.parseInt(m.group(1)); if (mo >= 1 && mo <= 12) return m.group(2) + "-" + (mo < 10 ? "0" : "") + mo; }
        m = java.util.regex.Pattern.compile("(?<!\\d)(\\d{4})[.\\-_/ ](\\d{1,2})(?!\\d)").matcher(s);
        if (m.find()) { int mo = Integer.parseInt(m.group(2)); if (mo >= 1 && mo <= 12) return m.group(1) + "-" + (mo < 10 ? "0" : "") + mo; }
        String n = Store.norm(s);
        String[] ms = {"ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"};
        java.util.regex.Matcher y = java.util.regex.Pattern.compile("(20\\d{2})").matcher(n);
        if (y.find()) for (int i = 0; i < 12; i++) if (n.contains(ms[i]) || (i == 8 && n.contains("SETIEMBRE"))) return y.group(1) + "-" + (i < 9 ? "0" : "") + (i + 1);
        return "";
    }

    void prepareImportSafe(List<List<String>> rows) {
        if (rows == null || rows.isEmpty()) { importError("No encontré datos en el archivo.", null); return; }
        int hdr = 0, best = -1;
        for (int r = 0; r < Math.min(rows.size(), 15); r++) {
            int hits = 0;
            for (String c : rows.get(r)) if (!detectFields(c).isEmpty()) hits++;
            if (hits > best) { best = hits; hdr = r; }
        }
        impHeaders = new ArrayList<>(rows.get(hdr));
        impRows = new ArrayList<>(rows.subList(hdr + 1, rows.size()));
        impMap = new int[IMP_FIELDS.length];
        java.util.Arrays.fill(impMap, -1);
        for (int c = 0; c < impHeaders.size(); c++)
            for (int f : detectFields(impHeaders.get(c))) if (impMap[f] < 0) { impMap[f] = c; break; }
        if (impHeaders.isEmpty()) { importError("No encontré la fila de títulos de las columnas.", null); return; }
        String m = monthFromName(impSheet);
        if (m.isEmpty()) for (int r = 0; r < hdr; r++) for (String c : rows.get(r)) { // fecha arriba de los títulos (ej. 1/10/2026)
            String iso = parseDateIso(c);
            if (!iso.isEmpty()) m = iso.substring(0, 7);
        }
        impMonth = m.isEmpty() ? Store.thisMonth() : m;
        impShowAll = false;
        open(() -> {
            try { importMapScreen(); }
            catch (Throwable e) { importError("Ocurrió un error al mostrar las columnas.", e); }
        });
    }

    String cellOf(List<String> row, int col) { return col < 0 || col >= row.size() ? "" : row.get(col).trim(); }

    String cellF(List<String> row, String field) {
        for (int f = 0; f < IMP_FIELDS.length; f++) if (IMP_FIELDS[f].equals(field)) {
            String v = cellOf(row, impMap[f]).replaceAll("\\s+", " ").trim();
            return v.startsWith("#") && v.endsWith("!") || v.equals("#N/A") ? "" : v; // #ERROR!, #REF!… de fórmulas
        }
        return "";
    }

    /** Fecha de la tabla → "yyyy-MM-dd". Acepta 1/10/2026, 01-10-2026, 2026-10-01 y fechas reales de Excel. */
    static String parseDateIso(String s) {
        if (s == null) return "";
        s = s.trim();
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\d{4})-(\\d{1,2})-(\\d{1,2})").matcher(s);
            if (m.find()) return iso(Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)), Integer.parseInt(m.group(3)));
            m = java.util.regex.Pattern.compile("^(\\d{1,2})[/.\\-](\\d{1,2})[/.\\-](\\d{2,4})$").matcher(s);
            if (m.find()) {
                int y = Integer.parseInt(m.group(3));
                if (y < 100) y += 2000;
                return iso(y, Integer.parseInt(m.group(2)), Integer.parseInt(m.group(1))); // día/mes/año
            }
            if (s.matches("^\\d{5}(\\.\\d+)?$")) { // número de serie de Excel
                double d = Double.parseDouble(s);
                if (d > 30000 && d < 80000) {
                    Calendar c = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));
                    c.clear();
                    c.set(1899, Calendar.DECEMBER, 30);
                    c.add(Calendar.DAY_OF_MONTH, (int) d);
                    return iso(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
                }
            }
        } catch (Exception e) { }
        return "";
    }

    static String iso(int y, int m, int d) {
        if (y < 2000 || y > 2100 || m < 1 || m > 12 || d < 1 || d > 31) return "";
        return String.format(Locale.US, "%04d-%02d-%02d", y, m, d);
    }

    static boolean vacantName(String n) {
        String x = Store.norm(n);
        return x.isEmpty() || x.equals("DISPONIBLE") || x.equals("DISPONIBLES") || x.equals("VACANTE") || x.equals("VACIO") || x.equals("VACIA")
                || x.equals("AVAILABLE") || x.equals("LIBRE") || x.equals("X") || x.equals("NA");
    }

    static String ownerOfCompany(String c) {
        String n = Store.norm(c);
        if (n.contains("CALLAO")) return "Callao";
        if (n.contains("AMIGO")) return "Amigo";
        return "";
    }

    static String cleanUnit(String v) {
        return v.replaceAll("(?i)^(cuarto|habitaci[oó]n|room|hab\\.?)\\s*#?\\s*", "").replaceAll("\\.0+$", "").trim();
    }

    /** Busca al inquilino de la fila: por código de unidad + nombre; si no, por nombre y propiedad (cargas anteriores sin código). */
    JSONObject findExisting(String code, String name, String prop) {
        String nn = Store.norm(name), np = Store.norm(prop), nc = Store.norm(code);
        JSONObject alt = null;
        if (!nc.isEmpty()) for (JSONObject t : tenants)
            if (Store.norm(t.optString("code")).equals(nc) && Store.norm(t.optString("name")).equals(nn)) {
                if (!t.optBoolean("inactive")) return t;
                if (alt == null) alt = t;
            }
        if (alt != null) return alt;
        for (JSONObject t : tenants) {
            if (!Store.norm(t.optString("name")).equals(nn)) continue;
            if (!nc.isEmpty() && !t.optString("code").isEmpty() && !Store.norm(t.optString("code")).equals(nc)) continue;
            if (np.isEmpty() || Store.norm(t.optString("property")).equals(np) || t.optString("property").isEmpty()) return t;
        }
        return null;
    }

    /** Resultado de revisar la tabla (sin cambiar nada) o de cargarla (apply = true). */
    static class ImpPlan { int add, upd, skip, vacant, ended, owners; List<String> endedNames = new ArrayList<>(), skipped = new ArrayList<>(); }

    JSONArray vacRows = new JSONArray();

    ImpPlan runImport(boolean apply) {
        ImpPlan pl = new ImpPlan();
        vacRows = new JSONArray();
        String m = impMonth.isEmpty() ? Store.thisMonth() : impMonth;
        java.util.HashMap<String, java.util.HashSet<String>> codeNames = new java.util.HashMap<>(); // código → nombres que siguen en esa unidad
        java.util.HashSet<String> touched = new java.util.HashSet<>();
        JSONObject owners = ownerMap();
        boolean ownersChanged = false;
        for (List<String> r : impRows) {
            if (String.join("", r).trim().isEmpty()) continue;
            String name = cellF(r, "name"), prop = cellF(r, "property"), code = cellF(r, "code").replaceAll("\\.0+$", "");
            String comp = ownerOfCompany(cellF(r, "company"));
            if (!prop.isEmpty() && !comp.isEmpty() && !comp.equals(houseOwner(owners, prop))) {
                Store.put(owners, Store.norm(prop), comp);
                ownersChanged = true;
                pl.owners++;
            }
            if (!code.isEmpty() && !codeNames.containsKey(Store.norm(code))) codeNames.put(Store.norm(code), new java.util.HashSet<>());
            if (vacantName(name)) {
                if (!code.isEmpty() || !prop.isEmpty()) {
                    pl.vacant++;
                    if (apply) { JSONArray raw = new JSONArray(); for (String c : r) raw.put(c); JSONObject v = new JSONObject(); Store.put(v, "row", raw); Store.put(v, "ord", impRows.indexOf(r)); Store.put(v, "code", code); Store.put(v, "prop", prop); vacRows.put(v); }
                }
                continue;
            }
            if (!code.isEmpty()) codeNames.get(Store.norm(code)).add(Store.norm(name));
            JSONObject t = findExisting(code, name, prop);
            double rent = num(cellF(r, "rent"));
            if (t == null && rent <= 0) { pl.skip++; if (pl.skipped.size() < 8) pl.skipped.add(name + " (sin renta)"); continue; }
            boolean isNew = t == null;
            if (isNew) pl.add++; else pl.upd++;
            if (!apply) { if (t != null) touched.add(String.valueOf(t.optInt("id"))); continue; }
            if (isNew) {
                t = new JSONObject();
                Store.put(t, "id", Store.nextId(this));
                Store.put(t, "dueDay", Store.getI(this, "dueDay", 1));
                tenants.add(t);
            }
            touched.add(String.valueOf(t.optInt("id")));
            fillTenant(t, r, isNew, m);
            // la fila tal cual venía (para volver a exportar en el mismo formato) y su posición
            JSONArray raw = new JSONArray(); for (String c : r) raw.put(c);
            Store.put(t, "xrow", raw);
            Store.put(t, "xord", impRows.indexOf(r));
        }
        // quien ya no aparece en su unidad (otra persona o DISPONIBLE) se marca como que se mudó
        for (JSONObject t : tenants) {
            String nc = Store.norm(t.optString("code"));
            if (nc.isEmpty() || !codeNames.containsKey(nc) || touched.contains(String.valueOf(t.optInt("id")))) continue;
            if (t.optBoolean("inactive") || !Store.activeIn(t, m)) continue;
            if (codeNames.get(nc).contains(Store.norm(t.optString("name")))) continue;
            pl.ended++;
            if (pl.endedNames.size() < 8) pl.endedNames.add(t.optString("name") + " · " + where(t));
            if (apply) {
                String last = Store.addMonth(m, -1);
                Store.put(t, "until", t.optString("since").compareTo(last) > 0 ? t.optString("since") : last);
                Store.put(t, "inactive", true);
            }
        }
        if (apply) {
            Store.putS(this, "impVacant", vacRows.toString());
            if (ownersChanged) { Store.putS(this, "propOwner", owners.toString()); Sync.soon(this, 4000); }
            saveAll();
        }
        return pl;
    }

    void fillTenant(JSONObject t, List<String> r, boolean isNew, String m) {
        Store.put(t, "name", cellF(r, "name"));
        String moveIn = parseDateIso(cellF(r, "moveIn")), moveOut = parseDateIso(cellF(r, "moveOut"));
        if (isNew) Store.put(t, "since", !moveIn.isEmpty() && moveIn.substring(0, 7).compareTo(m) > 0 ? moveIn.substring(0, 7) : m);
        if (t.optBoolean("inactive")) { Store.put(t, "inactive", false); t.remove("until"); } // volvió a aparecer en la tabla
        if (!moveIn.isEmpty()) Store.put(t, "moveIn", moveIn);
        if (!moveOut.isEmpty()) {
            Store.put(t, "moveOut", moveOut);
            String um = moveOut.substring(0, 7);
            if (um.compareTo(t.optString("since")) >= 0) Store.put(t, "until", um);
        }
        String[] text = {"property", "phone", "email", "aliases", "notes", "code", "landlord", "level", "unitType", "address", "postal", "unitObs",
                "invoice", "contract", "payNote", "payMethod", "qbRef", "svcTelus", "svcFortis", "svcHydro", "utilNotes"};
        for (String k : text) {
            String v = cellF(r, k);
            if (k.equals("code") || k.equals("invoice") || k.equals("qbRef")) v = v.replaceAll("\\.0+$", "");
            if (!v.isEmpty()) Store.put(t, k, v);
        }
        String comp = cellF(r, "company");
        if (!comp.isEmpty()) Store.put(t, "company", comp);
        String unit = cleanUnit(cellF(r, "unit"));
        if (!unit.isEmpty()) Store.put(t, "unit", unit);
        String qn = cellF(r, "qboName");
        if (!qn.isEmpty() && !Store.norm(qn).startsWith("REVISAR")) Store.put(t, "qboName", qn);
        double rent = num(cellF(r, "rent"));
        if (rent > 0) Store.put(t, "rent", rent);
        double dep = num(cellF(r, "deposit"));
        if (dep > 0) { Store.put(t, "deposit", dep); if (isNew) Store.put(t, "depPaid", true); }
        String dd = cellF(r, "depDateTx");
        if (!dd.isEmpty()) {
            String di = parseDateIso(dd);
            if (!di.isEmpty()) { Store.put(t, "depDate", Store.millisAt(di, 12)); Store.put(t, "depPaid", true); }
            else Store.put(t, "depNote", dd);
        }
        String occ = cellF(r, "occupants");
        if (num(occ) > 0) Store.put(t, "occupants", (int) num(occ));
        for (String k : new String[]{"petDeposit", "parking", "cleaning"}) { double v = num(cellF(r, k)); if (v > 0) Store.put(t, k, v); }
        int d = (int) num(cellF(r, "dueDay").replaceAll("[^0-9.]", ""));
        if (d >= 1 && d <= 31) Store.put(t, "dueDay", d);
        String inc = Store.norm(cellF(r, "utilIncl"));
        double uSum = num(cellF(r, "uInternet")) + num(cellF(r, "uGas")) + num(cellF(r, "uElec"));
        double uCol = num(cellF(r, "utilities"));
        if (!inc.isEmpty()) {
            boolean included = !(inc.contains("NOT") || inc.startsWith("NO ") || inc.equals("NO"));
            Store.put(t, "utilIncl", included);
            if (included) Store.put(t, "utilities", 0);
        }
        if (!t.optBoolean("utilIncl", false) || inc.isEmpty()) {
            if (uCol > 0) Store.put(t, "utilities", Math.round(uCol * 100) / 100.0);
            else if (uSum > 0) Store.put(t, "utilities", Math.round(uSum * 100) / 100.0);
        }
    }

    void importMapScreen() {
        setHeader("Cargar tabla del mes", impRows.size() + " filas · " + Store.monthName(impMonth), null, true);
        LinearLayout p = vbox();
        LinearLayout mc = card();
        TextView mf = field("📅  Tabla de " + Store.monthName(impMonth) + "  ▾");
        mf.setOnClickListener(v -> {
            String[] ms = new String[15];
            for (int i = 0; i < 15; i++) ms[i] = Store.monthName(Store.addMonth(Store.thisMonth(), 2 - i));
            new AlertDialog.Builder(this).setTitle("¿De qué mes es la tabla?").setItems(ms, (dl, w) -> { impMonth = Store.addMonth(Store.thisMonth(), 2 - w); refresh(); }).show();
        });
        mc.addView(labeled("Mes de la tabla", mf));
        mc.addView(tv("Los inquilinos nuevos empiezan a cobrarse desde este mes. Quien ya no aparece en su unidad (otro cliente o «DISPONIBLE») se marca como que se mudó al terminar el mes anterior.", 12, MUT, false));
        p.addView(mc);

        LinearLayout c = card();
        c.addView(tv("Revisa qué columna de tu Excel corresponde a cada dato. Lo que la app reconoció ya está elegido.", 14, TXT, false));
        String[] opts = new String[impHeaders.size() + 1];
        opts[0] = "— No importar —";
        for (int i = 0; i < impHeaders.size(); i++)
            opts[i + 1] = colName(i) + ": " + (impHeaders.get(i).isEmpty() ? "(sin título)" : impHeaders.get(i));
        int hidden = 0;
        for (int f = 0; f < IMP_FIELDS.length; f++) {
            if (!impShowAll && f >= CORE_FIELDS && impMap[f] < 0) { hidden++; continue; }
            if (!impShowAll && (f == 6 || f == 8 || f == 10) && impMap[f] < 0) { hidden++; continue; }
            final int ff = f;
            TextView sel = field((impMap[f] < 0 ? opts[0] : opts[impMap[f] + 1]) + "  ▾");
            if (impMap[f] < 0 && (f == 0 || f == 1 || f == 3)) sel.setTextColor(RED);
            sel.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(IMP_LABELS[ff]).setItems(opts, (dlg, w) -> {
                impMap[ff] = w - 1;
                refresh();
            }).show());
            c.addView(labeled(IMP_LABELS[f], sel));
        }
        if (hidden > 0 || impShowAll) {
            TextView more = tv(impShowAll ? "Ocultar los campos sin columna" : "＋ Ver " + hidden + " campos más (sin columna en tu Excel)", 14, PRI2, true);
            more.setPadding(0, dp(14), 0, 0);
            more.setOnClickListener(v -> { impShowAll = !impShowAll; refresh(); });
            c.addView(more);
        }
        p.addView(c);

        ImpPlan pl = runImport(false);
        p.addView(sectionTitle("Vista previa", null, null));
        LinearLayout pv = card();
        int shown = 0;
        for (List<String> r : impRows) {
            String n = cellF(r, "name");
            if (vacantName(n)) continue;
            if (pv.getChildCount() > 0) pv.addView(divider());
            pv.addView(tv(n, 15, TXT, true));
            String own = ownerOfCompany(cellF(r, "company"));
            pv.addView(tv(join(" · ", cellF(r, "code").replaceAll("\\.0+$", ""), cellF(r, "property"), cellF(r, "level"),
                    cellF(r, "unit").isEmpty() ? "" : (cellF(r, "unitType").isEmpty() ? "Cuarto" : cellF(r, "unitType")) + " " + cleanUnit(cellF(r, "unit")),
                    num(cellF(r, "rent")) > 0 ? money(num(cellF(r, "rent"))) : "sin renta", own), 13, MUT, false));
            if (++shown >= 5) break;
        }
        if (shown == 0) pv.addView(tv("Elige la columna del nombre para ver la vista previa.", 14, MUT, false));
        p.addView(pv);
        LinearLayout sc = card();
        sc.addView(kv("➕ Inquilinos nuevos", String.valueOf(pl.add), GRN));
        sc.addView(kv("✏️ Se actualizan", String.valueOf(pl.upd), PRI2));
        sc.addView(kv("🚪 Se mudaron (ya no están en su unidad)", String.valueOf(pl.ended), pl.ended > 0 ? ORG : MUT));
        sc.addView(kv("🟦 Unidades disponibles", String.valueOf(pl.vacant), MUT));
        if (pl.owners > 0) sc.addView(kv("🏢 Casas marcadas Amigo / Callao", String.valueOf(pl.owners), PRI2));
        if (pl.skip > 0) sc.addView(kv("⏭️ Filas que no se cargan", String.valueOf(pl.skip), RED));
        if (!pl.endedNames.isEmpty()) sc.addView(tv("Se mudaron: " + TextUtils.join(", ", pl.endedNames) + (pl.ended > pl.endedNames.size() ? "…" : ""), 12, MUT, false));
        if (!pl.skipped.isEmpty()) sc.addView(tv("No se cargan: " + TextUtils.join(", ", pl.skipped) + (pl.skip > pl.skipped.size() ? "…" : ""), 12, MUT, false));
        p.addView(sc);
        TextView note = tv("Cada mes puedes volver a cargar la tabla: el que ya existe (mismo código de unidad y nombre) se actualiza sin duplicarse, y sus pagos se conservan.", 12, MUT, false);
        note.setPadding(dp(18), dp(6), dp(18), 0);
        p.addView(note);
        p.addView(button("📗  Cargar tabla de " + Store.monthName(impMonth), GRN, v -> {
            if (impMap[0] < 0 || impMap[3] < 0) { toast("Elige al menos las columnas de nombre y renta"); return; }
            if (impMap[1] < 0) { toast("Elige la columna de la propiedad"); return; }
            try {
                saveLayout();
                ImpPlan done = runImport(true);
                reload();
                toast("✅ " + done.add + " nuevos · " + done.upd + " actualizados" + (done.ended > 0 ? " · " + done.ended + " se mudaron" : ""));
                month = impMonth;
                openTab(0);
            } catch (Throwable e) { importError("Ocurrió un error al guardar los inquilinos.", e); }
        }));
        show(scroll(p), false, null, null);
    }

    // ============================ exportar en el formato de la tabla del mes ============================
    static final String[][] DEF_LAYOUT = {{"Project", "code"}, {"Company", "company"}, {"OWNER", "landlord"}, {"LOCATION", "property"}, {"Class", "level"}, {"Unit Type", "unitType"},
            {"DIRECCIÓN", "address"}, {"Postal Code", "postal"}, {"UNIT", "unit"}, {"obs.", "unitObs"}, {"CLIENTS", "name"}, {"TENANT RENT", "rent"}, {"Utilities Payments", "utilIncl"},
            {"Utilidades", "utilities"}, {"Phone", "phone"}, {"Email", "email"}, {"N of occupants", "occupants"}, {"FECHA DE INGRESO", "moveIn"}, {"FECHA DE SALIDA", "moveOut"},
            {"Estado de contrato", "contract"}, {"Morosidad", "payNote"}, {"Method payment", "payMethod"}, {"Security Deposit", "deposit"}, {"Security Deposit Date", "depDateTx"},
            {"Pet Deposit", "petDeposit"}, {"Parking", "parking"}, {"Cleaning", "cleaning"}, {"Invoice", "invoice"}, {"Nombre QuickBooks", "qboName"}, {"QuickBooks", "qbRef"}, {"obs.2", "notes"}};

    /** Guarda los títulos de las columnas y qué dato va en cada una (de la última tabla cargada). */
    void saveLayout() {
        try {
            JSONObject o = new JSONObject();
            JSONArray h = new JSONArray(), f = new JSONArray();
            for (int c = 0; c < impHeaders.size(); c++) {
                h.put(impHeaders.get(c));
                String fld = "";
                for (int k = 0; k < IMP_FIELDS.length; k++) if (impMap[k] == c) { fld = IMP_FIELDS[k]; break; }
                f.put(fld);
            }
            o.put("headers", h); o.put("fields", f); o.put("sheet", impSheet); o.put("month", impMonth);
            Store.putS(this, "impLayout", o.toString());
        } catch (Exception e) { }
    }

    void tableExportDialog() {
        String m0 = Store.thisMonth(), m1 = Store.addMonth(m0, 1);
        String[] o = {"Mes actual · " + Store.monthName(m0), "Próximo mes · " + Store.monthName(m1)};
        boolean has = !Store.get(this, "impLayout", "").isEmpty();
        new AlertDialog.Builder(this).setTitle("¿Para qué mes?")
                .setItems(o, (d, w) -> {
                    String m = w == 0 ? m0 : m1;
                    try {
                        String fname = m.substring(5, 7) + "." + m.substring(0, 4) + "_clientes.xlsx";
                        Uri u = writeTableToDownloads(m, fname);
                        if (u == null) { toast("No se pudo guardar"); return; }
                        new AlertDialog.Builder(this).setTitle("Listo ✅")
                                .setMessage("Guardado en Descargas → Amigo Renta Reportes:\n" + fname + (has ? "" : "\n\n(Todavía no has cargado una tabla, así que usé las columnas de tu archivo de octubre.)"))
                                .setPositiveButton("Abrir", (d2, w2) -> { Intent i = new Intent(Intent.ACTION_VIEW); i.setDataAndType(u, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); launch(Intent.createChooser(i, "Abrir con")); })
                                .setNeutralButton("Compartir", (d2, w2) -> { Intent i = new Intent(Intent.ACTION_SEND); i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"); i.putExtra(Intent.EXTRA_STREAM, u); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); launch(Intent.createChooser(i, "Enviar " + fname)); })
                                .setNegativeButton("OK", null).show();
                    } catch (Throwable e) { toast("No se pudo crear el archivo: " + e.getMessage()); }
                }).show();
    }

    Uri writeTableToDownloads(String m, String fname) throws Exception {
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, fname);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Amigo Renta Reportes");
        Uri u;
        if (Build.VERSION.SDK_INT >= 29) u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
        else {
            java.io.File dir = new java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Amigo Renta Reportes");
            dir.mkdirs();
            java.io.File f = new java.io.File(dir, fname);
            try (OutputStream os = new java.io.FileOutputStream(f)) { writeTable(os, m); }
            android.os.StrictMode.setVmPolicy(new android.os.StrictMode.VmPolicy.Builder().build());
            return Uri.fromFile(f);
        }
        if (u == null) return null;
        try (OutputStream os = getContentResolver().openOutputStream(u)) { writeTable(os, m); }
        return u;
    }

    static String ddmmyyyy(String iso) { return iso != null && iso.length() >= 10 ? iso.substring(8, 10) + "/" + iso.substring(5, 7) + "/" + iso.substring(0, 4) : ""; }

    /** Valor de un inquilino para una columna de la tabla. raw = lo que traía la fila original en esa columna. */
    Object tableValue(JSONObject t, String f, String raw, JSONObject owners) {
        switch (f) {
            case "": return raw;
            case "rent": case "deposit": case "petDeposit": case "parking": case "cleaning": {
                double v = t.optDouble(f, 0); return v > 0 ? (Object) v : raw;
            }
            case "utilities": { double v = t.optDouble("utilities", 0); return v > 0 ? (Object) v : (t.optBoolean("utilIncl") ? (Object) 0 : raw); }
            case "occupants": { int v = t.optInt("occupants", 0); return v > 0 ? (Object) v : raw; }
            case "dueDay": return t.has("dueDay") ? (Object) t.optInt("dueDay") : raw;
            case "moveIn": case "moveOut": { String iso = t.optString(f); if (iso.isEmpty()) return raw; String r0 = parseDateIso(raw); return iso.equals(r0) ? raw : ddmmyyyy(iso); }
            case "utilIncl": if (!raw.isEmpty()) return raw; return t.has("utilIncl") ? (t.optBoolean("utilIncl") ? "INCLUDED" : "NOT INCLUDED") : "";
            case "depDateTx": if (!raw.isEmpty()) return raw; return t.optLong("depDate") > 0 ? ddmmyyyy(Store.dayOf(t.optLong("depDate"))) : t.optString("depNote");
            case "company": { String c = t.optString("company"); if (!c.isEmpty()) return c; String o = houseOwner(owners, t.optString("property")); return o.isEmpty() ? raw : o; }
            case "uInternet": case "uGas": case "uElec": case "svcTelus": case "svcFortis": case "svcHydro": case "utilNotes": case "qbRef":
                return !raw.isEmpty() ? raw : t.optString(f);
            default: { String v = t.optString(f); return v.isEmpty() ? raw : v; }
        }
    }

    void writeTable(OutputStream os, String m) throws Exception {
        JSONObject lay = null;
        try { lay = new JSONObject(Store.get(this, "impLayout", "")); } catch (Exception e) { }
        List<String> heads = new ArrayList<>(), fields = new ArrayList<>();
        if (lay != null && lay.optJSONArray("headers") != null) {
            JSONArray h = lay.optJSONArray("headers"), f = lay.optJSONArray("fields");
            for (int i = 0; i < h.length(); i++) { heads.add(h.optString(i)); fields.add(f == null ? "" : f.optString(i)); }
        } else for (String[] x : DEF_LAYOUT) { heads.add(x[0]); fields.add(x[1]); }
        JSONObject owners = ownerMap();
        // filas: inquilinos activos ese mes + unidades disponibles de la última tabla (si nadie las ocupa ahora)
        List<Object[]> rows = new ArrayList<>(); // {orden, celdas}
        java.util.HashMap<String, Double> lastOrdOfProp = new java.util.HashMap<>();
        java.util.HashSet<String> busy = new java.util.HashSet<>();
        List<JSONObject> act = activeTenants(m);
        for (JSONObject t : act) {
            if (t.has("xord")) { String pk = Store.norm(t.optString("property")); double o = t.optDouble("xord", 0); if (!lastOrdOfProp.containsKey(pk) || lastOrdOfProp.get(pk) < o) lastOrdOfProp.put(pk, o); }
            if (!t.optString("code").isEmpty()) busy.add(Store.norm(t.optString("code")));
        }
        int extra = 0;
        for (JSONObject t : act) {
            JSONArray raw = t.optJSONArray("xrow");
            double ord;
            if (t.has("xord")) ord = t.optDouble("xord", 0);
            else { Double lo = lastOrdOfProp.get(Store.norm(t.optString("property"))); ord = (lo == null ? 100000 : lo) + 0.001 * (++extra); }
            List<Object> cells = new ArrayList<>();
            for (int c = 0; c < heads.size(); c++) {
                String rv = raw != null && c < raw.length() ? raw.optString(c) : "";
                Object v = tableValue(t, fields.get(c), rv, owners);
                if (v instanceof String && ((String) v).matches("^-?\\d+(\\.\\d+)?$") && (fields.get(c).equals("rent") || fields.get(c).equals("deposit"))) v = Double.parseDouble((String) v);
                cells.add(v);
            }
            rows.add(new Object[]{ord, cells});
        }
        try {
            JSONArray vac = new JSONArray(Store.get(this, "impVacant", "[]"));
            for (int i = 0; i < vac.length(); i++) {
                JSONObject v = vac.optJSONObject(i); if (v == null) continue;
                String code = v.optString("code");
                if (!code.isEmpty() && busy.contains(Store.norm(code))) continue; // ya la ocupa alguien
                JSONArray raw = v.optJSONArray("row"); List<Object> cells = new ArrayList<>();
                for (int c = 0; c < heads.size(); c++) cells.add(raw != null && c < raw.length() ? raw.optString(c) : "");
                rows.add(new Object[]{v.optDouble("ord", 0), cells});
            }
        } catch (Exception e) { }
        Collections.sort(rows, (a, b) -> Double.compare((Double) a[0], (Double) b[0]));
        List<List<Object>> sheet = new ArrayList<>();
        sheet.add(new ArrayList<Object>(heads));
        for (Object[] r : rows) { @SuppressWarnings("unchecked") List<Object> cl = (List<Object>) r[1]; sheet.add(cl); }
        int[] w = new int[heads.size()];
        for (int c = 0; c < w.length; c++) { String f = fields.get(c); w[c] = f.equals("name") || f.equals("address") || f.equals("property") ? 28 : f.equals("notes") || f.equals("unitObs") ? 30 : 14; }
        List<String> names = new ArrayList<>(); names.add(m.substring(5, 7) + "." + m.substring(0, 4));
        List<List<List<Object>>> sheets = new ArrayList<>(); sheets.add(sheet);
        List<int[]> widths = new ArrayList<>(); widths.add(w);
        writeBook(os, names, sheets, widths);
    }

    void importDialog() {
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(4), dp(20), 0);
        box.addView(tv("Copia desde Excel estas columnas en este orden y pégalas aquí:\nNombre | Propiedad | Cuarto | Renta | Teléfono | Día de pago | Depósito | Utilidades\n(desde Teléfono son opcionales)", 13, MUT, false));
        EditText e = input("Pega aquí", TXT_MULTI);
        e.setMinLines(6);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        box.addView(e);
        new AlertDialog.Builder(this).setTitle("Importar inquilinos").setView(box)
                .setPositiveButton("Importar", (dlg, w) -> {
                    int n = 0, skip = 0;
                    for (String line : e.getText().toString().split("\\r?\\n")) {
                        if (line.trim().isEmpty()) continue;
                        String[] c = line.contains("\t") ? line.split("\t") : line.split("[;,]");
                        if (c.length < 4) { skip++; continue; }
                        double rn = num(c[3]);
                        if (c[0].trim().isEmpty() || rn <= 0) { skip++; continue; }
                        JSONObject o = new JSONObject();
                        Store.put(o, "id", Store.nextId(this));
                        Store.put(o, "name", c[0].trim());
                        Store.put(o, "property", c[1].trim());
                        Store.put(o, "unit", c[2].trim());
                        Store.put(o, "rent", rn);
                        Store.put(o, "phone", c.length > 4 ? c[4].trim() : "");
                        int d = c.length > 5 ? (int) num(c[5]) : 0;
                        Store.put(o, "dueDay", d >= 1 && d <= 31 ? d : Store.getI(this, "dueDay", 1));
                        Store.put(o, "since", Store.thisMonth());
                        double dpi = c.length > 6 ? num(c[6]) : 0;
                        if (dpi > 0) { Store.put(o, "deposit", dpi); Store.put(o, "depPaid", true); }
                        if (c.length > 7 && num(c[7]) > 0) Store.put(o, "utilities", num(c[7]));
                        tenants.add(o);
                        n++;
                    }
                    saveAll();
                    toast(n + " inquilinos importados" + (skip > 0 ? " · " + skip + " líneas no se pudieron leer" : ""));
                    openTab(1);
                }).setNegativeButton("Cancelar", null).show();
    }

    // ============================ QuickBooks Online ============================
    void qboDialog() {
        String[] ms = new String[13];
        for (int i = 0; i < 13; i++) ms[i] = Store.monthName(Store.addMonth(Store.thisMonth(), 1 - i));
        new AlertDialog.Builder(this).setTitle("Facturas de qué mes").setItems(ms, (dlg, w) -> exportQbo(Store.addMonth(Store.thisMonth(), 1 - w))).show();
    }

    static String csv(String v) {
        String x = v == null ? "" : v.replace("\r", " ").replace("\n", " ");
        return "\"" + x.replace("\"", "\"\"") + "\"";
    }

    static String csvLine(Object... cells) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < cells.length; i++) {
            if (i > 0) b.append(',');
            Object c = cells[i];
            if (c instanceof Number) b.append(String.format(Locale.US, "%.2f", ((Number) c).doubleValue()));
            else b.append(csv(c == null ? "" : c.toString()));
        }
        return b.append("\r\n").toString();
    }

    String qbDate(String iso) {
        try { return Store.f(Store.get(this, "qbDate", "MM/dd/yyyy")).format(Store.f("yyyy-MM-dd").parse(iso)); }
        catch (Exception e) { return iso; }
    }

    String qbName(JSONObject t) { return (t.optString("qboName").isEmpty() ? t.optString("name") : t.optString("qboName")).trim().replaceAll("\\s+", " ").replace(":", " "); }

    void exportQbo(String m) {
        List<JSONObject> act = activeTenants(m);
        if (act.isEmpty()) { toast("No hay inquilinos en " + Store.monthName(m)); return; }
        Collections.sort(act, (x, y) -> where(x).compareToIgnoreCase(where(y)));
        String item = Store.get(this, "qbItem", "Renta"), tax = Store.get(this, "qbTax", "Exempt");
        String tag = m.replace("-", "");

        StringBuilder cu = new StringBuilder(csvLine("Name", "Email", "Phone", "Mobile", "Street", "City", "Province", "Postal Code", "Country", "Notes"));
        for (JSONObject t : act)
            cu.append(csvLine(qbName(t), t.optString("email"), t.optString("phone"), t.optString("phone"),
                    where(t), "", "", "", "Canada", "Inquilino Amigo Renta"));

        StringBuilder inv = new StringBuilder(csvLine("Invoice No", "Customer", "Invoice Date", "Due Date", "Memo",
                "Item(Product/Service)", "Item Description", "Item Quantity", "Item Rate", "Item Amount", "Item Tax Code"));
        String first = m + "-01";
        String mName = Store.monthName(m).toLowerCase(Store.ES);
        for (JSONObject t : act) {
            JSONObject r = Store.rec(recs, t.optInt("id"), m, false);
            double rd = Store.rentDue(t, r), ud = Store.utilDue(t, r);
            if (rd + ud <= 0) continue;
            String no = "R" + tag.substring(2) + "-" + String.format(Locale.US, "%04d", t.optInt("id"));
            String desc = "Renta " + mName + " · " + where(t);
            if (rd > 0) inv.append(csvLine(no, qbName(t), qbDate(first), qbDate(Store.dueDate(t, m, this)), desc,
                    item, desc, 1, rd, rd, tax));
            if (ud > 0) inv.append(csvLine(no, qbName(t), qbDate(first), qbDate(Store.dueDate(t, m, this)), desc,
                    Store.get(this, "qbUtilItem", "Utilidades"), "Utilidades " + mName + " · " + where(t), 1, ud, ud,
                    Store.get(this, "qbUtilTax", tax)));
        }

        StringBuilder pay = new StringBuilder(csvLine("Payment Date", "Customer", "Amount", "Payment Method", "Reference No", "Invoice No", "Memo"));
        for (JSONObject t : act) {
            JSONObject r = Store.rec(recs, t.optInt("id"), m, false);
            JSONArray pa = r == null ? null : r.optJSONArray("payments");
            if (pa == null) continue;
            String no = "R" + tag.substring(2) + "-" + String.format(Locale.US, "%04d", t.optInt("id"));
            for (int i = 0; i < pa.length(); i++) {
                JSONObject x = pa.optJSONObject(i);
                if (x == null) continue;
                pay.append(csvLine(qbDate(Store.dayOf(x.optLong("date"))), qbName(t), x.optDouble("amount", 0), x.optString("method"),
                        x.optString("ref"), no, "Pago renta " + mName));
            }
        }

        if (Build.VERSION.SDK_INT < 29) { toast("Esta función necesita Android 10 o más nuevo"); return; }
        ArrayList<Uri> files = new ArrayList<>();
        final boolean qm = Store.qbo(this);
        String[][] parts = qm ? new String[][]{{"QBO_1_Clientes_" + m + ".csv", cu.toString()}, {"QBO_3_Pagos_" + m + ".csv", pay.toString()}}
                : new String[][]{{"QBO_1_Clientes_" + m + ".csv", cu.toString()}, {"QBO_2_Facturas_" + m + ".csv", inv.toString()},
                {"QBO_3_Pagos_" + m + ".csv", pay.toString()}};
        try {
            for (String[] f : parts) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, f[0]);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv");
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Amigo Renta QuickBooks");
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) throw new Exception("sin archivo");
                try (OutputStream os = getContentResolver().openOutputStream(u)) { os.write(f[1].getBytes(StandardCharsets.UTF_8)); }
                files.add(u);
            }
        } catch (Exception e) { toast("No se pudieron guardar los archivos"); return; }
        final ArrayList<Uri> fs = files;
        new AlertDialog.Builder(this)
                .setTitle("✅ Archivos listos")
                .setMessage(qm ? "Se guardaron 2 archivos en Descargas → Amigo Renta QuickBooks:\n\n"
                        + "1. Clientes (" + act.size() + " inquilinos)\n2. Pagos (referencia)\n\n"
                        + "🟢 Modo QuickBooks activo: no se crea el archivo de facturas, porque las facturas se hacen en QuickBooks."
                        : "Se guardaron 3 archivos en Descargas → Amigo Renta QuickBooks:\n\n"
                        + "1. Clientes (" + act.size() + " inquilinos)\n2. Facturas de " + Store.monthName(m) + "\n3. Pagos (referencia)\n\n"
                        + "Envíatelos por correo para importarlos desde la computadora.")
                .setPositiveButton("Enviar / compartir", (dlg, w) -> {
                    Intent i = new Intent(Intent.ACTION_SEND_MULTIPLE);
                    i.setType("text/csv");
                    i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, fs);
                    i.putExtra(Intent.EXTRA_SUBJECT, "QuickBooks · Rentas " + Store.monthName(m));
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    launch(Intent.createChooser(i, "Enviar archivos"));
                })
                .setNegativeButton("Listo", null).show();
    }

    // ============================ Excel ============================
    void exportDialog() {
        String[] ms = new String[12];
        for (int i = 0; i < 12; i++) ms[i] = Store.monthName(Store.addMonth(Store.thisMonth(), -i));
        new AlertDialog.Builder(this).setTitle("¿De qué mes?").setItems(ms, (dlg, w) -> {
            exportMonth = Store.addMonth(Store.thisMonth(), -w);
            new AlertDialog.Builder(this).setTitle("Reporte de " + ms[w])
                    .setItems(new String[]{"📁 Guardar en Descargas", "📂 Elegir dónde guardarlo (Drive, etc.)"}, (d2, w2) -> {
                        if (w2 == 0) {
                            if (saveToDownloads(exportMonth)) toast("Guardado en Descargas → Amigo Renta Reportes ✅");
                            else toast("No se pudo guardar. Usa «Elegir dónde guardarlo».");
                        } else {
                            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                            i.addCategory(Intent.CATEGORY_OPENABLE);
                            i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                            i.putExtra(Intent.EXTRA_TITLE, "Rentas_" + exportMonth + ".xlsx");
                            try { startActivityForResult(i, REQ_EXPORT); } catch (Exception e) { toast("No se pudo abrir el selector"); }
                        }
                    }).show();
        }).show();
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (Backup.onResult(this, rq, rs, data, this::afterRestore)) return;
        if (rq == REQ_IMPORT) {
            if (rs == RESULT_OK && data != null && data.getData() != null) {
                try { readImportFile(data.getData()); } catch (Throwable e) { importError("No pude abrir el archivo.", e); }
            }
            return;
        }
        if (rq == REQ_PHOTO) {
            if (rs == RESULT_OK && pendingCap != null) setImage(pendingCap.toString());
            else { movPhoto = false; if (pendingCap != null) try { getContentResolver().delete(pendingCap, null, null); } catch (Exception e) { } }
            pendingCap = null;
            return;
        }
        if (rq == REQ_PICK) {
            if (rs == RESULT_OK && data != null && data.getData() != null) {
                try { getContentResolver().takePersistableUriPermission(data.getData(), Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception e) { }
                setImage(data.getData().toString());
            } else movPhoto = false;
            return;
        }
        if (rq == REQ_EXPORT && rs == RESULT_OK && data != null && data.getData() != null) {
            try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                writeReport(os, exportMonth);
                toast("Excel guardado ✅");
            } catch (Exception e) { toast("No se pudo guardar el archivo"); }
        }
    }

    boolean saveToDownloads(String m) { return saveReportUri(m) != null; }

    Uri saveReportUri(String m) {
        if (Build.VERSION.SDK_INT < 29) return null;
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "Rentas_" + m + "_" + System.currentTimeMillis() % 100000 + ".xlsx");
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Amigo Renta Reportes");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u == null) return null;
            try (OutputStream os = getContentResolver().openOutputStream(u)) { writeReport(os, m); }
            return u;
        } catch (Exception e) { return null; }
    }

    void autoExport() {
        if (!Store.getB(this, "autoReport", true) || tenants.isEmpty()) return;
        String prev = Store.addMonth(Store.thisMonth(), -1);
        if (prev.equals(Store.get(this, "lastAuto", ""))) return;
        if (saveToDownloads(prev)) {
            Store.putS(this, "lastAuto", prev);
            toast("📊 Reporte de " + Store.monthName(prev) + " guardado en Descargas");
        }
    }

    void writeReport(OutputStream os, String m) throws Exception {
        List<String> names = new ArrayList<>();
        List<List<List<Object>>> sheets = new ArrayList<>();
        List<int[]> widths = new ArrayList<>();
        List<JSONObject> act = activeTenants(m);
        Collections.sort(act, (x, y) -> (x.optString("property") + x.optString("unit") + x.optString("name")).compareToIgnoreCase(y.optString("property") + y.optString("unit") + y.optString("name")));

        List<List<Object>> rows = new ArrayList<>();
        rows.add(row("Inquilino", "Propiedad", "Cuarto", "Renta", "Utilidades", "Total", "Pagado", "Falta", "Estado", "Fecha de pago", "Pagó el", "Forma de pago",
                "Días de atraso", "Fecha prometida", "Depósito", "Depósito recibido", "Depósito devuelto", "Teléfono", "Notas"));
        List<List<Object>> pend = new ArrayList<>();
        pend.add(row("Inquilino", "Propiedad", "Cuarto", "Falta", "Estado", "Días de atraso", "Fecha prometida", "Teléfono", "Notas"));
        List<List<Object>> pays = new ArrayList<>();
        pays.add(row("Fecha", "Inquilino", "Propiedad", "Cuarto", "Monto", "Forma de pago", "Recibió (efectivo)", "Origen", "Referencia", "Comprobante"));
        double exp = 0, got = 0, depHeld = 0, depPending = 0, expRent = 0, expUtil = 0;
        int[] cnt = new int[4];
        for (JSONObject t : act) {
            JSONObject r = Store.rec(recs, t.optInt("id"), m, false);
            double due = Store.due(t, r), pd = Store.paid(r), owed = Math.max(0, due - pd);
            int st = status(t, m);
            cnt[st]++;
            exp += due;
            expRent += Store.rentDue(t, r);
            expUtil += Store.utilDue(t, r);
            got += Math.min(pd, due);
            String dd = Store.dueDate(t, m, this);
            int late = lateDays(t, m);
            long lp = lastPaymentDate(r);
            String methods = "";
            JSONArray pa = r == null ? null : r.optJSONArray("payments");
            if (pa != null) for (int i = 0; i < pa.length(); i++) {
                JSONObject x = pa.optJSONObject(i);
                if (x == null) continue;
                if (!methods.contains(x.optString("method"))) methods = methods.isEmpty() ? x.optString("method") : methods + ", " + x.optString("method");
                pays.add(row(Store.excelDate(x.optLong("date")), t.optString("name"), t.optString("property"), t.optString("unit"),
                        r2(x.optDouble("amount", 0)), x.optString("method"), x.optString("recv"), x.optString("source").equals("auto") ? "Automático (correo)" : "Manual", x.optString("ref"),
                        x.optString("img").isEmpty() ? "No" : "Sí"));
            }
            String prom = r == null ? "" : r.optString("promise");
            String notes = r == null ? "" : r.optString("notes");
            rows.add(row(t.optString("name"), t.optString("property"), t.optString("unit"), r2(Store.rentDue(t, r)), r2(Store.utilDue(t, r)), r2(due), r2(pd), r2(owed), ST_NAMES[st], dd,
                    lp > 0 ? Store.dayOf(lp) : "", methods, late > 0 ? (Object) late : "", prom,
                    t.optDouble("deposit", 0) > 0 ? (Object) r2(t.optDouble("deposit", 0)) : "",
                    t.optDouble("deposit", 0) > 0 ? (t.optBoolean("depPaid") ? "Sí" + (t.optLong("depDate") > 0 ? " (" + Store.dayOf(t.optLong("depDate")) + ")" : "") : "No") : "",
                    t.optDouble("depReturned", 0) > 0 ? (Object) r2(t.optDouble("depReturned", 0)) : "",
                    t.optString("phone"), notes));
            if (t.optBoolean("depPaid")) depHeld += Math.max(0, t.optDouble("deposit", 0) - t.optDouble("depReturned", 0));
            else if (t.optDouble("deposit", 0) > 0) depPending += t.optDouble("deposit", 0);
            if (st != 0) pend.add(row(t.optString("name"), t.optString("property"), t.optString("unit"), r2(owed), ST_NAMES[st],
                    late > 0 ? (Object) late : "", prom, t.optString("phone"), notes));
        }
        List<List<Object>> res = new ArrayList<>();
        res.add(row("Reporte de rentas", Store.monthName(m)));
        res.add(row("Generado", Store.dateTime(System.currentTimeMillis())));
        res.add(row("Inquilinos", act.size()));
        res.add(row("Total renta", r2(expRent)));
        res.add(row("Total utilidades", r2(expUtil)));
        res.add(row("TOTAL GENERAL esperado", r2(exp)));
        res.add(row("Total cobrado", r2(got)));
        res.add(row("Falta por cobrar", r2(exp - got)));
        res.add(row("% cobrado", exp > 0 ? r2(got * 100 / exp) : 0));
        for (int i = 0; i < 4; i++) res.add(row(ST_NAMES[i], cnt[i]));
        res.add(row("Depósitos en garantía (recibidos)", r2(depHeld)));
        res.add(row("Depósitos pendientes de entregar", r2(depPending)));
        names.add("Resumen"); sheets.add(res); widths.add(new int[]{34, 26});
        names.add("Rentas"); sheets.add(rows); widths.add(new int[]{26, 26, 14, 11, 11, 11, 11, 11, 11, 13, 12, 16, 12, 14, 11, 18, 14, 16, 30});
        names.add("Faltan por pagar"); sheets.add(pend); widths.add(new int[]{26, 26, 14, 11, 11, 12, 14, 16, 30});
        names.add("Pagos"); sheets.add(pays); widths.add(new int[]{17, 26, 26, 14, 11, 14, 18, 24, 12});
        List<List<Object>> ets = new ArrayList<>();
        ets.add(row("Fecha", "Nombre en el e-Transfer", "Monto", "Estado", "Inquilino", "Aplicado al mes"));
        for (JSONObject d : detected) {
            if (!Store.month(d.optLong("at")).equals(m) && !m.equals(d.optString("month"))) continue;
            JSONObject t = d.has("tid") ? Store.tenant(tenants, d.optInt("tid")) : null;
            ets.add(row(Store.excelDate(d.optLong("at")), d.optString("name"), r2(d.optDouble("amount", 0)), d.optString("status"),
                    t == null ? "" : t.optString("name"), d.optString("month").isEmpty() ? "" : Store.monthName(d.optString("month"))));
        }
        names.add("e-Transfers"); sheets.add(ets); widths.add(new int[]{17, 28, 11, 12, 26, 16});
        writeBook(os, names, sheets, widths);
    }

    static double r2(double v) { return Math.round(v * 100) / 100.0; }

    void writeBook(OutputStream os, List<String> names, List<List<List<Object>>> sheets, List<int[]> widths) throws Exception {
        ZipOutputStream z = new ZipOutputStream(os);
        String ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        String rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        String pk = "http://schemas.openxmlformats.org/package/2006/relationships";
        String hd = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n";
        StringBuilder ct = new StringBuilder(hd + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        StringBuilder wb = new StringBuilder(hd + "<workbook xmlns=\"" + ns + "\" xmlns:r=\"" + rel + "\"><sheets>");
        StringBuilder wr = new StringBuilder(hd + "<Relationships xmlns=\"" + pk + "\">");
        for (int i = 0; i < names.size(); i++) {
            ct.append("<Override PartName=\"/xl/worksheets/sheet").append(i + 1)
                    .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            wb.append("<sheet name=\"").append(xml(names.get(i))).append("\" sheetId=\"").append(i + 1).append("\" r:id=\"rId").append(i + 1).append("\"/>");
            wr.append("<Relationship Id=\"rId").append(i + 1).append("\" Type=\"").append(rel).append("/worksheet\" Target=\"worksheets/sheet").append(i + 1).append(".xml\"/>");
        }
        ct.append("</Types>");
        wb.append("</sheets></workbook>");
        wr.append("<Relationship Id=\"rId").append(names.size() + 1).append("\" Type=\"").append(rel).append("/styles\" Target=\"styles.xml\"/></Relationships>");
        zput(z, "[Content_Types].xml", ct.toString());
        zput(z, "_rels/.rels", hd + "<Relationships xmlns=\"" + pk + "\">"
                + "<Relationship Id=\"rId1\" Type=\"" + rel + "/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        zput(z, "xl/workbook.xml", wb.toString());
        zput(z, "xl/_rels/workbook.xml.rels", wr.toString());
        zput(z, "xl/styles.xml", hd + "<styleSheet xmlns=\"" + ns + "\">"
                + "<numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"#,##0.00\"/></numFmts>"
                + "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font>"
                + "<font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font></fonts>"
                + "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>"
                + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF0D3B7A\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>"
                + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                + "<cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
                + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/>"
                + "<xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/></cellXfs>"
                + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
                + "</styleSheet>");
        for (int i = 0; i < names.size(); i++) zput(z, "xl/worksheets/sheet" + (i + 1) + ".xml", sheetXml(ns, sheets.get(i), widths.get(i)));
        z.finish();
    }

    static List<Object> row(Object... cells) {
        List<Object> r = new ArrayList<>();
        Collections.addAll(r, cells);
        return r;
    }

    static void zput(ZipOutputStream z, String name, String content) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    static String colName(int i) {
        StringBuilder s = new StringBuilder();
        i++;
        while (i > 0) { int m = (i - 1) % 26; s.insert(0, (char) ('A' + m)); i = (i - 1) / 26; }
        return s.toString();
    }

    static String xml(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch == '&') b.append("&amp;");
            else if (ch == '<') b.append("&lt;");
            else if (ch == '>') b.append("&gt;");
            else if (ch == '"') b.append("&quot;");
            else if (ch < 0x20 && ch != '\n' && ch != '\t' && ch != '\r') b.append(' ');
            else b.append(ch);
        }
        return b.toString();
    }

    static String sheetXml(String ns, List<List<Object>> rows, int[] widths) {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n");
        s.append("<worksheet xmlns=\"").append(ns).append("\">");
        s.append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
        s.append("<cols>");
        for (int i = 0; i < widths.length; i++)
            s.append("<col min=\"").append(i + 1).append("\" max=\"").append(i + 1).append("\" width=\"").append(widths[i]).append("\" customWidth=\"1\"/>");
        s.append("</cols><sheetData>");
        for (int r = 0; r < rows.size(); r++) {
            s.append("<row r=\"").append(r + 1).append("\">");
            List<Object> row = rows.get(r);
            for (int c = 0; c < row.size(); c++) {
                Object v = row.get(c);
                String ref = colName(c) + (r + 1);
                if (v instanceof Number && r > 0) {
                    double d = ((Number) v).doubleValue();
                    boolean whole = Math.abs(d - Math.round(d)) < 1e-9;
                    s.append("<c r=\"").append(ref).append("\"").append(whole ? "" : " s=\"2\"").append("><v>")
                            .append(whole ? String.valueOf(Math.round(d)) : String.valueOf(d)).append("</v></c>");
                } else {
                    String str = v == null ? "" : v.toString();
                    if (str.isEmpty() && r > 0) continue;
                    s.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"").append(r == 0 ? " s=\"1\"" : "")
                            .append("><is><t xml:space=\"preserve\">").append(xml(str)).append("</t></is></c>");
                }
            }
            s.append("</row>");
        }
        s.append("</sheetData></worksheet>");
        return s.toString();
    }

    // ============================ ingresos y egresos ============================
    static final String[] OWNERS = {"Amigo", "Callao"};
    /** Gastos generales: además de Amigo y Callao, «Otros» (ej. combustible de operadores o del Manager). */
    static final String[] GEN_OWNERS = {"Amigo", "Callao", "Otros"};
    static final String OTHERS = "Otros";
    static final String[] OTHER_FOR = {"Carro / vehículo", "Combustible", "Oficina", "Operadores", "Manager", "Herramientas y equipo", "Personal / empleados"};

    /** Opciones de «¿En qué fue?» para gastos de Otros: las de siempre + las que ya se usaron. */
    List<String> otherForOptions() {
        List<String> r = new ArrayList<>();
        Collections.addAll(r, OTHER_FOR);
        for (JSONObject x : movs()) {
            String v = x.optString("otherFor").trim();
            boolean has = false;
            for (String y : r) if (Store.norm(y).equals(Store.norm(v))) has = true;
            if (!v.isEmpty() && !has) r.add(v);
        }
        return r;
    }
    static final String[] EXP_CATS = {"Reparaciones y mantenimiento", "Materiales y ferretería", "Mano de obra", "Limpieza",
            "Utilidades (luz, agua, gas)", "Internet y cable", "Muebles y electrodomésticos", "Hipoteca / renta de la casa",
            "Impuestos de propiedad", "Seguro", "Strata / edificio", "Publicidad", "Comisiones", "Sueldos y pagos al personal",
            "Gasolina y transporte", "Cargos del banco", "Oficina y papelería", "Devolución de depósito", "Otros gastos"};
    static final String[] INC_CATS = {"Check-in", "Enganche", "Recargo por atraso", "Cargo de limpieza / mudanza", "Lavandería", "Estacionamiento", "Otros ingresos"};
    /** Quién hizo el egreso (para agruparlos): los de siempre y los que se vayan escribiendo. */
    static final String[] SPENDERS = {"Hugo", "Elías", "Edgar"};
    List<String> spenders() {
        List<String> r = new ArrayList<>(java.util.Arrays.asList(SPENDERS));
        try { JSONArray a = new JSONArray(Store.get(this, "spenders", "[]")); for (int i = 0; i < a.length(); i++) if (!r.contains(a.getString(i))) r.add(a.getString(i)); } catch (Exception e) { }
        return r;
    }
    void addSpender(String n) { List<String> r = spenders(); if (r.contains(n)) return; JSONArray a = new JSONArray(); for (String x : r) if (!java.util.Arrays.asList(SPENDERS).contains(x)) a.put(x); a.put(n); Store.putS(this, "spenders", a.toString()); }
    static final String[] MOV_METHODS = {"Efectivo", "Tarjeta", "Débito", "e-Transfer", "Cheque", "Otro"};
    static final String RENT_CAT = "Rentas cobradas", UNASSIGNED = "Sin asignar";
    String finOwner = "", finHouse = "", finWho = "";
    boolean finYear = false, movPhoto = false;
    JSONObject mDraft = null;

    List<JSONObject> movs() { return Store.list(this, "movs"); }

    List<String> cats(boolean out) {
        List<String> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Store.get(this, out ? "expCats" : "incCats", ""));
            for (int i = 0; i < a.length(); i++) r.add(a.getString(i));
        } catch (Exception e) { Collections.addAll(r, out ? EXP_CATS : INC_CATS); }
        // una vez: «Devolución de depósito» en egresos; «Check-in» y «Enganche» en ingresos, sin «Reembolso»
        if (!Store.getB(this, out ? "catsV2o" : "catsV2i", false)) {
            if (out) { if (!r.contains("Devolución de depósito")) r.add(Math.max(0, r.size() - 1), "Devolución de depósito"); }
            else { r.remove("Reembolso"); if (!r.contains("Enganche")) r.add(0, "Enganche"); if (!r.contains("Check-in")) r.add(0, "Check-in"); }
            saveCats(out, r); Store.sp(this).edit().putBoolean(out ? "catsV2o" : "catsV2i", true).apply();
        }
        return r;
    }

    void saveCats(boolean out, List<String> l) { Store.putS(this, out ? "expCats" : "incCats", new JSONArray(l).toString()); }

    JSONObject ownerMap() {
        try { return new JSONObject(Store.get(this, "propOwner", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    static String houseOwner(JSONObject map, String prop) {
        return prop == null || prop.trim().isEmpty() ? "" : map.optString(Store.norm(prop));
    }

    void setHouseOwner(String prop, String o) {
        JSONObject m = ownerMap();
        Store.put(m, Store.norm(prop), o);
        Store.putS(this, "propOwner", m.toString());
        Sync.soon(this, 4000); // el Manager también ve de quién es cada casa
    }

    /** De quién es un movimiento: el dueño de su casa o, si es general, el que se eligió. */
    static String lineOwner(JSONObject x, JSONObject map) {
        String p = x.optString("prop").trim();
        String o = p.isEmpty() ? x.optString("owner") : houseOwner(map, p);
        return o.equals("Amigo") || o.equals("Callao") || o.equals(OTHERS) ? o : UNASSIGNED;
    }

    List<String> extraHouses() {
        List<String> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Store.get(this, "housesExtra", "[]"));
            for (int i = 0; i < a.length(); i++) r.add(a.getString(i));
        } catch (Exception e) { }
        return r;
    }

    List<String> houses() {
        List<String> r = new ArrayList<>(properties());
        List<String> seen = new ArrayList<>();
        for (String s : r) seen.add(Store.norm(s));
        List<String> more = extraHouses();
        for (JSONObject x : movs()) more.add(x.optString("prop"));
        for (String s : more) {
            s = s.trim();
            if (s.isEmpty() || seen.contains(Store.norm(s))) continue;
            seen.add(Store.norm(s));
            r.add(s);
        }
        Collections.sort(r, String::compareToIgnoreCase);
        return r;
    }

    /** Movimientos del periodo ("2026-10" o "2026"): los anotados a mano + las rentas cobradas (por fecha del pago). */
    List<JSONObject> finLines(String prefix) {
        List<JSONObject> r = new ArrayList<>();
        for (JSONObject x : movs()) if (x.optString("date").startsWith(prefix)) r.add(x);
        for (JSONObject rc : recs) {
            JSONArray a = rc.optJSONArray("payments");
            if (a == null) continue;
            JSONObject t = Store.tenant(tenants, rc.optInt("tid"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject p = a.optJSONObject(i);
                if (p == null || p.optLong("date") <= 0 || !Store.month(p.optLong("date")).startsWith(prefix)) continue;
                JSONObject y = new JSONObject();
                Store.put(y, "type", "in");
                Store.put(y, "rent", true);
                Store.put(y, "cat", RENT_CAT);
                Store.put(y, "prop", t == null ? "" : t.optString("property"));
                Store.put(y, "amount", p.optDouble("amount", 0));
                Store.put(y, "date", Store.dayOf(p.optLong("date")));
                Store.put(y, "desc", (t == null ? "Inquilino borrado" : t.optString("name")) + " · renta de " + Store.monthName(rc.optString("month")).toLowerCase(Store.ES));
                Store.put(y, "method", p.optString("method"));
                Store.put(y, "img", p.optString("img"));
                Store.put(y, "unit", t == null ? "" : t.optString("unit"));
                r.add(y);
            }
        }
        Collections.sort(r, (x, y) -> y.optString("date").compareTo(x.optString("date")));
        return r;
    }

    static boolean isIn(JSONObject x) { return "in".equals(x.optString("type")); }

    boolean finPass(JSONObject x, String owner) {
        if (!finOwner.isEmpty() && !finOwner.equals(owner)) return false;
        if (!finWho.isEmpty() && (isIn(x) || !finWho.equals(x.optString("spent").isEmpty() ? "Sin anotar" : x.optString("spent")))) return false;
        return finHouse.isEmpty() || Store.norm(x.optString("prop")).equals(Store.norm(finHouse));
    }

    String finPrefix() { return finYear ? month.substring(0, 4) : month; }

    String finPeriod() { return finYear ? "Año " + month.substring(0, 4) : Store.monthName(month); }

    int ownerColor(String o) { return o.equals("Amigo") ? PRI2 : o.equals("Callao") ? ORG : o.equals(OTHERS) ? 0xFF7C3AED : MUT; }

    TextView ownerBadge(String o) {
        TextView b = tv(o.equals(UNASSIGNED) ? "Sin asignar" : o, 11, Color.WHITE, true);
        b.setBackground(round(ownerColor(o), 8));
        b.setPadding(dp(7), dp(2), dp(7), dp(2));
        return b;
    }

    void finScreen() {
        JSONObject map = ownerMap();
        List<JSONObject> all = finLines(finPrefix());
        setHeader("Ingresos y egresos", finPeriod(), "💰", false);
        LinearLayout p = vbox();

        // periodo
        LinearLayout mn = hbox();
        mn.setPadding(dp(14), dp(10), dp(14), 0);
        TextView prev = tv("‹", 28, PRI2, true);
        prev.setPadding(dp(14), 0, dp(14), 0);
        prev.setOnClickListener(v -> { month = Store.addMonth(month, finYear ? -12 : -1); finScreen(); });
        TextView ml = tv(finPeriod(), 18, TXT, true);
        ml.setGravity(Gravity.CENTER);
        TextView next = tv("›", 28, PRI2, true);
        next.setPadding(dp(14), 0, dp(14), 0);
        next.setOnClickListener(v -> { month = Store.addMonth(month, finYear ? 12 : 1); finScreen(); });
        mn.addView(prev);
        mn.addView(ml, new LinearLayout.LayoutParams(0, -2, 1f));
        mn.addView(next);
        p.addView(mn);

        LinearLayout pc = hbox();
        pc.setPadding(dp(10), dp(2), dp(10), 0);
        pc.addView(chip("Mes", !finYear, v -> { finYear = false; finScreen(); }));
        pc.addView(chip("Año completo", finYear, v -> { finYear = true; finScreen(); }));
        p.addView(pc);

        boolean anyUn = false;
        for (JSONObject x : all) if (lineOwner(x, map).equals(UNASSIGNED)) { anyUn = true; break; }
        LinearLayout oc = hbox();
        oc.setPadding(dp(10), 0, dp(10), 0);
        oc.addView(chip("Todo", finOwner.isEmpty(), v -> { finOwner = ""; finScreen(); }));
        for (String o : GEN_OWNERS) oc.addView(chip(o, o.equals(finOwner), v -> { finOwner = o; finScreen(); }));
        if (anyUn || finOwner.equals(UNASSIGNED)) oc.addView(chip("⚠️ Sin asignar", finOwner.equals(UNASSIGNED), v -> { finOwner = UNASSIGNED; finScreen(); }));
        p.addView(hscroll(oc));

        TextView hf = field("🏠  " + (finHouse.isEmpty() ? "Todas las casas" : finHouse) + "  ▾");
        ((LinearLayout.LayoutParams) hf.getLayoutParams()).setMargins(dp(14), dp(4), dp(14), dp(4));
        hf.setOnClickListener(x -> {
            List<String> hs = houses();
            hs.add(0, "Todas las casas");
            new AlertDialog.Builder(this).setTitle("Casa").setItems(hs.toArray(new String[0]), (d, w) -> {
                finHouse = w == 0 ? "" : hs.get(w);
                finScreen();
            }).show();
        });
        p.addView(hf);

        List<JSONObject> l = new ArrayList<>();
        double inc = 0, out = 0, rentSum = 0;
        int rentN = 0;
        java.util.LinkedHashMap<String, double[]> byOwner = new java.util.LinkedHashMap<>();
        for (String o : GEN_OWNERS) byOwner.put(o, new double[2]);
        byOwner.put(UNASSIGNED, new double[2]);
        java.util.HashMap<String, Double> byCat = new java.util.HashMap<>();
        java.util.TreeMap<String, double[]> byHouse = new java.util.TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for (JSONObject x : all) {
            String o = lineOwner(x, map);
            boolean hOk = finHouse.isEmpty() || Store.norm(x.optString("prop")).equals(Store.norm(finHouse));
            double a = x.optDouble("amount", 0);
            if (hOk) byOwner.get(o)[isIn(x) ? 0 : 1] += a;
            if (!finPass(x, o)) continue;
            l.add(x);
            if (isIn(x)) inc += a; else { out += a; byCat.put(x.optString("cat"), byCat.containsKey(x.optString("cat")) ? byCat.get(x.optString("cat")) + a : a); }
            if (x.optBoolean("rent")) { rentSum += a; rentN++; }
            String h = x.optString("prop").trim().isEmpty() ? "" : x.optString("prop").trim();
            if (!byHouse.containsKey(h)) byHouse.put(h, new double[2]);
            byHouse.get(h)[isIn(x) ? 0 : 1] += a;
        }

        LinearLayout big = card();
        big.setBackground(round(PRI, 18));
        if (!finOwner.isEmpty() || !finHouse.isEmpty())
            big.addView(tv(join(" · ", finOwner.equals(UNASSIGNED) ? "Sin asignar" : finOwner, finHouse), 12, 0xFFCFE0FF, true));
        LinearLayout r1 = hbox();
        r1.addView(bigNum("Ingresos", money(inc), 0xFF86EFAC), new LinearLayout.LayoutParams(0, -2, 1f));
        r1.addView(bigNum("Egresos", money(out), 0xFFFCA5A5), new LinearLayout.LayoutParams(0, -2, 1f));
        r1.addView(bigNum("Balance", money(inc - out), inc - out >= 0 ? Color.WHITE : 0xFFFCA5A5), new LinearLayout.LayoutParams(0, -2, 1f));
        big.addView(r1);
        p.addView(big);

        LinearLayout acts = hbox();
        acts.setPadding(dp(11), dp(4), dp(11), 0);
        acts.addView(action("🔻", "Egreso", RED, 0xFFFDE6E6, v -> openMov(null, false)));
        acts.addView(action("🔺", "Ingreso", 0xFF15803D, 0xFFE3F6E8, v -> openMov(null, true)));
        acts.addView(action("🏠", "Casas", PRI2, 0xFFEAF1FF, v -> open(this::housesScreen)));
        acts.addView(action("📊", "Excel", PRI2, 0xFFEAF1FF, v -> finExport()));
        p.addView(acts);

        if (finOwner.isEmpty()) {
            p.addView(sectionTitle("Amigo, Callao y Otros", null, null));
            LinearLayout oc2 = card();
            boolean first = true;
            for (java.util.Map.Entry<String, double[]> e : byOwner.entrySet()) {
                double[] v = e.getValue();
                if ((e.getKey().equals(UNASSIGNED) || e.getKey().equals(OTHERS)) && v[0] == 0 && v[1] == 0) continue;
                if (!first) oc2.addView(divider());
                first = false;
                LinearLayout row = hbox();
                row.addView(ownerBadge(e.getKey()));
                TextView s = tv("  Ingresos " + money(v[0]) + " · Egresos " + money(v[1]), 13, MUT, false);
                row.addView(s, new LinearLayout.LayoutParams(0, -2, 1f));
                row.addView(tv(money(v[0] - v[1]), 16, v[0] - v[1] >= 0 ? 0xFF15803D : RED, true));
                final String ow = e.getKey();
                row.setOnClickListener(x -> { finOwner = ow; finScreen(); });
                oc2.addView(row);
            }
            if (anyUn) {
                TextView w = tv("⚠️ Hay casas sin marcar como Amigo o Callao. Toca aquí para marcarlas.", 13, YEL, true);
                w.setPadding(0, dp(10), 0, 0);
                w.setOnClickListener(x -> open(this::housesScreen));
                oc2.addView(w);
            }
            p.addView(oc2);
        }

        java.util.TreeMap<String, Double> byFor = new java.util.TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for (JSONObject x : l) if (!isIn(x) && OTHERS.equals(lineOwner(x, map))) {
            String k = x.optString("otherFor").trim().isEmpty() ? "Sin especificar" : x.optString("otherFor").trim();
            byFor.put(k, (byFor.containsKey(k) ? byFor.get(k) : 0) + x.optDouble("amount", 0));
        }
        if (!byFor.isEmpty()) {
            p.addView(sectionTitle("Otros: en qué se gastó", null, null));
            LinearLayout oc3 = card();
            for (java.util.Map.Entry<String, Double> e : byFor.entrySet()) {
                if (oc3.getChildCount() > 0) oc3.addView(divider());
                oc3.addView(kv("🚗 " + e.getKey(), money(e.getValue()), RED));
            }
            p.addView(oc3);
        }
        // 👤 egresos por persona (Hugo, Elías, Edgar…)
        java.util.LinkedHashMap<String, double[]> byWho = new java.util.LinkedHashMap<>();
        for (String n : SPENDERS) byWho.put(n, new double[2]);
        for (JSONObject x : all) {
            if (isIn(x)) continue;
            boolean hOk = finHouse.isEmpty() || Store.norm(x.optString("prop")).equals(Store.norm(finHouse));
            if (!hOk || (!finOwner.isEmpty() && !finOwner.equals(lineOwner(x, map)))) continue;
            String w = x.optString("spent").isEmpty() ? "Sin anotar" : x.optString("spent");
            if (!byWho.containsKey(w)) byWho.put(w, new double[2]);
            byWho.get(w)[0] += x.optDouble("amount", 0); byWho.get(w)[1]++;
        }
        p.addView(sectionTitle("Egresos por persona", finWho.isEmpty() ? null : "Ver todos", v -> { finWho = ""; finScreen(); }));
        LinearLayout wc = card();
        for (java.util.Map.Entry<String, double[]> e : byWho.entrySet()) {
            double[] v = e.getValue();
            if (v[1] == 0 && !java.util.Arrays.asList(SPENDERS).contains(e.getKey())) continue;
            if (wc.getChildCount() > 0) wc.addView(divider());
            LinearLayout row = hbox();
            boolean sel = e.getKey().equals(finWho);
            row.addView(tv((e.getKey().equals("Sin anotar") ? "❔ " : "👤 ") + e.getKey() + (sel ? "  ✓" : ""), 15, sel ? PRI2 : TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
            row.addView(tv((int) v[1] + (v[1] == 1 ? " egreso  " : " egresos  "), 12, MUT, false));
            row.addView(tv(money(v[0]), 15, v[0] > 0 ? RED : MUT, true));
            final String who = e.getKey();
            row.setOnClickListener(x -> { finWho = who.equals(finWho) ? "" : who; finScreen(); });
            wc.addView(row);
        }
        wc.addView(tv("Toca a una persona para ver solo sus egresos.", 12, MUT, false));
        p.addView(wc);

        if (out > 0) {
            p.addView(sectionTitle("Egresos por categoría", null, null));
            LinearLayout cc = card();
            List<String> ks = new ArrayList<>(byCat.keySet());
            Collections.sort(ks, (a, b) -> Double.compare(byCat.get(b), byCat.get(a)));
            for (int i = 0; i < ks.size(); i++) {
                if (i > 0) cc.addView(gap(8));
                double v = byCat.get(ks.get(i));
                LinearLayout row = hbox();
                row.addView(tv(ks.get(i).isEmpty() ? "Sin categoría" : ks.get(i), 14, TXT, false), new LinearLayout.LayoutParams(0, -2, 1f));
                row.addView(tv(money(v) + "  ", 14, TXT, true));
                row.addView(tv(Math.round(v * 100 / out) + "%", 12, MUT, false));
                cc.addView(row);
                LinearLayout bar = hbox();
                bar.setBackground(round(0xFFF1F3F7, 4));
                bar.setClipToOutline(true);
                View fill = new View(this);
                fill.setBackgroundColor(0xFFF87171);
                float pc2 = (float) (v / out);
                bar.addView(fill, new LinearLayout.LayoutParams(0, dp(6), Math.max(pc2, 0.0001f)));
                bar.addView(new View(this), new LinearLayout.LayoutParams(0, dp(6), Math.max(1 - pc2, 0.0001f)));
                LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(6));
                bl.setMargins(0, dp(3), 0, 0);
                cc.addView(bar, bl);
            }
            p.addView(cc);
        }

        if (finHouse.isEmpty() && !byHouse.isEmpty()) {
            p.addView(sectionTitle("Por casa", null, null));
            LinearLayout hc = card();
            boolean first = true;
            for (java.util.Map.Entry<String, double[]> e : byHouse.entrySet()) {
                if (!first) hc.addView(divider());
                first = false;
                double[] v = e.getValue();
                LinearLayout row = hbox();
                LinearLayout tx = vbox();
                LinearLayout nm = hbox();
                TextView hn = tv(e.getKey().isEmpty() ? "Sin casa (general)" : e.getKey() + "  ", 15, TXT, true);
                hn.setMaxLines(1);
                hn.setEllipsize(TextUtils.TruncateAt.END);
                nm.addView(hn, new LinearLayout.LayoutParams(0, -2, 1f));
                if (!e.getKey().isEmpty()) nm.addView(ownerBadge(houseOwner(map, e.getKey()).isEmpty() ? UNASSIGNED : houseOwner(map, e.getKey())));
                tx.addView(nm);
                tx.addView(tv("Ingresos " + money(v[0]) + " · Egresos " + money(v[1]), 12, MUT, false));
                row.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
                TextView bal = tv("  " + money(v[0] - v[1]), 15, v[0] - v[1] >= 0 ? 0xFF15803D : RED, true);
                row.addView(bal);
                final String h = e.getKey();
                if (!h.isEmpty()) row.setOnClickListener(x -> { finHouse = h; finScreen(); });
                hc.addView(row);
            }
            p.addView(hc);
        }

        p.addView(sectionTitle("Movimientos", null, null));
        if (l.isEmpty()) p.addView(empty("No hay ingresos ni egresos en " + finPeriod().toLowerCase(Store.ES) + ".\nToca «＋ Egreso» para anotar el primero."));
        if (rentN > 0) {
            LinearLayout rc = card();
            rc.setOrientation(LinearLayout.HORIZONTAL);
            rc.setGravity(Gravity.CENTER_VERTICAL);
            TextView ic = tv("💵", 20, TXT, false);
            ic.setGravity(Gravity.CENTER);
            ic.setBackground(round(0xFFE3F6E8, 12));
            rc.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(44)));
            LinearLayout tx = vbox();
            tx.setPadding(dp(12), 0, dp(6), 0);
            tx.addView(tv(RENT_CAT, 16, TXT, true));
            tx.addView(tv(rentN + (rentN == 1 ? " pago" : " pagos") + " de inquilinos · se suman solas", 13, MUT, false));
            rc.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
            rc.addView(tv("+" + money(rentSum), 16, 0xFF15803D, true));
            rc.setOnClickListener(v -> open(this::rentLinesScreen));
            p.addView(rc);
        }
        for (JSONObject x : l) if (!x.optBoolean("rent")) p.addView(movRow(x, map));

        LinearLayout mc = card();
        mc.addView(menuRow("🏠", "Casas: Amigo o Callao", "Marca de quién es cada casa", v -> open(this::housesScreen)));
        mc.addView(divider());
        mc.addView(menuRow("🏷️", "Categorías de egresos", cats(true).size() + " categorías", v -> open(() -> catsScreen(true))));
        mc.addView(divider());
        mc.addView(menuRow("🏷️", "Categorías de ingresos", cats(false).size() + " categorías (las rentas se suman solas)", v -> open(() -> catsScreen(false))));
        mc.addView(divider());
        mc.addView(menuRow("📊", "Exportar a Excel", "Del mes o del año, separado por Amigo y Callao", v -> finExport()));
        LinearLayout.LayoutParams ml2 = (LinearLayout.LayoutParams) mc.getLayoutParams();
        ml2.topMargin = dp(18);
        p.addView(mc);
        show(scroll(p), true, "＋  Egreso", () -> openMov(null, false));
    }

    View movRow(JSONObject x, JSONObject map) {
        boolean in = isIn(x);
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        TextView ic = tv(in ? "🔺" : "🔻", 18, TXT, false);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(round(in ? 0xFFE3F6E8 : 0xFFFDE6E6, 12));
        c.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout v = vbox();
        v.setPadding(dp(12), 0, dp(6), 0);
        String desc = x.optString("desc").trim();
        TextView nm = tv(desc.isEmpty() ? x.optString("cat") : desc, 15, TXT, true);
        nm.setMaxLines(1);
        nm.setEllipsize(TextUtils.TruncateAt.END);
        v.addView(nm);
        TextView sub = tv(join(" · ", Store.shortDate(x.optString("date")), desc.isEmpty() ? "" : x.optString("cat"),
                x.optString("prop").trim().isEmpty() ? (x.optString("otherFor").isEmpty() ? "General" : x.optString("otherFor")) : x.optString("prop"), x.optString("img").isEmpty() ? "" : "🧾",
                x.optString("spent").isEmpty() ? "" : "👤 " + x.optString("spent"), x.optString("by").isEmpty() ? "" : "anotó " + x.optString("by")), 12, MUT, false);
        sub.setMaxLines(2);
        v.addView(sub);
        LinearLayout ob = hbox();
        ob.setPadding(0, dp(3), 0, 0);
        ob.addView(ownerBadge(lineOwner(x, map)));
        v.addView(ob);
        c.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(tv((in ? "+" : "-") + money(x.optDouble("amount", 0)), 15, in ? 0xFF15803D : RED, true));
        c.setOnClickListener(k -> openMov(x, in));
        return c;
    }

    void rentLinesScreen() {
        JSONObject map = ownerMap();
        List<JSONObject> l = new ArrayList<>();
        double s = 0;
        for (JSONObject x : finLines(finPrefix())) if (x.optBoolean("rent") && finPass(x, lineOwner(x, map))) { l.add(x); s += x.optDouble("amount", 0); }
        setHeader(RENT_CAT, finPeriod() + " · " + money(s), null, true);
        LinearLayout p = vbox();
        TextView info = tv("Son los pagos registrados en la pestaña Mes (tuyos, automáticos y del Manager), contados por la fecha en que se recibieron. No hay que anotarlos aquí.", 13, MUT, false);
        info.setPadding(dp(18), dp(8), dp(18), dp(4));
        p.addView(info);
        if (l.isEmpty()) p.addView(empty("No hay pagos de renta en este periodo."));
        for (JSONObject x : l) {
            LinearLayout c = card();
            c.setOrientation(LinearLayout.HORIZONTAL);
            c.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout v = vbox();
            v.addView(tv(x.optString("desc"), 15, TXT, true));
            v.addView(tv(join(" · ", Store.shortDate(x.optString("date")), x.optString("prop"), x.optString("method")), 12, MUT, false));
            LinearLayout ob = hbox();
            ob.setPadding(0, dp(3), 0, 0);
            ob.addView(ownerBadge(lineOwner(x, map)));
            v.addView(ob);
            c.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
            c.addView(tv("+" + money(x.optDouble("amount", 0)), 15, 0xFF15803D, true));
            if (!x.optString("img").isEmpty()) { final String u = x.optString("img"); c.setOnClickListener(k -> viewImage(u)); }
            p.addView(c);
        }
        show(scroll(p), false, null, null);
    }

    void openMov(JSONObject x, boolean in) {
        JSONObject d = new JSONObject();
        try {
            if (x != null) {
                d = new JSONObject(x.toString());
                Store.put(d, "amountS", qty(x.optDouble("amount", 0)));
                Store.put(d, "houseSet", true);
            } else {
                Store.put(d, "type", in ? "in" : "out");
                Store.put(d, "date", Store.today());
                if (!finHouse.isEmpty()) { Store.put(d, "prop", finHouse); Store.put(d, "houseSet", true); }
                if (finHouse.isEmpty() && (finOwner.equals("Amigo") || finOwner.equals("Callao") || finOwner.equals(OTHERS))) Store.put(d, "ownerHint", finOwner);
            }
        } catch (Exception e) { }
        mDraft = d;
        open(this::movForm);
    }

    void movForm() {
        final JSONObject d = mDraft;
        if (d == null) { goBack(); return; }
        final boolean out = !isIn(d), edit = d.optInt("id") > 0;
        setHeader(edit ? (out ? "Editar egreso" : "Editar ingreso") : (out ? "Nuevo egreso" : "Nuevo ingreso"), null, null, true);
        formMode();
        JSONObject map = ownerMap();
        LinearLayout p = vbox();
        LinearLayout f = card();

        LinearLayout tr = hbox();
        tr.addView(chip("🔻 Egreso", out, v -> { if (!out) { Store.put(d, "type", "out"); Store.put(d, "cat", ""); refresh(); } }));
        tr.addView(chip("🔺 Ingreso", !out, v -> { if (out) { Store.put(d, "type", "in"); Store.put(d, "cat", ""); refresh(); } }));
        f.addView(tr);

        EditText amt = input("0.00", DEC);
        amt.setText(d.optString("amountS"));
        watch(amt, () -> Store.put(d, "amountS", amt.getText().toString()));
        TextView df = field("📅  " + Store.shortDate(d.optString("date")));
        df.setOnClickListener(v -> pickDate(d.optString("date"), iso -> { Store.put(d, "date", iso); df.setText("📅  " + Store.shortDate(iso)); }));
        f.addView(twoCols(labeled("Monto (" + Store.get(this, "cur", "$") + ")", amt), labeled("Fecha", df)));

        f.addView(label("🏷️", "Categoría", true));
        TextView cf = field(d.optString("cat").isEmpty() ? "Elige la categoría  ▾" : d.optString("cat") + "  ▾");
        if (d.optString("cat").isEmpty()) cf.setTextColor(MUT);
        cf.setOnClickListener(v -> {
            List<String> cs = cats(out);
            cs.add("＋ Nueva categoría…");
            new AlertDialog.Builder(this).setTitle(out ? "Categoría del egreso" : "Categoría del ingreso").setItems(cs.toArray(new String[0]), (dl, w) -> {
                if (w < cs.size() - 1) { Store.put(d, "cat", cs.get(w)); refresh(); return; }
                askText("Nueva categoría", "Ej. Plomería", "", s -> {
                    List<String> all = cats(out);
                    boolean has = false;
                    for (String c : all) if (Store.norm(c).equals(Store.norm(s))) { s = c; has = true; break; }
                    if (!has) { all.add(s); saveCats(out, all); }
                    Store.put(d, "cat", s);
                    refresh();
                });
            }).show();
        });
        f.addView(cf);

        if (out) { // 👤 quién hizo el egreso (Hugo, Elías, Edgar…): luego se agrupan en Finanzas
            f.addView(label("👤", "¿Quién hizo el egreso?", false));
            LinearLayout sr = hbox();
            String curS = d.optString("spent");
            for (String n : spenders()) sr.addView(chip(n, n.equals(curS), v -> { Store.put(d, "spent", n.equals(d.optString("spent")) ? "" : n); refresh(); }));
            sr.addView(chip("＋ Otro", false, v -> askText("¿Quién hizo el egreso?", "Nombre", "", s2 -> { addSpender(s2.trim()); Store.put(d, "spent", s2.trim()); refresh(); })));
            f.addView(hscroll(sr));
        }

        f.addView(label("🏠", out ? "¿En qué casa se hizo el egreso?" : "¿De qué casa es el ingreso?", true));
        final String prop = d.optString("prop").trim();
        boolean houseSet = d.optBoolean("houseSet");
        TextView hf = field(!houseSet ? "Elige la casa  ▾" : prop.isEmpty() ? "Sin casa (general / oficina)  ▾" : prop + "  ▾");
        if (!houseSet) hf.setTextColor(MUT);
        hf.setOnClickListener(v -> {
            List<String> hs = houses();
            hs.add("Sin casa (general / oficina)");
            hs.add("＋ Otra casa…");
            new AlertDialog.Builder(this).setTitle("Casa").setItems(hs.toArray(new String[0]), (dl, w) -> {
                if (w == hs.size() - 1) {
                    askText("Otra casa", "Dirección o nombre de la casa", "", s -> {
                        addExtraHouse(s);
                        Store.put(d, "prop", s);
                        Store.put(d, "houseSet", true);
                        refresh();
                    });
                    return;
                }
                Store.put(d, "prop", w == hs.size() - 2 ? "" : hs.get(w));
                Store.put(d, "houseSet", true);
                refresh();
            }).show();
        });
        f.addView(hf);

        if (houseSet) {
            if (!prop.isEmpty()) {
                final String cur = houseOwner(map, prop);
                f.addView(label("🏢", "Esta casa es de", true));
                LinearLayout orow = hbox();
                for (String o : OWNERS) orow.addView(chip(o, o.equals(cur), v -> {
                    if (o.equals(cur)) return;
                    if (cur.isEmpty()) { setHouseOwner(prop, o); refresh(); return; }
                    new AlertDialog.Builder(this).setTitle("¿Cambiar la casa a " + o + "?")
                            .setMessage("«" + prop + "» pasará a ser de " + o + ". Todos sus ingresos y egresos (también los anteriores y las rentas) se contarán para " + o + ".")
                            .setPositiveButton("Cambiar", (dl, w) -> { setHouseOwner(prop, o); refresh(); })
                            .setNegativeButton("Cancelar", null).show();
                }));
                f.addView(orow);
                f.addView(tv(cur.isEmpty() ? "Elígelo una vez: la app lo recuerda para esta casa." : "Se toma de la casa. Lo cambias en Finanzas → Casas.", 12, cur.isEmpty() ? YEL : MUT, false));
            } else {
                String cur = d.optString("owner", d.optString("ownerHint"));
                f.addView(label("🏢", out ? "¿De quién es este egreso?" : "¿De quién es este ingreso?", true));
                LinearLayout orow = hbox();
                for (String o : GEN_OWNERS) orow.addView(chip(o, o.equals(cur), v -> { Store.put(d, "owner", o); refresh(); }));
                f.addView(orow);
                f.addView(tv("«Otros» es para egresos que no son de Amigo ni de Callao, como el combustible de los operadores o del Manager.", 12, MUT, false));
                if (OTHERS.equals(cur)) {
                    f.addView(label("🚗", out ? "¿En qué fue el egreso?" : "¿De qué fue el ingreso?", true));
                    String of = d.optString("otherFor");
                    TextView ofv = field(of.isEmpty() ? "Elige: carro, oficina, operadores…  ▾" : of + "  ▾");
                    if (of.isEmpty()) ofv.setTextColor(MUT);
                    ofv.setOnClickListener(v -> {
                        List<String> os = otherForOptions();
                        os.add("＋ Otro…");
                        new AlertDialog.Builder(this).setTitle("¿En qué fue?").setItems(os.toArray(new String[0]), (dl, w) -> {
                            if (w < os.size() - 1) { Store.put(d, "otherFor", os.get(w)); refresh(); return; }
                            askText("¿En qué fue?", "Ej. Seguro del carro", "", t -> { Store.put(d, "otherFor", t); refresh(); });
                        }).show();
                    });
                    f.addView(ofv);
                }
            }
        }

        f.addView(label("💳", out ? "¿Cómo se pagó?" : "¿Cómo se recibió?", false));
        LinearLayout mr = hbox();
        for (String m : MOV_METHODS) mr.addView(chip(m, m.equals(d.optString("method")), v -> {
            Store.put(d, "method", m.equals(d.optString("method")) ? "" : m);
            refresh();
        }));
        f.addView(hscroll(mr));

        EditText desc = input(out ? "Detalle o proveedor (ej. Home Depot, plomero)" : "Detalle (ej. lavandería cuarto 3)", TXT_MULTI);
        desc.setText(d.optString("desc"));
        watch(desc, () -> Store.put(d, "desc", desc.getText().toString()));
        f.addView(labeled("Detalle", desc));

        f.addView(label("🧾", out ? "Recibo o factura (foto)" : "Comprobante (foto)", false));
        final String img = d.optString("img");
        if (!img.isEmpty()) {
            LinearLayout ir = hbox();
            ImageView pv = new ImageView(this);
            pv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            pv.setBackground(round(0xFFE1E7EF, 12));
            pv.setClipToOutline(true);
            ir.addView(pv, new LinearLayout.LayoutParams(dp(90), dp(90)));
            loadThumb(pv, Uri.parse(img));
            pv.setOnClickListener(v -> viewImage(img));
            LinearLayout iv = vbox();
            iv.setPadding(dp(12), 0, 0, 0);
            iv.addView(tv("✅ Foto lista", 14, 0xFF15803D, true));
            TextView rm = tv("Quitar", 14, RED, true);
            rm.setPadding(0, dp(8), 0, 0);
            rm.setOnClickListener(v -> { Store.put(d, "img", ""); refresh(); });
            iv.addView(rm);
            ir.addView(iv, new LinearLayout.LayoutParams(0, -2, 1f));
            LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(-1, -2);
            il.setMargins(0, dp(6), 0, 0);
            f.addView(ir, il);
        } else {
            LinearLayout ib = hbox();
            ib.setPadding(0, dp(6), 0, 0);
            ib.addView(smallBtn("📷 Tomar foto", PRI2, v -> { pendingPayId = -1; movPhoto = true; capture(); }), weightLp(1f));
            ib.addView(smallBtn("🖼️ De la galería", PRI2, v -> { pendingPayId = -1; movPhoto = true; pickImage(); }), weightLp(1f));
            f.addView(ib);
        }
        p.addView(f);

        p.addView(button(out ? "🔻  Guardar egreso" : "🔺  Guardar ingreso", out ? RED : GRN, v -> {
            double a = num(d.optString("amountS"));
            if (a <= 0) { toast("Escribe el monto"); return; }
            if (d.optString("cat").isEmpty()) { toast("Elige la categoría"); return; }
            if (!d.optBoolean("houseSet")) { toast("Elige la casa (o «Sin casa»)"); return; }
            String pr = d.optString("prop").trim();
            String ow = pr.isEmpty() ? d.optString("owner", d.optString("ownerHint")) : houseOwner(ownerMap(), pr);
            if (ow.isEmpty()) { toast(pr.isEmpty() ? "Elige si es de Amigo, de Callao u Otros" : "Marca si la casa es de Amigo o de Callao"); return; }
            JSONObject x = new JSONObject();
            int id = d.optInt("id") > 0 ? d.optInt("id") : Store.nextId(this);
            Store.put(x, "id", id);
            Store.put(x, "type", out ? "out" : "in");
            Store.put(x, "date", d.optString("date"));
            Store.put(x, "amount", a);
            Store.put(x, "cat", d.optString("cat"));
            Store.put(x, "prop", pr);
            if (pr.isEmpty()) Store.put(x, "owner", ow);
            if (pr.isEmpty() && OTHERS.equals(ow)) {
                if (d.optString("otherFor").trim().isEmpty()) { toast("Elige en qué fue el egreso"); return; }
                Store.put(x, "otherFor", d.optString("otherFor").trim());
            }
            Store.put(x, "method", d.optString("method"));
            if (out) Store.put(x, "spent", d.optString("spent"));
            Store.put(x, "desc", d.optString("desc").trim());
            Store.put(x, "img", d.optString("img"));
            if (!d.optString("img").isEmpty() && d.optString("img").equals(d.optString("imgFor"))) { Store.put(x, "imgId", d.optString("imgId")); Store.put(x, "imgFor", d.optString("imgFor")); Store.put(x, "imgDl", d.optString("imgDl")); }
            for (String k : new String[]{"srvId", "by"}) if (!d.optString(k).isEmpty()) Store.put(x, k, d.optString(k));
            Store.put(x, "created", d.optLong("created", System.currentTimeMillis()));
            List<JSONObject> ms = movs();
            boolean rep = false;
            for (int i = 0; i < ms.size(); i++) if (ms.get(i).optInt("id") == id) { ms.set(i, x); rep = true; }
            if (!rep) ms.add(x);
            Store.save(this, "movs", ms);
            mDraft = null;
            toast((out ? "Egreso" : "Ingreso") + " guardado ✅");
            goBack();
        }));
        if (edit) {
            final JSONObject dd = d;
            TextView sh = outline("💬  Compartir por WhatsApp", 0xFF128C7E, v -> waShareAny(movText(dd), dd.optString("img").isEmpty() ? null : Uri.parse(dd.optString("img"))));
            LinearLayout.LayoutParams shl = new LinearLayout.LayoutParams(-1, -2);
            shl.setMargins(dp(14), dp(6), dp(14), 0);
            p.addView(sh, shl);
            TextView del = outline("🗑️  Borrar", RED, v -> new AlertDialog.Builder(this).setTitle("¿Borrar este " + (out ? "egreso" : "ingreso") + "?")
                    .setPositiveButton("Borrar", (dl, w) -> {
                        List<JSONObject> ms = movs();
                        for (int i = ms.size() - 1; i >= 0; i--) if (ms.get(i).optInt("id") == d.optInt("id")) ms.remove(i);
                        Store.save(this, "movs", ms);
                        mDraft = null;
                        toast("Borrado");
                        goBack();
                    }).setNegativeButton("Cancelar", null).show());
            LinearLayout.LayoutParams dl2 = new LinearLayout.LayoutParams(-1, -2);
            dl2.setMargins(dp(14), dp(6), dp(14), dp(6));
            p.addView(del, dl2);
        }
        show(scroll(p), false, null, null);
    }

    void askText(String title, String hint, String val, Cb cb) {
        EditText e = input(hint, TXT_CAP);
        e.setText(val);
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(6), dp(20), 0);
        box.addView(e);
        new AlertDialog.Builder(this).setTitle(title).setView(box)
                .setPositiveButton("Guardar", (dl, w) -> {
                    String s = e.getText().toString().trim();
                    if (!s.isEmpty()) cb.on(s);
                }).setNegativeButton("Cancelar", null).show();
    }

    void addExtraHouse(String s) {
        List<String> ex = extraHouses();
        for (String h : houses()) if (Store.norm(h).equals(Store.norm(s))) return;
        ex.add(s);
        Store.putS(this, "housesExtra", new JSONArray(ex).toString());
    }

    void housesScreen() {
        JSONObject map = ownerMap();
        List<String> hs = houses();
        int un = 0;
        for (String h : hs) if (houseOwner(map, h).isEmpty()) un++;
        setHeader("Casas: Amigo o Callao", hs.size() + " casas" + (un > 0 ? " · " + un + " sin marcar" : ""), null, true);
        LinearLayout p = vbox();
        TextView info = tv("Marca de quién es cada casa. Los egresos, los ingresos y las rentas de esa casa se suman para Amigo o para Callao.", 13, MUT, false);
        info.setPadding(dp(18), dp(8), dp(18), dp(4));
        p.addView(info);
        if (hs.isEmpty()) p.addView(empty("Todavía no hay casas. Se toman de las propiedades de tus inquilinos, o agrega una abajo."));
        List<String> sorted = new ArrayList<>(hs);
        Collections.sort(sorted, (a, b) -> Boolean.compare(!houseOwner(map, a).isEmpty(), !houseOwner(map, b).isEmpty()));
        List<String> extra = extraHouses();
        for (String h : sorted) {
            final String cur = houseOwner(map, h);
            LinearLayout c = card();
            int n = 0;
            for (JSONObject t : tenants) if (!t.optBoolean("inactive") && Store.norm(t.optString("property")).equals(Store.norm(h))) n++;
            LinearLayout top = hbox();
            TextView nm = tv(h, 16, TXT, true);
            top.addView(nm, new LinearLayout.LayoutParams(0, -2, 1f));
            if (cur.isEmpty()) top.addView(ownerBadge(UNASSIGNED));
            c.addView(top);
            c.addView(tv(n > 0 ? n + (n == 1 ? " inquilino" : " inquilinos") : "Sin inquilinos", 12, MUT, false));
            LinearLayout orow = hbox();
            for (String o : OWNERS) orow.addView(chip(o, o.equals(cur), v -> { setHouseOwner(h, o); refresh(); }));
            c.addView(orow);
            boolean isExtra = false;
            for (String e : extra) if (Store.norm(e).equals(Store.norm(h))) isExtra = true;
            if (isExtra && n == 0) {
                TextView rm = tv("Quitar de la lista", 13, RED, true);
                rm.setPadding(0, dp(4), 0, 0);
                rm.setOnClickListener(v -> {
                    for (JSONObject x : movs()) if (Store.norm(x.optString("prop")).equals(Store.norm(h))) { toast("Tiene movimientos anotados; no se puede quitar"); return; }
                    List<String> ex = extraHouses();
                    for (int i = ex.size() - 1; i >= 0; i--) if (Store.norm(ex.get(i)).equals(Store.norm(h))) ex.remove(i);
                    Store.putS(this, "housesExtra", new JSONArray(ex).toString());
                    refresh();
                });
                c.addView(rm);
            }
            p.addView(c);
        }
        p.addView(button("＋  Agregar casa", PRI2, v -> askText("Agregar casa", "Dirección o nombre de la casa", "", s -> { addExtraHouse(s); refresh(); })));
        show(scroll(p), false, null, null);
    }

    void catsScreen(boolean out) {
        List<String> cs = cats(out);
        setHeader(out ? "Categorías de egresos" : "Categorías de ingresos", cs.size() + " categorías", null, true);
        LinearLayout p = vbox();
        if (!out) {
            TextView info = tv("Las rentas de los inquilinos se suman solas como «" + RENT_CAT + "». Aquí van los otros ingresos.", 13, MUT, false);
            info.setPadding(dp(18), dp(8), dp(18), dp(4));
            p.addView(info);
        }
        LinearLayout c = card();
        for (int i = 0; i < cs.size(); i++) {
            if (i > 0) c.addView(divider());
            final String name = cs.get(i);
            final int idx = i;
            LinearLayout r = hbox();
            r.addView(tv(name, 15, TXT, false), new LinearLayout.LayoutParams(0, -2, 1f));
            r.addView(tv("⋮", 20, MUT, true));
            r.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(name)
                    .setItems(new String[]{"✏️ Cambiar nombre", "⬆️ Subir", "🗑️ Quitar"}, (dl, w) -> {
                        List<String> l = cats(out);
                        if (w == 0) askText("Cambiar nombre", name, name, s -> {
                            List<String> l2 = cats(out);
                            l2.set(idx, s);
                            saveCats(out, l2);
                            List<JSONObject> ms = movs();
                            for (JSONObject x : ms) if (x.optString("cat").equals(name) && isIn(x) != out) Store.put(x, "cat", s);
                            Store.save(this, "movs", ms);
                            refresh();
                        });
                        else if (w == 1) { if (idx > 0) { Collections.swap(l, idx, idx - 1); saveCats(out, l); refresh(); } }
                        else { l.remove(idx); saveCats(out, l); toast("Quitada. Lo ya anotado conserva su categoría."); refresh(); }
                    }).show());
            c.addView(r);
        }
        if (cs.isEmpty()) c.addView(tv("No hay categorías.", 14, MUT, false));
        p.addView(c);
        p.addView(button("＋  Agregar categoría", PRI2, v -> askText("Nueva categoría", "Ej. Plomería", "", s -> {
            List<String> l = cats(out);
            for (String x : l) if (Store.norm(x).equals(Store.norm(s))) { toast("Ya existe"); return; }
            l.add(s);
            saveCats(out, l);
            refresh();
        })));
        TextView rs = tv("Volver a las categorías de fábrica", 14, PRI2, true);
        rs.setGravity(Gravity.CENTER);
        rs.setPadding(0, dp(14), 0, 0);
        rs.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("¿Volver a las categorías de fábrica?")
                .setMessage("Se reemplaza la lista. Lo ya anotado conserva su categoría.")
                .setPositiveButton("Sí", (dl, w) -> { Store.putS(this, out ? "expCats" : "incCats", ""); refresh(); })
                .setNegativeButton("No", null).show());
        p.addView(rs, new LinearLayout.LayoutParams(-1, -2));
        show(scroll(p), false, null, null);
    }

    // ---------- Excel de ingresos y egresos ----------
    void finExport() {
        if (Build.VERSION.SDK_INT < 29) { toast("Esta función necesita Android 10 o más nuevo"); return; }
        final String m = month, y = month.substring(0, 4);
        new AlertDialog.Builder(this).setTitle("Exportar ingresos y egresos")
                .setItems(new String[]{"📅 " + Store.monthName(m), "🗓️ Todo el año " + y}, (dl, w) -> {
                    String prefix = w == 0 ? m : y, label = w == 0 ? Store.monthName(m) : "Año " + y;
                    try {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "Ingresos_Egresos_" + prefix + "_" + System.currentTimeMillis() % 100000 + ".xlsx");
                        cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Amigo Renta Reportes");
                        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                        if (u == null) throw new Exception("sin archivo");
                        try (OutputStream os = getContentResolver().openOutputStream(u)) { writeFinBook(os, prefix, label); }
                        new AlertDialog.Builder(this).setTitle("✅ Excel listo")
                                .setMessage("Se guardó en Descargas → Amigo Renta Reportes.\n\nTrae 4 hojas: Resumen (Amigo y Callao), Movimientos, Por categoría y Por casa.")
                                .setPositiveButton("Enviar / compartir", (d2, w2) -> {
                                    Intent i = new Intent(Intent.ACTION_SEND);
                                    i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                                    i.putExtra(Intent.EXTRA_STREAM, u);
                                    i.putExtra(Intent.EXTRA_SUBJECT, "Ingresos y egresos · " + label);
                                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                    launch(Intent.createChooser(i, "Enviar Excel"));
                                })
                                .setNegativeButton("Listo", null).show();
                    } catch (Exception e) { toast("No se pudo guardar el Excel"); }
                }).show();
    }

    void writeFinBook(OutputStream os, String prefix, String label) throws Exception {
        JSONObject map = ownerMap();
        List<JSONObject> all = finLines(prefix);
        Collections.reverse(all);
        String[] groups = {"Amigo", "Callao", OTHERS, UNASSIGNED};
        java.util.LinkedHashMap<String, double[]> byOwner = new java.util.LinkedHashMap<>();
        for (String g : groups) byOwner.put(g, new double[2]);
        java.util.TreeMap<String, double[]> byCat = new java.util.TreeMap<>(String.CASE_INSENSITIVE_ORDER); // [Amigo, Callao, Sin asignar]
        java.util.TreeMap<String, double[]> byHouse = new java.util.TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        List<List<Object>> mv = new ArrayList<>();
        mv.add(row("Fecha", "Tipo", "Categoría", "Casa", "De", "En qué (Otros)", "Detalle", "Forma de pago", "Ingreso", "Egreso", "Foto"));
        java.util.TreeMap<String, Double> byFor = new java.util.TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        double ti = 0, tg = 0;
        for (JSONObject x : all) {
            String o = lineOwner(x, map);
            boolean in = isIn(x);
            double a = x.optDouble("amount", 0);
            byOwner.get(o)[in ? 0 : 1] += a;
            String ck = (in ? "1|" : "0|") + x.optString("cat");
            if (!byCat.containsKey(ck)) byCat.put(ck, new double[4]);
            byCat.get(ck)[o.equals("Amigo") ? 0 : o.equals("Callao") ? 1 : o.equals(OTHERS) ? 2 : 3] += a;
            String h = x.optString("prop").trim();
            if (!byHouse.containsKey(h)) byHouse.put(h, new double[2]);
            byHouse.get(h)[in ? 0 : 1] += a;
            if (in) ti += a; else tg += a;
            if (!in && o.equals(OTHERS)) { String k = x.optString("otherFor").trim().isEmpty() ? "Sin especificar" : x.optString("otherFor").trim(); byFor.put(k, (byFor.containsKey(k) ? byFor.get(k) : 0) + a); }
            mv.add(row(x.optString("date"), in ? "Ingreso" : "Egreso", x.optString("cat"), h.isEmpty() ? "General" : h,
                    o.equals(UNASSIGNED) ? "Sin asignar" : o, x.optString("otherFor"), x.optString("desc"), x.optString("method"),
                    in ? (Object) r2(a) : "", in ? "" : (Object) r2(a), x.optString("img").isEmpty() ? "No" : "Sí"));
        }
        mv.add(row("TOTAL", "", "", "", "", "", "", r2(ti), r2(tg), ""));

        List<List<Object>> res = new ArrayList<>();
        res.add(row("Ingresos y egresos · " + label, "Ingresos", "Egresos", "Balance"));
        for (java.util.Map.Entry<String, double[]> e : byOwner.entrySet()) {
            double[] v = e.getValue();
            if ((e.getKey().equals(UNASSIGNED) || e.getKey().equals(OTHERS)) && v[0] == 0 && v[1] == 0) continue;
            res.add(row(e.getKey().equals(UNASSIGNED) ? "Sin asignar" : e.getKey(), r2(v[0]), r2(v[1]), r2(v[0] - v[1])));
        }
        res.add(row("TOTAL", r2(ti), r2(tg), r2(ti - tg)));
        if (!byFor.isEmpty()) {
            res.add(row(""));
            res.add(row("Egresos de Otros: en qué", "", "Egresos"));
            for (java.util.Map.Entry<String, Double> e : byFor.entrySet()) res.add(row("   " + e.getKey(), "", r2(e.getValue())));
        }
        res.add(row(""));
        res.add(row("Generado", Store.dateTime(System.currentTimeMillis())));
        res.add(row("Nota", "Las rentas se cuentan por la fecha en que se recibió el pago."));

        List<List<Object>> cat = new ArrayList<>();
        cat.add(row("Categoría", "Tipo", "Amigo", "Callao", "Otros", "Sin asignar", "Total"));
        for (int pass = 0; pass < 2; pass++)
            for (java.util.Map.Entry<String, double[]> e : byCat.entrySet()) {
                boolean in = e.getKey().startsWith("1|");
                if (in != (pass == 0)) continue;
                double[] v = e.getValue();
                cat.add(row(e.getKey().substring(2), in ? "Ingreso" : "Egreso", r2(v[0]), r2(v[1]), r2(v[2]), r2(v[3]), r2(v[0] + v[1] + v[2] + v[3])));
            }

        List<List<Object>> hs = new ArrayList<>();
        hs.add(row("Casa", "De", "Ingresos", "Egresos", "Balance"));
        for (java.util.Map.Entry<String, double[]> e : byHouse.entrySet()) {
            double[] v = e.getValue();
            String ow = e.getKey().isEmpty() ? "Varios" : houseOwner(map, e.getKey());
            hs.add(row(e.getKey().isEmpty() ? "General (sin casa)" : e.getKey(), ow.isEmpty() ? "Sin asignar" : ow, r2(v[0]), r2(v[1]), r2(v[0] - v[1])));
        }

        List<String> names = new ArrayList<>();
        List<List<List<Object>>> sheets = new ArrayList<>();
        List<int[]> widths = new ArrayList<>();
        names.add("Resumen"); sheets.add(res); widths.add(new int[]{34, 14, 14, 14});
        names.add("Movimientos"); sheets.add(mv); widths.add(new int[]{12, 10, 28, 26, 12, 20, 34, 14, 12, 12, 7});
        names.add("Por categoría"); sheets.add(cat); widths.add(new int[]{30, 10, 13, 13, 13, 13, 13});
        names.add("Por casa"); sheets.add(hs); widths.add(new int[]{30, 12, 13, 13, 13});
        writeBook(os, names, sheets, widths);
    }

    // ============================ propiedades y cuartos ============================
    static String room(JSONObject t) {
        String u = t.optString("unit").trim(), lv = t.optString("level").trim(), ty = t.optString("unitType").trim();
        if (!lv.isEmpty() || !ty.isEmpty()) return join(" · ", lv, u.isEmpty() ? ty : (ty.isEmpty() ? "Cuarto" : ty) + " " + u);
        if (u.isEmpty()) return "";
        return u.toLowerCase(Locale.US).startsWith("cuarto") || u.toLowerCase(Locale.US).startsWith("room") ? u : "Cuarto " + u;
    }

    static String where(JSONObject t) { return join(" · ", t.optString("property"), room(t)); }

    List<String> properties() {
        List<String> r = new ArrayList<>();
        List<String> seen = new ArrayList<>();
        for (JSONObject t : tenants) {
            String pr = t.optString("property").trim();
            if (pr.isEmpty() || seen.contains(Store.norm(pr))) continue;
            seen.add(Store.norm(pr));
            r.add(pr);
        }
        Collections.sort(r, String::compareToIgnoreCase);
        return r;
    }

    JSONObject roomTaken(String prop, String unit, int exceptId) { return roomTaken(prop, unit, exceptId, null); }

    JSONObject roomTaken(String prop, String unit, int exceptId, String lvl) {
        String np = Store.norm(prop), nu = Store.norm(unit).replace("CUARTO ", "").replace("ROOM ", "");
        if (np.isEmpty() || nu.isEmpty()) return null;
        for (JSONObject t : tenants) {
            if (t.optInt("id") == exceptId || t.optBoolean("inactive")) continue;
            String tu = Store.norm(t.optString("unit")).replace("CUARTO ", "").replace("ROOM ", "");
            if (Store.norm(t.optString("property")).equals(np) && tu.equals(nu) && (lvl == null || Store.norm(t.optString("level")).equals(Store.norm(lvl)))) return t;
        }
        return null;
    }

    // ============================ utilidades ============================
    static String qty(double q) {
        if (Math.abs(q - Math.round(q)) < 0.0001) return String.valueOf(Math.round(q));
        return String.format(Locale.US, "%.2f", q);
    }

    static double num(String s) {
        try { return Double.parseDouble(s.trim().replace("$", "").replace(",", "")); } catch (Exception e) { return 0; }
    }

    View kv(String k, String v) { return kv(k, v, TXT); }

    View kv(String k, String v, int color) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(4), 0, dp(4));
        r.addView(tv(k, 14, MUT, false), new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(tv(v, 15, color, true));
        return r;
    }

    View dateField(long[] date) { return dateField(date, "Fecha"); }

    View dateField(long[] date, String title) {
        final TextView f = field("📅  " + Store.shortDate(Store.dayOf(date[0])));
        f.setOnClickListener(v -> pickDate(Store.dayOf(date[0]), iso -> {
            long base = Store.millisAt(iso, 12);
            if (base > 0) date[0] = base;
            f.setText("📅  " + Store.shortDate(iso));
        }));
        return labeled(title, f);
    }

    void pickDate(String iso, Cb cb) {
        Calendar c = Store.cal();
        try { c.setTime(Store.f("yyyy-MM-dd").parse(iso)); } catch (Exception e) { }
        new DatePickerDialog(this, (dpk, y, m, d) -> cb.on(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)),
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    static String join(String sep, String... parts) {
        StringBuilder b = new StringBuilder();
        for (String p : parts) {
            if (p == null || p.trim().isEmpty()) continue;
            if (b.length() > 0) b.append(sep);
            b.append(p.trim());
        }
        return b.toString();
    }

    LinearLayout.LayoutParams weightLp(float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, w);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    void launch(Intent i) {
        try { startActivity(i); } catch (Exception e) { toast("No hay una app para abrir esto"); }
    }

    void afterRestore() {
        Store.scheduleAllPromises(this);
        recreate();
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ============================ Componentes visuales ============================
    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    GradientDrawable roundStroke(int color, float r, int stroke) {
        GradientDrawable g = round(color, r);
        g.setStroke(dp(1), stroke);
        return g;
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    LinearLayout card() {
        LinearLayout c = vbox();
        c.setBackground(round(Color.WHITE, 16));
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(6), dp(14), dp(6));
        c.setLayoutParams(lp);
        return c;
    }

    ScrollView scroll(LinearLayout inner) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        inner.setPadding(0, dp(6), 0, dp(100));
        s.addView(inner, new FrameLayout.LayoutParams(-1, -2));
        return s;
    }

    HorizontalScrollView hscroll(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }

    View sectionTitle(String t, String link, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(dp(18), dp(16), dp(18), dp(6));
        r.addView(tv(t, 17, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        if (link != null) {
            TextView k = tv(link, 14, PRI2, true);
            k.setOnClickListener(l);
            r.addView(k);
        }
        return r;
    }

    View empty(String s) {
        TextView t = tv(s, 14, MUT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundStroke(Color.WHITE, 14, BRD));
        t.setPadding(dp(14), dp(20), dp(14), dp(20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(4), dp(14), dp(4));
        t.setLayoutParams(lp);
        return t;
    }

    View divider() {
        View d = new View(this);
        d.setBackgroundColor(BRD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(10), 0, dp(10));
        d.setLayoutParams(lp);
        return d;
    }

    View gap(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    TextView chip(String text, boolean sel, View.OnClickListener l) {
        TextView t = tv(text, 14, TXT, true);
        t.setPadding(dp(16), dp(9), dp(16), dp(9));
        styleChip(t, sel);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    void styleChip(TextView t, boolean sel) {
        t.setBackground(sel ? round(PRI2, 20) : roundStroke(Color.WHITE, 20, BRD));
        t.setTextColor(sel ? Color.WHITE : TXT);
    }

    TextView avatar(String n, int color, int size) {
        String ini = n == null || n.trim().isEmpty() ? "?" : n.trim().substring(0, 1).toUpperCase(Store.ES);
        TextView t = tv(ini, size / 2.4f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return t;
    }

    View action(String ic, String label, int fg, int bg, View.OnClickListener l) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(bg, 14));
        b.setPadding(dp(2), dp(12), dp(2), dp(10));
        TextView i = tv(ic, 20, fg, false);
        i.setGravity(Gravity.CENTER);
        TextView t = tv(label, 10, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(1);
        t.setEllipsize(TextUtils.TruncateAt.END);
        b.addView(i);
        b.addView(t);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    TextView button(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 16, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(color, 14));
        b.setPadding(dp(14), dp(15), dp(14), dp(15));
        b.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(16), dp(14), dp(6));
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    TextView outline(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 15, color, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundStroke(Color.WHITE, 14, color));
        b.setPadding(dp(10), dp(13), dp(10), dp(13));
        b.setOnClickListener(l);
        return b;
    }

    LinearLayout.LayoutParams fieldLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, 0);
        return lp;
    }

    EditText input(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFFA0A8B5);
        e.setTextColor(TXT);
        e.setTextSize(15);
        e.setInputType(type);
        if ((type & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) {
            e.setMinLines(2);
            e.setGravity(Gravity.TOP | Gravity.START);
        }
        e.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        e.setPadding(dp(12), dp(11), dp(12), dp(11));
        e.setLayoutParams(fieldLp());
        return e;
    }

    TextView field(String text) {
        TextView t = tv(text, 15, TXT, false);
        t.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        t.setPadding(dp(12), dp(12), dp(12), dp(12));
        t.setLayoutParams(fieldLp());
        return t;
    }

    TextView picker(String[] opts, String cur) {
        String val = (cur == null || cur.isEmpty()) ? (opts.length > 0 ? opts[0] : "") : cur;
        final TextView t = field(val + "  ▾");
        t.setTag(val);
        t.setOnClickListener(v -> new AlertDialog.Builder(this).setItems(opts, (dlg, w) -> {
            t.setTag(opts[w]);
            t.setText(opts[w] + "  ▾");
        }).show());
        return t;
    }

    View label(String icon, String text, boolean req) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(14), 0, 0);
        r.addView(tv(icon + "  " + text, 13, MUT, true));
        if (req) r.addView(tv(" *", 13, RED, true));
        return r;
    }

    View labeled(String text, View v) {
        LinearLayout b = vbox();
        TextView l = tv(text, 13, MUT, true);
        l.setPadding(0, dp(14), 0, 0);
        b.addView(l);
        b.addView(v);
        return b;
    }

    View twoCols(View a, View b) {
        LinearLayout r = hbox();
        r.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1f);
        l1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1f);
        l2.setMargins(dp(6), 0, 0, 0);
        r.addView(a, l1);
        r.addView(b, l2);
        return r;
    }

}
