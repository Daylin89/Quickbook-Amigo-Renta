package com.amigorenta.rentas;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Store {
    static final Locale ES = new Locale("es");
    static final TimeZone TZ = TimeZone.getTimeZone("America/Vancouver");

    // ---------- almacenamiento ----------
    static SharedPreferences sp(Context c) { return c.getSharedPreferences("rentas", Context.MODE_PRIVATE); }

    static synchronized List<JSONObject> list(Context c, String k) {
        ArrayList<JSONObject> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString(k, "[]"));
            for (int i = 0; i < a.length(); i++) r.add(a.getJSONObject(i));
        } catch (Exception e) { }
        return r;
    }

    static synchronized void save(Context c, String k, List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (JSONObject o : l) a.put(o);
        sp(c).edit().putString(k, a.toString()).commit();
    }

    static synchronized int nextId(Context c) {
        int n = sp(c).getInt("nextId", 1);
        sp(c).edit().putInt("nextId", n + 1).commit();
        return n;
    }

    static String get(Context c, String k, String d) { return sp(c).getString(k, d); }
    static void putS(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }
    static boolean getB(Context c, String k, boolean d) { return sp(c).getBoolean(k, d); }
    static void putB(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }
    static int getI(Context c, String k, int d) { return sp(c).getInt(k, d); }
    static void putI(Context c, String k, int v) { sp(c).edit().putInt(k, v).apply(); }

    static void put(JSONObject o, String k, Object v) { try { o.put(k, v); } catch (Exception e) { } }

    // ---------- fechas ----------
    static SimpleDateFormat f(String p) { SimpleDateFormat s = new SimpleDateFormat(p, Locale.US); s.setTimeZone(TZ); return s; }
    static SimpleDateFormat fe(String p) { SimpleDateFormat s = new SimpleDateFormat(p, ES); s.setTimeZone(TZ); return s; }
    static Calendar cal() { return Calendar.getInstance(TZ); }
    static String today() { return f("yyyy-MM-dd").format(new Date()); }
    static String month(long ms) { return f("yyyy-MM").format(new Date(ms)); }
    static String thisMonth() { return month(System.currentTimeMillis()); }
    static String cap(String s) { return s.isEmpty() ? s : s.substring(0, 1).toUpperCase(ES) + s.substring(1); }

    static String addMonth(String m, int n) {
        try {
            Calendar c = cal();
            c.setTime(f("yyyy-MM").parse(m));
            c.add(Calendar.MONTH, n);
            return f("yyyy-MM").format(c.getTime());
        } catch (Exception e) { return m; }
    }

    static String monthName(String m) {
        try { return cap(fe("MMMM yyyy").format(f("yyyy-MM").parse(m))); } catch (Exception e) { return m; }
    }

    static String shortDate(String iso) {
        try { return fe("d MMM").format(f("yyyy-MM-dd").parse(iso)); } catch (Exception e) { return iso; }
    }

    static String excelDate(long ms) { return ms <= 0 ? "" : f("yyyy-MM-dd HH:mm").format(new Date(ms)); }
    static String dayOf(long ms) { return f("yyyy-MM-dd").format(new Date(ms)); }

    static String dateTime(long ms) {
        return cap(fe("EEE d MMM").format(new Date(ms))) + ", " + f("h:mm a").format(new Date(ms));
    }

    static String dueDate(JSONObject t, String m, Context c) {
        try {
            Calendar k = cal();
            k.setTime(f("yyyy-MM").parse(m));
            int d = t.optInt("dueDay", getI(c, "dueDay", 1));
            k.set(Calendar.DAY_OF_MONTH, Math.min(Math.max(d, 1), k.getActualMaximum(Calendar.DAY_OF_MONTH)));
            return f("yyyy-MM-dd").format(k.getTime());
        } catch (Exception e) { return m + "-01"; }
    }

    static int daysBetween(String a, String b) {
        try { return (int) Math.round((f("yyyy-MM-dd").parse(b).getTime() - f("yyyy-MM-dd").parse(a).getTime()) / 86400000.0); }
        catch (Exception e) { return 0; }
    }

    static long millisAt(String iso, int hour) {
        try { return f("yyyy-MM-dd").parse(iso).getTime() + hour * 3600000L; } catch (Exception e) { return 0; }
    }

    // ---------- dinero ----------
    static String money(Context c, double v) {
        String s = String.format(Locale.US, "%,.2f", Math.abs(v));
        if (s.endsWith(".00")) s = s.substring(0, s.length() - 3);
        return (v < -0.004 ? "-" : "") + get(c, "cur", "$") + s;
    }

    // ---------- inquilinos y meses ----------
    static boolean activeIn(JSONObject t, String m) {
        String since = t.optString("since", "");
        String until = t.optString("until", "");
        if (!since.isEmpty() && m.compareTo(since) < 0) return false;
        if (!until.isEmpty() && m.compareTo(until) > 0) return false;
        return true;
    }

    static JSONObject rec(List<JSONObject> recs, int tid, String m, boolean create) {
        for (JSONObject r : recs) if (r.optInt("tid") == tid && r.optString("month").equals(m)) return r;
        if (!create) return null;
        JSONObject r = new JSONObject();
        put(r, "tid", tid);
        put(r, "month", m);
        put(r, "payments", new JSONArray());
        recs.add(r);
        return r;
    }

    static double rentDue(JSONObject t, JSONObject r) {
        if (r != null && r.has("due")) return r.optDouble("due", 0);
        return t.optDouble("rent", 0);
    }

    static double utilDue(JSONObject t, JSONObject r) {
        if (r != null && r.has("util")) return r.optDouble("util", 0);
        return t.optDouble("utilities", 0);
    }

    /** Total del mes = renta + utilidades. */
    static double due(JSONObject t, JSONObject r) { return rentDue(t, r) + utilDue(t, r); }

    static double monthly(JSONObject t) { return t.optDouble("rent", 0) + t.optDouble("utilities", 0); }

    static double paid(JSONObject r) {
        if (r == null) return 0;
        JSONArray p = r.optJSONArray("payments");
        double s = 0;
        if (p != null) for (int i = 0; i < p.length(); i++) { JSONObject x = p.optJSONObject(i); if (x != null) s += x.optDouble("amount", 0); }
        return s;
    }

    static JSONObject tenant(List<JSONObject> ts, int id) {
        for (JSONObject t : ts) if (t.optInt("id") == id) return t;
        return null;
    }

    // ---------- QuickBooks (preparación) ----------
    static boolean qbo(Context c) { return getB(c, "qboMode", false); }

    /** Marca un pago nuevo: id único (servirá como requestid) y estado de sincronización. */
    static void stamp(Context c, JSONObject p) {
        if (!p.has("uuid")) put(p, "uuid", java.util.UUID.randomUUID().toString());
        put(p, "syncStatus", qbo(c) ? "pendiente" : "local");
    }

    /** Los pagos que ya existían nunca se envían a QuickBooks. */
    static void markHistory(Context c) {
        List<JSONObject> recs = list(c, "recs");
        boolean ch = false;
        for (JSONObject r : recs) {
            JSONArray a = r.optJSONArray("payments");
            if (a == null) continue;
            for (int i = 0; i < a.length(); i++) {
                JSONObject x = a.optJSONObject(i);
                if (x == null) continue;
                String s = x.optString("syncStatus");
                if (s.isEmpty() || s.equals("local")) { put(x, "syncStatus", "historico"); ch = true; }
            }
        }
        if (ch) save(c, "recs", recs);
    }

    static String syncLabel(String s) {
        switch (s) {
            case "pendiente": return "⏳ Pendiente de enviar a QuickBooks";
            case "enviando": return "🔄 Enviando a QuickBooks…";
            case "sincronizado": return "🟢 Registrado en QuickBooks";
            case "error": return "⚠️ Error al enviar a QuickBooks";
            default: return "";
        }
    }

    /** Mes al que pertenece una factura según su fecha (desde el día de corte = mes siguiente). */
    static String invoiceMonth(Context c, String isoDate) {
        if (isoDate == null || isoDate.length() < 10) return "";
        int day = 1;
        try { day = Integer.parseInt(isoDate.substring(8, 10)); } catch (Exception e) { }
        String m = isoDate.substring(0, 7);
        return day >= getI(c, "qbCutoff", 20) ? addMonth(m, 1) : m;
    }

    // ---------- idioma de los mensajes al inquilino ----------
    static boolean en(Context c) { return get(c, "tLang", "en").equals("en"); }
    static String monthNameEn(String m) {
        try { return new SimpleDateFormat("MMMM yyyy", Locale.US).format(f("yyyy-MM").parse(m)); } catch (Exception e) { return m; }
    }
    static String monthT(Context c, String m) { return en(c) ? monthNameEn(m) : monthName(m).toLowerCase(ES); }
    static String shortDateT(Context c, String iso) {
        if (!en(c)) return shortDate(iso);
        try { return new SimpleDateFormat("MMM d", Locale.US).format(f("yyyy-MM-dd").parse(iso)); } catch (Exception e) { return iso; }
    }
    static String dateTimeT(Context c, long ms) {
        if (!en(c)) return dateTime(ms);
        SimpleDateFormat a = new SimpleDateFormat("EEE, MMM d, yyyy · h:mm a", Locale.US);
        a.setTimeZone(TZ);
        return a.format(new Date(ms));
    }

    // ---------- WhatsApp ----------
    static boolean installed(Context c, String pkg) {
        try { c.getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Exception e) { return false; }
    }

    static Intent waIntent(Context c, String phone, String text) {
        String d = phone == null ? "" : phone.replaceAll("[^0-9]", "");
        if (d.length() == 10) d = "1" + d;
        String url = "https://wa.me/" + d + (text == null || text.isEmpty() ? "" : "?text=" + Uri.encode(text));
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        String pkg = get(c, "waApp", "business").equals("business") ? "com.whatsapp.w4b" : "com.whatsapp";
        if (installed(c, pkg)) i.setPackage(pkg);
        return i;
    }

    static String reminderText(Context c, JSONObject t, String m, double owed) {
        String due = dueDate(t, m, c);
        boolean late = today().compareTo(due) > 0;
        String et = get(c, "etEmail", "");
        String first = t.optString("name").trim().split("\\s+")[0];
        boolean util = t.optDouble("utilities", 0) > 0;
        if (en(c))
            return "Hi " + first + ", this is Amigo Renta. This is a friendly reminder that your rent" + (util ? " and utilities" : "") + " payment for "
                    + monthNameEn(m) + " of " + money(c, owed) + (late ? " was due on " : " is due on ") + shortDateT(c, due) + "."
                    + (et.isEmpty() ? "" : " You can pay by e-Transfer to " + et + ".")
                    + " If you have already paid, please disregard this message. Thank you!";
        return "Hola " + first + ", te escribimos de Amigo Renta. Te recordamos que el pago de renta" + (util ? " y utilidades" : "") + " de "
                + monthName(m).toLowerCase(ES) + " por " + money(c, owed) + (late ? " venció el " : " vence el ") + shortDate(due) + "."
                + (et.isEmpty() ? "" : " Puedes pagar por e-Transfer a " + et + ".")
                + " Si ya pagaste, por favor ignora este mensaje. ¡Gracias!";
    }

    // ---------- lectura de e-Transfers ----------
    static String norm(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.toUpperCase(Locale.US).replaceAll("[^A-Z0-9 ]", " ").replaceAll("\\s+", " ").trim();
    }

    static final Pattern AMT = Pattern.compile("\\$\\s?([0-9]{1,3}(?:,[0-9]{3})+(?:\\.[0-9]{1,2})?|[0-9]+(?:\\.[0-9]{1,2})?)");
    static final String[] NAME_PATS = {
            "e-?transfer\\s*:?\\s*(.{2,60}?)\\s+(?:has\\s+)?sent you",
            "transfer from\\s+(.{2,60}?)\\s+(?:has been|was)\\s",
            "money from\\s+(.{2,60}?)\\s+(?:has been|was)\\s",
            "virement\\s+interac\\s*:?\\s*(.{2,60}?)\\s+vous a envoy",
            "hi\\s+[^,]{1,60},\\s*(.{2,60}?)\\s+(?:has\\s+)?sent you",
            "(?:^|[\\n.])\\s*([A-Za-zÀ-ÿ'\\- ]{2,60}?)\\s+(?:has\\s+)?sent you"
    };

    static JSONObject parse(String text) {
        if (text == null) return null;
        String t = text.replace('\n', ' ').replaceAll("\\s+", " ");
        String low = t.toLowerCase(Locale.US);
        if (!(low.contains("transfer") || low.contains("virement"))) return null;
        if (low.contains("you sent") || low.contains("transfer to ") && !low.contains("sent you")) return null;
        String name = null;
        for (String pat : NAME_PATS) {
            Matcher m = Pattern.compile(pat, Pattern.CASE_INSENSITIVE).matcher(t);
            if (m.find()) {
                String n = m.group(1).replaceAll("(?i)^(interac|e-?transfer|:)\\s*", "").trim();
                if (n.length() >= 2 && n.length() <= 60 && !n.toLowerCase(Locale.US).contains("transfer")) { name = n; break; }
            }
        }
        double amount = 0;
        Matcher am = AMT.matcher(t);
        if (am.find()) { try { amount = Double.parseDouble(am.group(1).replace(",", "")); } catch (Exception e) { } }
        if (name == null && amount <= 0) return null;
        JSONObject o = new JSONObject();
        put(o, "name", name == null ? "" : name);
        put(o, "amount", amount);
        return o;
    }

    static JSONObject match(List<JSONObject> ts, String name, double amount) {
        String n = norm(name);
        if (n.isEmpty()) return null;
        List<String> nt = new ArrayList<>();
        for (String w : n.split(" ")) if (w.length() > 1) nt.add(w);
        JSONObject best = null;
        int bestScore = 0;
        double bestDiff = Double.MAX_VALUE;
        for (JSONObject t : ts) {
            if (t.optBoolean("inactive")) continue;
            List<String> cands = new ArrayList<>();
            cands.add(t.optString("name"));
            for (String a : t.optString("aliases").split(",")) if (!a.trim().isEmpty()) cands.add(a);
            int score = 0;
            for (String cnd : cands) {
                String cn = norm(cnd);
                if (cn.isEmpty()) continue;
                if (cn.equals(n)) { score = Math.max(score, 3); continue; }
                int hits = 0, total = 0;
                for (String w : cn.split(" ")) { if (w.length() <= 1) continue; total++; if (nt.contains(w)) hits++; }
                if (total > 0 && hits >= 2) score = Math.max(score, 2);
                else if (total == 1 && hits == 1 && nt.size() == 1) score = Math.max(score, 2);
            }
            if (score == 0) continue;
            double diff = amount > 0 ? Math.abs(monthly(t) - amount) : 0;
            if (score > bestScore || (score == bestScore && diff < bestDiff)) { best = t; bestScore = score; bestDiff = diff; }
        }
        return bestScore >= 2 ? best : null;
    }

    /** Aplica un pago detectado a un inquilino. Devuelve el mes al que se aplicó. */
    static String apply(Context c, JSONObject det, JSONObject t, List<JSONObject> recs) {
        long at = det.optLong("at");
        String m = month(at);
        if (!activeIn(t, m)) m = activeIn(t, addMonth(m, 1)) ? addMonth(m, 1) : m;
        JSONObject r = rec(recs, t.optInt("id"), m, true);
        if (due(t, r) - paid(r) <= 0.009) {
            String nm = addMonth(m, 1);
            JSONObject r2 = rec(recs, t.optInt("id"), nm, false);
            if (r2 == null || due(t, r2) - paid(r2) > 0.009) { m = nm; r = rec(recs, t.optInt("id"), nm, true); }
        }
        double amt = det.optDouble("amount", 0);
        if (amt <= 0) amt = Math.max(0, due(t, r) - paid(r));
        JSONObject p = new JSONObject();
        put(p, "id", nextId(c));
        put(p, "amount", amt);
        put(p, "date", at);
        put(p, "method", "e-Transfer");
        put(p, "source", "auto");
        put(p, "detId", det.optInt("id"));
        put(p, "ref", det.optString("name"));
        stamp(c, p);
        r.optJSONArray("payments").put(p);
        put(det, "tid", t.optInt("id"));
        put(det, "month", m);
        put(det, "status", "aplicado");
        if (due(t, r) - paid(r) <= 0.009) cancelPromise(c, t.optInt("id"));
        return m;
    }

    static synchronized JSONObject handleIncoming(Context c, String text, long when, String source) {
        JSONObject p = parse(text);
        if (p == null) return null;
        List<JSONObject> det = list(c, "detected");
        String nn = norm(p.optString("name"));
        for (int i = det.size() - 1; i >= 0 && i >= det.size() - 40; i--) {
            JSONObject d = det.get(i);
            if (norm(d.optString("name")).equals(nn) && Math.abs(d.optDouble("amount", 0) - p.optDouble("amount", 0)) < 0.01
                    && Math.abs(d.optLong("at") - when) < 12 * 3600000L) return d;
        }
        JSONObject d = new JSONObject();
        put(d, "id", nextId(c));
        put(d, "at", when);
        put(d, "name", p.optString("name"));
        put(d, "amount", p.optDouble("amount", 0));
        put(d, "raw", text.length() > 600 ? text.substring(0, 600) : text);
        put(d, "source", source);
        put(d, "status", "pendiente");
        List<JSONObject> ts = list(c, "tenants");
        JSONObject t = match(ts, p.optString("name"), p.optDouble("amount", 0));
        String title, body;
        String amtS = p.optDouble("amount", 0) > 0 ? money(c, p.optDouble("amount", 0)) : "(monto no visible)";
        if (t != null && getB(c, "autoApply", true)) {
            List<JSONObject> recs = list(c, "recs");
            String m = apply(c, d, t, recs);
            save(c, "recs", recs);
            title = "💸 Pago recibido: " + t.optString("name");
            body = amtS + " por e-Transfer · aplicado a " + monthName(m);
        } else {
            if (t != null) put(d, "tid", t.optInt("id"));
            title = "💸 e-Transfer de " + (p.optString("name").isEmpty() ? "alguien" : p.optString("name"));
            body = amtS + " · toca para " + (t != null ? "confirmarlo (" + t.optString("name") + ")" : "asignarlo a un inquilino");
        }
        det.add(d);
        while (det.size() > 3000) det.remove(0);
        save(c, "detected", det);
        if (!"manual".equals(source)) notifyNow(c, 50000 + (d.optInt("id") % 10000), title, body);
        return d;
    }

    static void notifyNow(Context c, int code, String title, String text) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("rentas", "Rentas Amigo Renta", NotificationManager.IMPORTANCE_HIGH));
            Intent oi = new Intent(c, MainActivity.class);
            oi.putExtra("tab", 2);
            oi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent open = PendingIntent.getActivity(c, 2, oi, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(c, "rentas")
                    .setSmallIcon(android.R.drawable.stat_notify_more)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setContentIntent(open)
                    .setAutoCancel(true)
                    .build();
            nm.notify(code, n);
        } catch (Exception e) { }
    }

    // ---------- recordatorios de fecha prometida ----------
    static void schedulePromise(Context c, JSONObject t, JSONObject r) {
        cancelPromise(c, t.optInt("id"));
        String pr = r == null ? "" : r.optString("promise");
        if (pr.isEmpty()) return;
        double owed = due(t, r) - paid(r);
        if (owed <= 0.009) return;
        long when = millisAt(pr, 9);
        if (when <= System.currentTimeMillis()) return;
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("title", "🤝 Hoy prometió pagar: " + t.optString("name"));
        i.putExtra("text", money(c, owed) + " de " + monthName(r.optString("month")) + " · " + t.optString("property") + " " + t.optString("unit"));
        i.putExtra("code", 10000 + t.optInt("id"));
        if (!t.optString("phone").isEmpty()) {
            i.putExtra("action", "Recordarle por WhatsApp");
            i.putExtra("waPhone", t.optString("phone"));
            i.putExtra("waText", reminderText(c, t, r.optString("month"), owed));
        }
        PendingIntent pi = PendingIntent.getBroadcast(c, 10000 + t.optInt("id"), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
    }

    static void cancelPromise(Context c, int tid) {
        PendingIntent pi = PendingIntent.getBroadcast(c, 10000 + tid, new Intent(c, ReminderReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) { ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pi); pi.cancel(); }
    }

    static void scheduleAllPromises(Context c) {
        List<JSONObject> ts = list(c, "tenants"), recs = list(c, "recs");
        for (JSONObject r : recs) {
            if (r.optString("promise").isEmpty()) continue;
            JSONObject t = tenant(ts, r.optInt("tid"));
            if (t != null) schedulePromise(c, t, r);
        }
    }
}
