package com.amigorenta.rentas;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class PagosListener extends NotificationListenerService {
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || getPackageName().equals(sbn.getPackageName())) return;
            Notification n = sbn.getNotification();
            if (n == null || n.extras == null) return;
            Bundle e = n.extras;
            StringBuilder b = new StringBuilder();
            for (String k : new String[]{Notification.EXTRA_TITLE, Notification.EXTRA_TEXT, Notification.EXTRA_BIG_TEXT,
                    Notification.EXTRA_SUB_TEXT, Notification.EXTRA_SUMMARY_TEXT}) {
                CharSequence cs = e.getCharSequence(k);
                if (cs != null) b.append(cs).append(" \n ");
            }
            CharSequence[] lines = e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
            if (lines != null) for (CharSequence l : lines) if (l != null) b.append(l).append(" \n ");
            String text = b.toString();
            String low = text.toLowerCase();
            if (!(low.contains("transfer") || low.contains("virement") || low.contains("interac"))) return;
            Store.handleIncoming(getApplicationContext(), text, sbn.getPostTime(), "auto");
        } catch (Exception ignored) { }
    }
}
