package com.amigorenta.rentas;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import org.json.JSONObject;
import java.io.OutputStream;

/** Recibo de pago en PDF (hecho en el teléfono). Cuando QuickBooks esté conectado se usará el PDF de QuickBooks. */
public class Recibo {
    static final int W = 612, H = 792, M = 48;
    static final int AZUL = 0xFF0D3B7A, GRIS = 0xFF6B7585, TXT = 0xFF1A2433, LINEA = 0xFFE1E7EF, VERDE = 0xFF15803D, ROJO = 0xFFB91C1C;

    static String number(JSONObject x) { return "AR-" + String.format(java.util.Locale.US, "%05d", x.optInt("id")); }

    /** Crea el PDF y lo guarda en Descargas → Amigo Renta Recibos. Devuelve su Uri o null. */
    static Uri make(Context c, JSONObject t, JSONObject r, JSONObject x) {
        if (Build.VERSION.SDK_INT < 29) return null;
        PdfDocument doc = new PdfDocument();
        PdfDocument.Page page = doc.startPage(new PdfDocument.PageInfo.Builder(W, H, 1).create());
        Canvas cv = page.getCanvas();
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final boolean en = Store.en(c);

        // encabezado
        p.setColor(AZUL);
        cv.drawRect(0, 0, W, 110, p);
        p.setColor(Color.WHITE);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        p.setTextSize(26);
        cv.drawText(Store.get(c, "coName", "Amigo Renta"), M, 52, p);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
        p.setTextSize(10.5f);
        cv.drawText(Store.get(c, "coLine", "Amigo International Services Inc. · 801 E Broadway, Vancouver, BC · +1 604-767-8650"), M, 74, p);
        cv.drawText("amigorenta.com", M, 90, p);

        int y = 150;
        p.setColor(TXT);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        p.setTextSize(20);
        cv.drawText(en ? "PAYMENT RECEIPT" : "RECIBO DE PAGO", M, y, p);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
        p.setTextSize(11);
        p.setColor(GRIS);
        if (!en) cv.drawText("Payment receipt", M, y + 16, p);
        right(cv, p, (en ? "No. " : "N.º ") + number(x), y - 4, TXT, 12, true);
        right(cv, p, (en ? "Issued: " : "Emitido: ") + Store.dateTimeT(c, System.currentTimeMillis()), y + 14, GRIS, 10, false);

        y += 48;
        String m = r.optString("month");
        String room = MainActivity.room(t);
        String where = t.optString("property") + (room.isEmpty() ? "" : " · " + room);
        y = row(cv, p, en ? "Tenant" : "Inquilino / Tenant", t.optString("name"), y);
        if (!where.trim().isEmpty()) y = row(cv, p, en ? "Property" : "Propiedad / Property", where, y);
        y = row(cv, p, en ? "Month" : "Mes / Month", en ? Store.monthNameEn(m) : Store.monthName(m), y);
        y = row(cv, p, en ? "Payment date" : "Fecha del pago / Date", Store.dateTimeT(c, x.optLong("date")), y);
        y = row(cv, p, en ? "Payment method" : "Forma de pago / Method", en ? methodEn(x.optString("method")) : x.optString("method"), y);
        if (!x.optString("ref").isEmpty()) y = row(cv, p, en ? "Reference" : "Referencia / Reference", x.optString("ref"), y);

        // monto destacado
        y += 14;
        p.setColor(0xFFEAF6EE);
        cv.drawRoundRect(new RectF(M, y, W - M, y + 70), 10, 10, p);
        p.setColor(VERDE);
        p.setTextSize(12);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        cv.drawText(en ? "AMOUNT RECEIVED" : "MONTO RECIBIDO / AMOUNT RECEIVED", M + 18, y + 26, p);
        p.setTextSize(26);
        cv.drawText(Store.money(c, x.optDouble("amount", 0)), M + 18, y + 56, p);
        y += 100;

        // resumen del mes
        double rd = Store.rentDue(t, r), ud = Store.utilDue(t, r), due = rd + ud, pd = Store.paid(r);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        p.setTextSize(13);
        p.setColor(AZUL);
        cv.drawText(en ? Store.monthNameEn(m) + " summary" : "Resumen de " + Store.monthName(m).toLowerCase(Store.ES), M, y, p);
        y += 10;
        y = line(cv, p, en ? "Rent" : "Renta / Rent", Store.money(c, rd), y, TXT, false);
        if (ud > 0.009) y = line(cv, p, en ? "Utilities" : "Utilidades / Utilities", Store.money(c, ud), y, TXT, false);
        y = line(cv, p, en ? "Total due" : "Total del mes / Total due", Store.money(c, due), y, TXT, true);
        y = line(cv, p, en ? "Total paid" : "Pagado en total / Total paid", Store.money(c, pd), y, VERDE, false);
        double bal = due - pd;
        if (bal > 0.009) y = line(cv, p, en ? "Balance due" : "Saldo pendiente / Balance due", Store.money(c, bal), y, ROJO, true);
        else if (bal < -0.009) {
            y = line(cv, p, en ? "Balance" : "Saldo / Balance", Store.money(c, 0) + (en ? " · PAID" : " · PAGADO"), y, VERDE, true);
            y = line(cv, p, en ? "Credit on account" : "Crédito a favor / Credit", Store.money(c, -bal), y, VERDE, true);
        } else y = line(cv, p, en ? "Balance" : "Saldo / Balance", Store.money(c, 0) + (en ? " · PAID" : " · PAGADO / PAID"), y, VERDE, true);

        y += 26;
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
        p.setTextSize(11);
        p.setColor(GRIS);
        if (bal < -0.009) {
            if (en) { cv.drawText("Your credit will be applied to your next invoice.", M, y, p); y += 21; }
            else {
                cv.drawText("El crédito a favor se aplicará a su próxima factura.", M, y, p);
                cv.drawText("Your credit will be applied to your next invoice.", M, y + 15, p);
                y += 36;
            }
        }
        cv.drawText(en ? "Thank you for your payment." : "Gracias por su pago. / Thank you for your payment.", M, y, p);

        p.setColor(LINEA);
        cv.drawRect(M, H - 60, W - M, H - 59, p);
        p.setColor(GRIS);
        p.setTextSize(9);
        cv.drawText((en ? "Receipt issued by Amigo Renta · " : "Recibo generado por la app Rentas Amigo Renta · ") + number(x), M, H - 42, p);

        doc.finishPage(page);
        try {
            ContentValues v = new ContentValues();
            String safe = t.optString("name").replaceAll("[^A-Za-z0-9ÁÉÍÓÚÑáéíóúñ ]", "").trim().replace(' ', '_');
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, (Store.en(c) ? "Receipt_" : "Recibo_") + number(x) + "_" + safe + ".pdf");
            v.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Amigo Renta Recibos");
            Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) return null;
            try (OutputStream os = c.getContentResolver().openOutputStream(u)) { doc.writeTo(os); }
            return u;
        } catch (Exception e) {
            return null;
        } finally { doc.close(); }
    }

    static String methodEn(String m) {
        switch (m) {
            case "Efectivo": return "Cash";
            case "Depósito": return "Bank deposit";
            case "Otro": return "Other";
            default: return m;
        }
    }

    static void right(Canvas cv, Paint p, String s, int y, int color, float size, boolean bold) {
        p.setColor(color);
        p.setTextSize(size);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, bold ? Typeface.BOLD : Typeface.NORMAL));
        cv.drawText(s, W - M - p.measureText(s), y, p);
    }

    static int row(Canvas cv, Paint p, String k, String v, int y) {
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
        p.setTextSize(10.5f);
        p.setColor(GRIS);
        cv.drawText(k, M, y, p);
        p.setColor(TXT);
        p.setTextSize(12.5f);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        String s = v;
        while (p.measureText(s) > W - M - 220 && s.length() > 4) s = s.substring(0, s.length() - 2);
        if (!s.equals(v)) s = s + "…";
        cv.drawText(s, 220, y, p);
        p.setColor(LINEA);
        cv.drawRect(M, y + 9, W - M, y + 10, p);
        return y + 28;
    }

    static int line(Canvas cv, Paint p, String k, String v, int y, int color, boolean bold) {
        y += 22;
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, bold ? Typeface.BOLD : Typeface.NORMAL));
        p.setTextSize(12);
        p.setColor(TXT);
        cv.drawText(k, M, y, p);
        right(cv, p, v, y, color, 12, bold);
        p.setColor(LINEA);
        cv.drawRect(M, y + 8, W - M, y + 9, p);
        return y;
    }
}
