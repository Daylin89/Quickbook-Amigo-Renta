package com.amigorenta.rentas;

import android.app.Activity;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/** Llamadas al servidor de Amigo Renta (Cloudflare). Corre en segundo plano y responde en la pantalla. */
public class Net {
    interface Cb { void on(int code, byte[] body, String error); }

    static String base(Activity a) {
        String u = Store.get(a, "serverUrl", "").trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        if (!u.isEmpty() && !u.startsWith("http")) u = "https://" + u;
        return u;
    }

    static boolean ready(Activity a) { return !base(a).isEmpty() && !Store.get(a, "deviceKey", "").isEmpty(); }

    static void call(Activity a, String method, String path, byte[] body, String contentType, Map<String, String> headers, Cb cb) {
        final String url = base(a) + path, key = Store.get(a, "deviceKey", "");
        new Thread(() -> {
            int code = 0;
            byte[] out = null;
            String error = null;
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestMethod(method);
                c.setConnectTimeout(20000);
                c.setReadTimeout(60000);
                c.setRequestProperty("X-Device-Key", key);
                if (headers != null) for (Map.Entry<String, String> e : headers.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
                if (body != null) {
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", contentType == null ? "application/octet-stream" : contentType);
                    c.setFixedLengthStreamingMode(body.length);
                    try (OutputStream os = c.getOutputStream()) { os.write(body); }
                }
                code = c.getResponseCode();
                InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
                out = is == null ? new byte[0] : readAll(is);
            } catch (Exception e) {
                error = "Sin conexión con el servidor (" + e.getClass().getSimpleName() + ")";
            } finally { if (c != null) c.disconnect(); }
            final int fc = code;
            final byte[] fo = out;
            final String fe = error;
            a.runOnUiThread(() -> cb.on(fc, fo, fe));
        }).start();
    }

    static byte[] readAll(InputStream is) throws java.io.IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = is.read(buf)) > 0) b.write(buf, 0, n);
        is.close();
        return b.toByteArray();
    }

    static String text(byte[] b) { return b == null ? "" : new String(b, StandardCharsets.UTF_8); }

    /** Mensaje de error legible a partir de la respuesta del servidor. */
    static String errorOf(int code, byte[] body, String error) {
        if (error != null) return error;
        try {
            org.json.JSONObject o = new org.json.JSONObject(text(body));
            if (!o.optString("error").isEmpty()) return o.optString("error");
        } catch (Exception e) { }
        if (code == 401) return "Clave del dispositivo incorrecta (revísala en Ajustes)";
        if (code == 404) return "No encontrado en el servidor (revisa la dirección en Ajustes)";
        return "El servidor respondió " + code;
    }
}
