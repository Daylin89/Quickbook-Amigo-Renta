package com.amigorenta.rentas;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Comparte inquilinos, meses y pagos con el servidor del equipo (el mismo de Clientes y Citas),
 * para que el Manager los vea y registre pagos desde la app web del iPhone.
 * Cada pago es un registro aparte (por su uuid), así dos personas pueden registrar pagos a la vez sin pisarse.
 */
public class Sync {
    static final Set<String> T_SKIP = new HashSet<>(java.util.Arrays.asList("id"));
    static final Set<String> R_SKIP = new HashSet<>(java.util.Arrays.asList("payments"));
    static final String[] PAY_F = {"amount", "date", "method", "ref", "source", "note", "by", "tid", "month", "imgId"};
    static final String[] CFG_F = {"cur", "dueDay", "company"};
    static volatile long lastRun = 0;
    static volatile boolean running = false, hold = false, deferred = false;
    static volatile Runnable onChange = null;

    static boolean on(Context c) { return TeamNet.ready(c); }

    static String norm(Object v) {
        if (v == null || v == JSONObject.NULL) return "";
        if (v instanceof Number) {
            double d = ((Number) v).doubleValue();
            if (d == 0) return "";
            return d == Math.rint(d) ? String.valueOf((long) d) : String.valueOf(d);
        }
        if (v instanceof Boolean) return ((Boolean) v) ? "true" : "";
        return v.toString();
    }

    static JSONObject snap(Context c) {
        try { return new JSONObject(Store.get(c, "syncSnap", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    static Set<String> keys(JSONObject a, JSONObject b, JSONObject d, Set<String> skip) {
        Set<String> k = new HashSet<>();
        for (JSONObject o : new JSONObject[]{a, b, d}) if (o != null) for (Iterator<String> it = o.keys(); it.hasNext(); ) k.add(it.next());
        k.removeAll(skip);
        return k;
    }

    /** Vista de un pago para comparar: sus campos + el inquilino y mes donde está. */
    static JSONObject payView(JSONObject p, JSONObject r) {
        JSONObject v = new JSONObject();
        try {
            for (String k : PAY_F) if (p.has(k)) v.put(k, p.get(k));
            v.put("tid", r.optInt("tid"));
            v.put("month", r.optString("month"));
        } catch (Exception ignored) { }
        return v;
    }

    static JSONObject cfg(Context c) {
        JSONObject o = new JSONObject();
        try {
            o.put("cur", Store.get(c, "cur", "$"));
            o.put("dueDay", Store.getI(c, "dueDay", 1));
            o.put("company", Store.get(c, "company", "Amigo Renta"));
        } catch (Exception ignored) { }
        return o;
    }

    static void auto(Context c) {
        if (hold) { deferred = true; return; }
        deferred = false;
        run(c);
    }

    static String run(Context c) {
        if (!on(c)) return "Falta configurar el servidor del equipo";
        if (running) return null;
        running = true;
        try { return doRun(c); } finally { running = false; lastRun = System.currentTimeMillis(); }
    }

    /** Diferencias de un objeto contra la foto de la última sincronización. */
    static JSONObject diff(JSONObject cur, JSONObject s, Set<String> fields, Map<String, String> base) throws Exception {
        JSONObject set = new JSONObject();
        for (String k : fields) {
            Object v = cur.opt(k);
            String now = norm(v), old = s == null ? null : s.optString(k, "");
            base.put(k, now);
            if (old == null ? !now.isEmpty() : !now.equals(old)) set.put(k, v == null ? "" : v);
        }
        return set;
    }

    static String doRun(Context c) {
        try {
            JSONObject snap = snap(c);
            List<JSONObject> tenants, recs;
            synchronized (Store.class) {
                tenants = Store.list(c, "tenants");
                recs = Store.list(c, "recs");
                boolean add = false;
                for (JSONObject r : recs) {
                    JSONArray a = r.optJSONArray("payments");
                    if (a != null) for (int i = 0; i < a.length(); i++) {
                        JSONObject p = a.optJSONObject(i);
                        if (p != null && p.optString("uuid").isEmpty()) { p.put("uuid", java.util.UUID.randomUUID().toString()); add = true; }
                    }
                }
                if (add) Store.save(c, "recs", recs);
            }
            JSONArray out = new JSONArray();
            Map<String, Map<String, String>> base = new HashMap<>();
            Set<String> live = new HashSet<>();
            // ---------- 1. lo que cambió en este teléfono ----------
            for (JSONObject t : tenants) {
                String sid = "t:" + t.optInt("id");
                live.add(sid);
                JSONObject s = snap.optJSONObject(sid);
                Map<String, String> b = new HashMap<>();
                JSONObject set = diff(t, s, keys(t, s, null, T_SKIP), b);
                base.put(sid, b);
                if (set.length() > 0) out.put(new JSONObject().put("kind", "rten").put("id", String.valueOf(t.optInt("id"))).put("set", set));
            }
            for (JSONObject r : recs) {
                String rid = r.optInt("tid") + "|" + r.optString("month"), sid = "r:" + rid;
                live.add(sid);
                JSONObject s = snap.optJSONObject(sid);
                Map<String, String> b = new HashMap<>();
                JSONObject set = diff(r, s, keys(r, s, null, R_SKIP), b);
                base.put(sid, b);
                if (set.length() > 0) out.put(new JSONObject().put("kind", "rrec").put("id", rid).put("set", set));
                JSONArray a = r.optJSONArray("payments");
                if (a != null) for (int i = 0; i < a.length(); i++) {
                    JSONObject p = a.optJSONObject(i);
                    if (p == null) continue;
                    String pid = "p:" + p.optString("uuid");
                    live.add(pid);
                    JSONObject ps = snap.optJSONObject(pid);
                    Map<String, String> pb = new HashMap<>();
                    Set<String> pf = new HashSet<>(java.util.Arrays.asList(PAY_F));
                    JSONObject pset = diff(payView(p, r), ps, pf, pb);
                    base.put(pid, pb);
                    if (pset.length() > 0) out.put(new JSONObject().put("kind", "rpay").put("id", p.optString("uuid")).put("set", pset));
                }
            }
            for (Iterator<String> it = snap.keys(); it.hasNext(); ) { // borrados en este teléfono
                String sid = it.next();
                if (sid.equals("cfg") || live.contains(sid)) continue;
                String kind = sid.startsWith("t:") ? "rten" : sid.startsWith("r:") ? "rrec" : "rpay";
                out.put(new JSONObject().put("kind", kind).put("id", sid.substring(2)).put("set", new JSONObject().put("deleted", true)));
            }
            JSONObject cfg = cfg(c), cs0 = snap.optJSONObject("cfg");
            Map<String, String> cb = new HashMap<>();
            JSONObject cset = diff(cfg, cs0, new HashSet<>(java.util.Arrays.asList(CFG_F)), cb);
            if (cset.length() > 0) out.put(new JSONObject().put("kind", "rcfg").put("id", "main").put("set", cset));
            // ---------- 2. enviar (en partes) ----------
            for (int i = 0; i < out.length(); i += 1500) {
                JSONArray part = new JSONArray();
                for (int j = i; j < Math.min(out.length(), i + 1500); j++) part.put(out.get(j));
                JSONObject body = new JSONObject().put("records", part).put("dev", "rentas");
                TeamNet.Res r = TeamNet.request(c, "POST", "/api/push", body.toString().getBytes(StandardCharsets.UTF_8), "application/json", null);
                if (r.error != null || r.code != 200) return TeamNet.errorOf(r.code, r.body, r.error);
            }
            for (Map.Entry<String, Map<String, String>> e : base.entrySet()) snap.put(e.getKey(), new JSONObject(e.getValue()));
            for (Iterator<String> it = snap.keys(); it.hasNext(); ) { String sid = it.next(); if (!sid.equals("cfg") && !live.contains(sid)) it.remove(); }
            snap.put("cfg", new JSONObject(cb));
            // ---------- 3. traer lo que cambiaron otros (Manager) ----------
            long lastPull = Store.sp(c).getLong("teamPull", 0);
            TeamNet.Res r = TeamNet.request(c, "GET", "/api/changes?kinds=rten,rrec,rpay&since=" + Math.max(0, lastPull - 120000), null, null, null);
            if (r.error != null || r.code != 200) { Store.putS(c, "syncSnap", snap.toString()); return TeamNet.errorOf(r.code, r.body, r.error); }
            JSONObject res = new JSONObject(TeamNet.text(r.body));
            JSONArray in = res.getJSONArray("records");
            boolean chg = false;
            List<String> news = new ArrayList<>();
            List<String[]> photos = new ArrayList<>(); // {uuid del pago, id de la foto}
            synchronized (Store.class) {
                List<JSONObject> lt = Store.list(c, "tenants"), lr = Store.list(c, "recs");
                for (int i = 0; i < in.length(); i++) {
                    JSONObject rec = in.getJSONObject(i);
                    String kind = rec.optString("kind"), id = rec.optString("id");
                    JSONObject data = rec.optJSONObject("data");
                    if (data == null) continue;
                    if (kind.equals("rten")) {
                        String sid = "t:" + id;
                        JSONObject t = Store.tenant(lt, parseInt(id));
                        if (data.optBoolean("deleted")) { if (t != null) { lt.remove(t); chg = true; } snap.remove(sid); continue; }
                        JSONObject s = snap.optJSONObject(sid);
                        if (t == null) { t = new JSONObject(); t.put("id", parseInt(id)); lt.add(t); s = null; }
                        if (merge(t, data, s, keys(t, s, data, T_SKIP), snap, sid)) chg = true;
                    } else if (kind.equals("rrec")) {
                        String sid = "r:" + id;
                        String[] parts = id.split("\\|");
                        if (parts.length < 2) continue;
                        JSONObject rr = Store.rec(lr, parseInt(parts[0]), parts[1], !data.optBoolean("deleted"));
                        if (data.optBoolean("deleted")) { snap.remove(sid); continue; } // un mes nunca se borra si tiene pagos
                        Set<String> ks = keys(rr, snap.optJSONObject(sid), data, R_SKIP);
                        if (merge(rr, data, snap.optJSONObject(sid), ks, snap, sid)) chg = true;
                    } else if (kind.equals("rpay")) {
                        String sid = "p:" + id;
                        JSONObject[] found = findPay(lr, id);
                        if (data.optBoolean("deleted")) {
                            if (found != null) { removePay(found[0], found[1]); chg = true; }
                            snap.remove(sid);
                            continue;
                        }
                        JSONObject s = snap.optJSONObject(sid);
                        if (found == null) {
                            int tid = data.optInt("tid");
                            String m = data.optString("month");
                            if (tid <= 0 || m.isEmpty()) continue;
                            JSONObject p = new JSONObject();
                            p.put("id", Store.nextId(c));
                            p.put("uuid", id);
                            for (String k : PAY_F) if (!k.equals("tid") && !k.equals("month") && data.has(k)) p.put(k, data.get(k));
                            Store.stamp(c, p);
                            Store.rec(lr, tid, m, true).optJSONArray("payments").put(p);
                            JSONObject ns = new JSONObject();
                            for (String k : PAY_F) ns.put(k, norm(data.opt(k)));
                            snap.put(sid, ns);
                            chg = true;
                            if (!data.optString("imgId").isEmpty()) photos.add(new String[]{id, data.optString("imgId")});
                            JSONObject t = Store.tenant(lt, tid);
                            if (!data.optString("by").isEmpty())
                                news.add(data.optString("by") + " registró " + Store.money(c, data.optDouble("amount", 0)) + " de " + (t == null ? "un inquilino" : t.optString("name")) + " · " + Store.monthName(m));
                        } else {
                            JSONObject rr = found[0], p = found[1];
                            JSONObject view = payView(p, rr);
                            JSONObject ns = new JSONObject();
                            boolean moved = false;
                            for (String k : PAY_F) {
                                Object sv = data.opt(k);
                                String cur = norm(view.opt(k)), was = s == null ? cur : s.optString(k, "");
                                if (cur.equals(was)) {
                                    if (sv != null && !norm(sv).equals(cur)) {
                                        chg = true;
                                        if (k.equals("tid") || k.equals("month")) moved = true; else p.put(k, sv);
                                    }
                                    ns.put(k, sv == null ? "" : norm(sv));
                                } else ns.put(k, was);
                            }
                            snap.put(sid, ns);
                            if (!p.optString("imgId").isEmpty() && !p.optString("imgId").equals(p.optString("imgDl"))) photos.add(new String[]{id, p.optString("imgId")});
                            if (moved) {
                                removePay(rr, p);
                                Store.rec(lr, parseInt(ns.optString("tid")), ns.optString("month"), true).optJSONArray("payments").put(p);
                            }
                        }
                    }
                }
                if (chg) { Store.save(c, "tenants", lt); Store.save(c, "recs", lr); }
                Store.putS(c, "syncSnap", snap.toString());
                Store.sp(c).edit().putLong("teamPull", res.optLong("now")).putLong("lastSyncOk", System.currentTimeMillis()).apply();
            }
            for (String[] ph : photos) fetchPhoto(c, ph[0], ph[1]);
            for (int i = 0; i < news.size(); i++) Store.notifyNow(c, 61000 + i, "💵 Pago registrado por el equipo", news.get(i));
            if (chg) { Runnable r2 = onChange; if (r2 != null) H.post(() -> { Runnable r3 = onChange; if (r3 != null) r3.run(); }); }
            return null;
        } catch (Exception e) {
            return "Error al sincronizar: " + e.getMessage();
        }
    }

    /** Baja la foto del comprobante que subió el Manager y la deja en el pago (Imágenes → Amigo Renta Comprobantes). */
    static void fetchPhoto(Context c, String uuid, String imgId) {
        try {
            if (android.os.Build.VERSION.SDK_INT < 29) return;
            TeamNet.Res r = TeamNet.request(c, "GET", "/api/file?id=" + java.net.URLEncoder.encode(imgId, "UTF-8"), null, null, null);
            if (r.error != null || r.code != 200 || r.body == null || r.body.length == 0) return;
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "comprobante_" + imgId + ".jpg");
            cv.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
            cv.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_PICTURES + "/Amigo Renta Comprobantes");
            android.net.Uri u = c.getContentResolver().insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (u == null) return;
            try (java.io.OutputStream os = c.getContentResolver().openOutputStream(u)) { os.write(r.body); }
            synchronized (Store.class) {
                List<JSONObject> lr = Store.list(c, "recs");
                JSONObject[] f = findPay(lr, uuid);
                if (f == null) return;
                f[1].put("img", u.toString());
                f[1].put("imgDl", imgId);
                Store.save(c, "recs", lr);
            }
        } catch (Exception ignored) { }
    }

    static int parseInt(String s) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; } }

    /** Aplica los campos del servidor que no cambiaron aquí desde la última vez. */
    static boolean merge(JSONObject o, JSONObject data, JSONObject s, Set<String> fields, JSONObject snap, String sid) throws Exception {
        boolean chg = false;
        JSONObject ns = new JSONObject();
        for (String k : fields) {
            Object sv = data.opt(k);
            String cur = norm(o.opt(k)), was = s == null ? cur : s.optString(k, "");
            if (cur.equals(was)) {
                if (sv != null && !norm(sv).equals(cur)) { o.put(k, sv); chg = true; }
                ns.put(k, sv == null ? cur : norm(sv));
            } else ns.put(k, was);
        }
        snap.put(sid, ns);
        return chg;
    }

    static JSONObject[] findPay(List<JSONObject> recs, String uuid) {
        for (JSONObject r : recs) {
            JSONArray a = r.optJSONArray("payments");
            if (a != null) for (int i = 0; i < a.length(); i++) {
                JSONObject p = a.optJSONObject(i);
                if (p != null && uuid.equals(p.optString("uuid"))) return new JSONObject[]{r, p};
            }
        }
        return null;
    }

    static void removePay(JSONObject r, JSONObject p) {
        JSONArray a = r.optJSONArray("payments"), n = new JSONArray();
        if (a != null) for (int i = 0; i < a.length(); i++) if (a.opt(i) != p) n.put(a.opt(i));
        Store.put(r, "payments", n);
    }

    // ---------- cuándo sincronizar ----------
    static final Handler H = new Handler(Looper.getMainLooper());
    static final Runnable[] PENDING = {null};

    static void soon(Context c, long delayMs) {
        if (!on(c)) return;
        final Context app = c.getApplicationContext();
        if (PENDING[0] != null) H.removeCallbacks(PENDING[0]);
        PENDING[0] = () -> new Thread(() -> auto(app)).start();
        H.postDelayed(PENDING[0], delayMs);
    }

    static void schedule(Context c) {
        PendingIntent pi = PendingIntent.getBroadcast(c, 31, new Intent(c, Rx.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE))
                .setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + AlarmManager.INTERVAL_FIFTEEN_MINUTES, AlarmManager.INTERVAL_FIFTEEN_MINUTES, pi);
    }

    public static class Rx extends BroadcastReceiver {
        @Override
        public void onReceive(Context c, Intent i) {
            if (!on(c)) return;
            final PendingResult pr = goAsync();
            new Thread(() -> { try { auto(c); } finally { pr.finish(); } }).start();
        }
    }
}
