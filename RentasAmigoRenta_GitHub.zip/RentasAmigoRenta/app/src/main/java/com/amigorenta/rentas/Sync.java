package com.amigorenta.rentas;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Comparte inquilinos, meses y pagos con el servidor del equipo (el mismo de Clientes y Citas),
 * para que el Manager los vea y registre pagos desde la app web del iPhone.
 * Cada pago es un registro aparte (por su uuid), así dos personas pueden registrar pagos a la vez sin pisarse.
 */
public class Sync {
    static final Set<String> T_SKIP = new HashSet<>(java.util.Arrays.asList("id"));
    static final Set<String> R_SKIP = new HashSet<>(java.util.Arrays.asList("payments"));
    static final String[] PAY_F = {"amount", "date", "method", "ref", "source", "note", "by", "tid", "month", "imgId"};
    static final String[] CFG_F = {"cur", "dueDay", "company"};
    /** Ingresos y egresos (solo se envían; el Manager los ve en el iPhone). */
    static final String[] MOV_F = {"type", "date", "amount", "cat", "prop", "owner", "method", "desc", "imgId", "by", "otherFor"};

    static String movKey(JSONObject x) { return x.optString("srvId").isEmpty() ? String.valueOf(x.optInt("id")) : x.optString("srvId"); }

    static JSONArray catsJson(Context c, boolean out) {
        try { return new JSONArray(Store.get(c, out ? "expCats" : "incCats", "")); } catch (Exception e) { return new JSONArray(java.util.Arrays.asList(out ? MainActivity.EXP_CATS : MainActivity.INC_CATS)); }
    }

    static JSONObject finLocal(Context c) throws Exception {
        JSONObject f = new JSONObject(), m;
        try { m = new JSONObject(Store.get(c, "propOwner", "{}")); } catch (Exception e) { m = new JSONObject(); }
        for (Iterator<String> it = m.keys(); it.hasNext(); ) { String k = it.next(); f.put("o:" + k, m.optString(k)); }
        f.put("expCats", catsJson(c, true).toString());
        f.put("incCats", catsJson(c, false).toString());
        return f;
    }
    static volatile long lastRun = 0;
    static volatile boolean running = false, hold = false, deferred = false;
    static volatile Runnable onChange = null;

    static boolean on(Context c) { return TeamNet.ready(c); }

    static String norm(Object v) {
        if (v == null || v == JSONObject.NULL) return "";
        if (v instanceof Number) {
            double d = ((Number) v).doubleValue();
            if (d == 0) return "";
            return d == Math.rint(d) ? String.valueOf((long) d) : String.valueOf(d);
        }
        if (v instanceof Boolean) return ((Boolean) v) ? "true" : "";
        return v.toString();
    }

    static JSONObject snap(Context c) {
        try { return new JSONObject(Store.get(c, "syncSnap", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    static Set<String> keys(JSONObject a, JSONObject b, JSONObject d, Set<String> skip) {
        Set<String> k = new HashSet<>();
        for (JSONObject o : new JSONObject[]{a, b, d}) if (o != null) for (Iterator<String> it = o.keys(); it.hasNext(); ) k.add(it.next());
        k.removeAll(skip);
        return k;
    }

    /** Vista de un pago para comparar: sus campos + el inquilino y mes donde está. */
    static JSONObject payView(JSONObject p, JSONObject r) {
        JSONObject v = new JSONObject();
        try {
            for (String k : PAY_F) if (p.has(k)) v.put(k, p.get(k));
            v.put("tid", r.optInt("tid"));
            v.put("month", r.optString("month"));
        } catch (Exception ignored) { }
        return v;
    }

    static JSONObject cfg(Context c) {
        JSONObject o = new JSONObject();
        try {
            o.put("cur", Store.get(c, "cur", "$"));
            o.put("dueDay", Store.getI(c, "dueDay", 1));
            o.put("company", Store.get(c, "company", "Amigo Renta"));
        } catch (Exception ignored) { }
        return o;
    }

    static void auto(Context c) {
        if (hold) { deferred = true; return; }
        deferred = false;
        run(c);
    }

    static String run(Context c) {
        if (!on(c)) return "Falta configurar el servidor del equipo";
        if (running) return null;
        running = true;
        try { return doRun(c); } finally { running = false; lastRun = System.currentTimeMillis(); }
    }

    /** Diferencias de un objeto contra la foto de la última sincronización. */
    static JSONObject diff(JSONObject cur, JSONObject s, Set<String> fields, Map<String, String> base) throws Exception {
        JSONObject set = new JSONObject();
        for (String k : fields) {
            Object v = cur.opt(k);
            String now = norm(v), old = s == null ? null : s.optString(k, "");
            base.put(k, now);
            if (old == null ? !now.isEmpty() : !now.equals(old)) set.put(k, v == null ? "" : v);
        }
        return set;
    }

    static String doRun(Context c) {
        try {
            JSONObject snap = snap(c);
            List<JSONObject> tenants, recs;
            synchronized (Store.class) {
                tenants = Store.list(c, "tenants");
                recs = Store.list(c, "recs");
                boolean add = false;
                for (JSONObject r : recs) {
                    JSONArray a = r.optJSONArray("payments");
                    if (a != null) for (int i = 0; i < a.length(); i++) {
                        JSONObject p = a.optJSONObject(i);
                        if (p != null && p.optString("uuid").isEmpty()) { p.put("uuid", java.util.UUID.randomUUID().toString()); add = true; }
                    }
                }
                if (add) Store.save(c, "recs", recs);
            }
            uploadMovPhotos(c);
            List<JSONObject> movs = Store.list(c, "movs");
            JSONArray out = new JSONArray();
            Map<String, Map<String, String>> base = new HashMap<>();
            Set<String> live = new HashSet<>();
            // ---------- 1. lo que cambió en este teléfono ----------
            for (JSONObject t : tenants) {
                String sid = "t:" + t.optInt("id");
                live.add(sid);
                JSONObject s = snap.optJSONObject(sid);
                Map<String, String> b = new HashMap<>();
                JSONObject set = diff(t, s, keys(t, s, null, T_SKIP), b);
                base.put(sid, b);
                if (set.length() > 0) out.put(new JSONObject().put("kind", "rten").put("id", String.valueOf(t.optInt("id"))).put("set", set));
            }
            for (JSONObject r : recs) {
                String rid = r.optInt("tid") + "|" + r.optString("month"), sid = "r:" + rid;
                live.add(sid);
                JSONObject s = snap.optJSONObject(sid);
                Map<String, String> b = new HashMap<>();
                JSONObject set = diff(r, s, keys(r, s, null, R_SKIP), b);
                base.put(sid, b);
                if (set.length() > 0) out.put(new JSONObject().put("kind", "rrec").put("id", rid).put("set", set));
                JSONArray a = r.optJSONArray("payments");
                if (a != null) for (int i = 0; i < a.length(); i++) {
                    JSONObject p = a.optJSONObject(i);
                    if (p == null) continue;
                    String pid = "p:" + p.optString("uuid");
                    live.add(pid);
                    JSONObject ps = snap.optJSONObject(pid);
                    Map<String, String> pb = new HashMap<>();
                    Set<String> pf = new HashSet<>(java.util.Arrays.asList(PAY_F));
                    JSONObject pset = diff(payView(p, r), ps, pf, pb);
                    base.put(pid, pb);
                    if (pset.length() > 0) out.put(new JSONObject().put("kind", "rpay").put("id", p.optString("uuid")).put("set", pset));
                }
            }
            for (JSONObject x : movs) {
                String sid = "m:" + movKey(x);
                live.add(sid);
                JSONObject s = snap.optJSONObject(sid);
                Map<String, String> b = new HashMap<>();
                JSONObject set = diff(x, s, new HashSet<>(java.util.Arrays.asList(MOV_F)), b);
                base.put(sid, b);
                if (set.length() > 0) out.put(new JSONObject().put("kind", "rmov").put("id", movKey(x)).put("set", set));
            }
            JSONObject fin = finLocal(c), fs0 = snap.optJSONObject("fin");
            Map<String, String> fb = new HashMap<>();
            JSONObject fset = diff(fin, fs0, keys(fin, null, null, new HashSet<String>()), fb);
            if (fset.length() > 0) out.put(new JSONObject().put("kind", "rfin").put("id", "main").put("set", fset));
            for (Iterator<String> it = snap.keys(); it.hasNext(); ) { // borrados en este teléfono
                String sid = it.next();
                if (sid.equals("cfg") || sid.equals("fin") || live.contains(sid)) continue;
                String kind = sid.startsWith("t:") ? "rten" : sid.startsWith("r:") ? "rrec" : sid.startsWith("m:") ? "rmov" : "rpay";
                out.put(new JSONObject().put("kind", kind).put("id", sid.substring(2)).put("set", new JSONObject().put("deleted", true)));
            }
            JSONObject cfg = cfg(c), cs0 = snap.optJSONObject("cfg");
            Map<String, String> cb = new HashMap<>();
            JSONObject cset = diff(cfg, cs0, new HashSet<>(java.util.Arrays.asList(CFG_F)), cb);
            if (cset.length() > 0) out.put(new JSONObject().put("kind", "rcfg").put("id", "main").put("set", cset));
            // ---------- 2. enviar (en partes) ----------
            for (int i = 0; i < out.length(); i += 1500) {
                JSONArray part = new JSONArray();
                for (int j = i; j < Math.min(out.length(), i + 1500); j++) part.put(out.get(j));
                JSONObject body = new JSONObject().put("records", part).put("dev", "rentas");
                TeamNet.Res r = TeamNet.request(c, "POST", "/api/push", body.toString().getBytes(StandardCharsets.UTF_8), "application/json", null);
                if (r.error != null || r.code != 200) return TeamNet.errorOf(r.code, r.body, r.error);
            }
            for (Map.Entry<String, Map<String, String>> e : base.entrySet()) snap.put(e.getKey(), new JSONObject(e.getValue()));
            for (Iterator<String> it = snap.keys(); it.hasNext(); ) { String sid = it.next(); if (!sid.equals("cfg") && !sid.equals("fin") && !live.contains(sid)) it.remove(); }
            snap.put("cfg", new JSONObject(cb));
            snap.put("fin", new JSONObject(fb));
            // ---------- 3. traer lo que cambiaron otros (Manager) ----------
            long lastPull = Store.sp(c).getLong("teamPull", 0);
            TeamNet.Res r = TeamNet.request(c, "GET", "/api/changes?kinds=rten,rrec,rpay,rmov,rfin&since=" + Math.max(0, lastPull - 120000), null, null, null);
            if (r.error != null || r.code != 200) { Store.putS(c, "syncSnap", snap.toString()); return TeamNet.errorOf(r.code, r.body, r.error); }
            JSONObject res = new JSONObject(TeamNet.text(r.body));
            JSONArray in = res.getJSONArray("records");
            boolean chg = false;
            List<String> news = new ArrayList<>();
            List<String[]> photos = new ArrayList<>(); // {uuid del pago, id de la foto}
            List<String[]> movPhotos = new ArrayList<>(); // {clave del gasto, id de la foto}
            boolean movChg = false;
            synchronized (Store.class) {
                List<JSONObject> lt = Store.list(c, "tenants"), lr = Store.list(c, "recs"), lm = Store.list(c, "movs");
                for (int i = 0; i < in.length(); i++) {
                    JSONObject rec = in.getJSONObject(i);
                    String kind = rec.optString("kind"), id = rec.optString("id");
                    JSONObject data = rec.optJSONObject("data");
                    if (data == null) continue;
                    if (kind.equals("rmov")) {
                        String sid = "m:" + id;
                        JSONObject x = null;
                        for (JSONObject y : lm) if (movKey(y).equals(id)) { x = y; break; }
                        if (data.optBoolean("deleted")) { if (x != null) { lm.remove(x); movChg = true; } snap.remove(sid); continue; }
                        JSONObject s = snap.optJSONObject(sid);
                        boolean isNew = x == null;
                        if (isNew) {
                            if (data.optString("type").isEmpty()) continue;
                            x = new JSONObject();
                            x.put("id", Store.nextId(c));
                            x.put("srvId", id);
                            x.put("created", System.currentTimeMillis());
                            lm.add(x);
                            s = null;
                        }
                        if (merge(x, data, s, new HashSet<>(java.util.Arrays.asList(MOV_F)), snap, sid)) movChg = true;
                        if (isNew) {
                            movChg = true;
                            if (!data.optString("by").isEmpty())
                                news.add("G|" + data.optString("by") + " anotó " + ("in".equals(data.optString("type")) ? "un ingreso" : "un gasto") + " de " + Store.money(c, data.optDouble("amount", 0))
                                        + " · " + data.optString("cat") + (data.optString("prop").isEmpty() ? "" : " · " + data.optString("prop")));
                        }
                        if (!x.optString("imgId").isEmpty() && !x.optString("imgId").equals(x.optString("imgDl"))) movPhotos.add(new String[]{movKey(x), x.optString("imgId")});
                        continue;
                    }
                    if (kind.equals("rfin")) {
                        JSONObject m;
                        try { m = new JSONObject(Store.get(c, "propOwner", "{}")); } catch (Exception e) { m = new JSONObject(); }
                        JSONObject loc = finLocal(c), fs = snap.optJSONObject("fin");
                        Set<String> ks = new HashSet<>();
                        for (Iterator<String> it = data.keys(); it.hasNext(); ) { String k = it.next(); if (k.startsWith("o:")) ks.add(k); }
                        if (merge(loc, data, fs, ks, new JSONObject(), "x")) {
                            for (String k : ks) if (!loc.optString(k).isEmpty()) m.put(k.substring(2), loc.optString(k));
                            Store.putS(c, "propOwner", m.toString());
                            chg = true;
                        }
                        JSONObject nf = fs == null ? new JSONObject() : fs;
                        for (String k : ks) nf.put(k, norm(data.opt(k)));
                        snap.put("fin", nf);
                        continue;
                    }
                    if (kind.equals("rten")) {
                        String sid = "t:" + id;
                        JSONObject t = Store.tenant(lt, parseInt(id));
                        if (data.optBoolean("deleted")) { if (t != null) { lt.remove(t); chg = true; } snap.remove(sid); continue; }
                        JSONObject s = snap.optJSONObject(sid);
                        if (t == null) { t = new JSONObject(); t.put("id", parseInt(id)); lt.add(t); s = null; }
                        if (merge(t, data, s, keys(t, s, data, T_SKIP), snap, sid)) chg = true;
                    } else if (kind.equals("rrec")) {
                        String sid = "r:" + id;
                        String[] parts = id.split("\\|");
                        if (parts.length < 2) continue;
                        JSONObject rr = Store.rec(lr, parseInt(parts[0]), parts[1], !data.optBoolean("deleted"));
                        if (data.optBoolean("deleted")) { snap.remove(sid); continue; } // un mes nunca se borra si tiene pagos
                        Set<String> ks = keys(rr, snap.optJSONObject(sid), data, R_SKIP);
                        if (merge(rr, data, snap.optJSONObject(sid), ks, snap, sid)) chg = true;
                    } else if (kind.equals("rpay")) {
                        String sid = "p:" + id;
                        JSONObject[] found = findPay(lr, id);
                        if (data.optBoolean("deleted")) {
                            if (found != null) { removePay(found[0], found[1]); chg = true; }
                            snap.remove(sid);
                            continue;
                        }
                        JSONObject s = snap.optJSONObject(sid);
                        if (found == null) {
                            int tid = data.optInt("tid");
                            String m = data.optString("month");
                            if (tid <= 0 || m.isEmpty()) continue;
                            JSONObject p = new JSONObject();
                            p.put("id", Store.nextId(c));
                            p.put("uuid", id);
                            for (String k : PAY_F) if (!k.equals("tid") && !k.equals("month") && data.has(k)) p.put(k, data.get(k));
                            Store.stamp(c, p);
                            Store.rec(lr, tid, m, true).optJSONArray("payments").put(p);
                            JSONObject ns = new JSONObject();
                            for (String k : PAY_F) ns.put(k, norm(data.opt(k)));
                            snap.put(sid, ns);
                            chg = true;
                            if (!data.optString("imgId").isEmpty()) photos.add(new String[]{id, data.optString("imgId")});
                            JSONObject t = Store.tenant(lt, tid);
                            if (!data.optString("by").isEmpty())
                                news.add(data.optString("by") + " registró " + Store.money(c, data.optDouble("amount", 0)) + " de " + (t == null ? "un inquilino" : t.optString("name")) + " · " + Store.monthName(m));
                        } else {
                            JSONObject rr = found[0], p = found[1];
                            JSONObject view = payView(p, rr);
                            JSONObject ns = new JSONObject();
                            boolean moved = false;
                            for (String k : PAY_F) {
                                Object sv = data.opt(k);
                                String cur = norm(view.opt(k)), was = s == null ? cur : s.optString(k, "");
                                if (cur.equals(was)) {
                                    if (sv != null && !norm(sv).equals(cur)) {
                                        chg = true;
                                        if (k.equals("tid") || k.equals("month")) moved = true; else p.put(k, sv);
                                    }
                                    ns.put(k, sv == null ? "" : norm(sv));
                                } else ns.put(k, was);
                            }
                            snap.put(sid, ns);
                            if (!p.optString("imgId").isEmpty() && !p.optString("imgId").equals(p.optString("imgDl"))) photos.add(new String[]{id, p.optString("imgId")});
                            if (moved) {
                                removePay(rr, p);
                                Store.rec(lr, parseInt(ns.optString("tid")), ns.optString("month"), true).optJSONArray("payments").put(p);
                            }
                        }
                    }
                }
                if (chg) { Store.save(c, "tenants", lt); Store.save(c, "recs", lr); }
                if (movChg) { Store.sp(c).edit().putString("movs", new JSONArray(lm).toString()).commit(); chg = true; }
                Store.putS(c, "syncSnap", snap.toString());
                Store.sp(c).edit().putLong("teamPull", res.optLong("now")).putLong("lastSyncOk", System.currentTimeMillis()).apply();
            }
            for (String[] ph : photos) fetchPhoto(c, ph[0], ph[1]);
            for (String[] ph : movPhotos) fetchMovPhoto(c, ph[0], ph[1]);
            for (int i = 0; i < news.size(); i++) {
                String n = news.get(i);
                if (n.startsWith("G|")) Store.notifyNow(c, 61000 + i, "🧾 Gasto anotado por el equipo", n.substring(2));
                else Store.notifyNow(c, 61000 + i, "💵 Pago registrado por el equipo", n);
            }
            if (chg) { Runnable r2 = onChange; if (r2 != null) H.post(() -> { Runnable r3 = onChange; if (r3 != null) r3.run(); }); }
            return null;
        } catch (Exception e) {
            return "Error al sincronizar: " + e.getMessage();
        }
    }

    /** Baja la foto del comprobante que subió el Manager y la deja en el pago (Imágenes → Amigo Renta Comprobantes). */
    static void fetchPhoto(Context c, String uuid, String imgId) {
        try {
            if (android.os.Build.VERSION.SDK_INT < 29) return;
            TeamNet.Res r = TeamNet.request(c, "GET", "/api/file?id=" + java.net.URLEncoder.encode(imgId, "UTF-8"), null, null, null);
            if (r.error != null || r.code != 200 || r.body == null || r.body.length == 0) return;
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "comprobante_" + imgId + ".jpg");
            cv.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
            cv.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_PICTURES + "/Amigo Renta Comprobantes");
            android.net.Uri u = c.getContentResolver().insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (u == null) return;
            try (java.io.OutputStream os = c.getContentResolver().openOutputStream(u)) { os.write(r.body); }
            synchronized (Store.class) {
                List<JSONObject> lr = Store.list(c, "recs");
                JSONObject[] f = findPay(lr, uuid);
                if (f == null) return;
                f[1].put("img", u.toString());
                f[1].put("imgDl", imgId);
                Store.save(c, "recs", lr);
            }
        } catch (Exception ignored) { }
    }

    /** Sube (reducidas) las fotos de recibos de gastos que aún no están en el servidor, para que el Manager las vea. */
    static void uploadMovPhotos(Context c) {
        List<JSONObject> l;
        synchronized (Store.class) { l = Store.list(c, "movs"); }
        for (JSONObject x : l) {
            String img = x.optString("img");
            if (img.isEmpty() || img.equals(x.optString("imgFor"))) continue;
            try {
                byte[] jpg = shrink(c, android.net.Uri.parse(img));
                if (jpg == null) continue;
                String id = "exp-" + x.optInt("id") + "-" + Long.toString(System.currentTimeMillis(), 36);
                JSONObject body = new JSONObject().put("id", id).put("mime", "image/jpeg").put("data", android.util.Base64.encodeToString(jpg, android.util.Base64.NO_WRAP));
                TeamNet.Res r = TeamNet.request(c, "POST", "/api/file", body.toString().getBytes(StandardCharsets.UTF_8), "application/json", null);
                if (r.error != null || r.code != 200) continue;
                synchronized (Store.class) {
                    List<JSONObject> l2 = Store.list(c, "movs");
                    for (JSONObject y : l2) if (y.optInt("id") == x.optInt("id") && img.equals(y.optString("img"))) { y.put("imgId", id); y.put("imgFor", img); y.put("imgDl", id); }
                    Store.sp(c).edit().putString("movs", new JSONArray(l2).toString()).commit();
                }
            } catch (Exception ignored) { }
        }
        // si se quitó la foto, también se quita en el servidor
        synchronized (Store.class) {
            List<JSONObject> l2 = Store.list(c, "movs");
            boolean ch = false;
            for (JSONObject y : l2) if (y.optString("img").isEmpty() && !y.optString("imgId").isEmpty() && y.optString("imgId").equals(y.optString("imgDl"))) { y.remove("imgId"); y.remove("imgFor"); y.remove("imgDl"); ch = true; }
            if (ch) Store.sp(c).edit().putString("movs", new JSONArray(l2).toString()).commit();
        }
    }

    static byte[] shrink(Context c, android.net.Uri u) {
        try {
            android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (java.io.InputStream in = c.getContentResolver().openInputStream(u)) { android.graphics.BitmapFactory.decodeStream(in, null, o); }
            int sz = 1;
            while (Math.max(o.outWidth, o.outHeight) / (sz * 2) >= 1600) sz *= 2;
            android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
            o2.inSampleSize = sz;
            android.graphics.Bitmap b;
            try (java.io.InputStream in = c.getContentResolver().openInputStream(u)) { b = android.graphics.BitmapFactory.decodeStream(in, null, o2); }
            if (b == null) return null;
            int rot = 0;
            try (java.io.InputStream in = c.getContentResolver().openInputStream(u)) {
                int ori = new android.media.ExifInterface(in).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                rot = ori == 6 ? 90 : ori == 3 ? 180 : ori == 8 ? 270 : 0;
            } catch (Exception e) { }
            float k = Math.min(1f, 1600f / Math.max(b.getWidth(), b.getHeight()));
            android.graphics.Matrix mx = new android.graphics.Matrix();
            mx.postScale(k, k);
            if (rot != 0) mx.postRotate(rot);
            b = android.graphics.Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), mx, true);
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            b.compress(android.graphics.Bitmap.CompressFormat.JPEG, 72, bo);
            return bo.toByteArray();
        } catch (Exception e) { return null; }
    }

    /** Baja la foto del recibo que subió el Manager (Imágenes → Amigo Renta Comprobantes). */
    static void fetchMovPhoto(Context c, String key, String imgId) {
        try {
            if (android.os.Build.VERSION.SDK_INT < 29) return;
            TeamNet.Res r = TeamNet.request(c, "GET", "/api/file?id=" + java.net.URLEncoder.encode(imgId, "UTF-8"), null, null, null);
            if (r.error != null || r.code != 200 || r.body == null || r.body.length == 0) return;
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "recibo_" + imgId + ".jpg");
            cv.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
            cv.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_PICTURES + "/Amigo Renta Comprobantes");
            android.net.Uri u = c.getContentResolver().insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (u == null) return;
            try (java.io.OutputStream os = c.getContentResolver().openOutputStream(u)) { os.write(r.body); }
            synchronized (Store.class) {
                List<JSONObject> l = Store.list(c, "movs");
                for (JSONObject y : l) if (movKey(y).equals(key)) { y.put("img", u.toString()); y.put("imgFor", u.toString()); y.put("imgDl", imgId); }
                Store.sp(c).edit().putString("movs", new JSONArray(l).toString()).commit();
            }
            Runnable r2 = onChange;
            if (r2 != null) H.post(() -> { Runnable r3 = onChange; if (r3 != null) r3.run(); });
        } catch (Exception ignored) { }
    }

    static int parseInt(String s) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; } }

    /** Aplica los campos del servidor que no cambiaron aquí desde la última vez. */
    static boolean merge(JSONObject o, JSONObject data, JSONObject s, Set<String> fields, JSONObject snap, String sid) throws Exception {
        boolean chg = false;
        JSONObject ns = new JSONObject();
        for (String k : fields) {
            Object sv = data.opt(k);
            String cur = norm(o.opt(k)), was = s == null ? cur : s.optString(k, "");
            if (cur.equals(was)) {
                if (sv != null && !norm(sv).equals(cur)) { o.put(k, sv); chg = true; }
                ns.put(k, sv == null ? cur : norm(sv));
            } else ns.put(k, was);
        }
        snap.put(sid, ns);
        return chg;
    }

    static JSONObject[] findPay(List<JSONObject> recs, String uuid) {
        for (JSONObject r : recs) {
            JSONArray a = r.optJSONArray("payments");
            if (a != null) for (int i = 0; i < a.length(); i++) {
                JSONObject p = a.optJSONObject(i);
                if (p != null && uuid.equals(p.optString("uuid"))) return new JSONObject[]{r, p};
            }
        }
        return null;
    }

    static void removePay(JSONObject r, JSONObject p) {
        JSONArray a = r.optJSONArray("payments"), n = new JSONArray();
        if (a != null) for (int i = 0; i < a.length(); i++) if (a.opt(i) != p) n.put(a.opt(i));
        Store.put(r, "payments", n);
    }

    // ---------- cuándo sincronizar ----------
    static final Handler H = new Handler(Looper.getMainLooper());
    static final Runnable[] PENDING = {null};

    static void soon(Context c, long delayMs) {
        if (!on(c)) return;
        final Context app = c.getApplicationContext();
        if (PENDING[0] != null) H.removeCallbacks(PENDING[0]);
        PENDING[0] = () -> new Thread(() -> auto(app)).start();
        H.postDelayed(PENDING[0], delayMs);
    }

    static void schedule(Context c) {
        PendingIntent pi = PendingIntent.getBroadcast(c, 31, new Intent(c, Rx.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE))
                .setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + AlarmManager.INTERVAL_FIFTEEN_MINUTES, AlarmManager.INTERVAL_FIFTEEN_MINUTES, pi);
    }

    public static class Rx extends BroadcastReceiver {
        @Override
        public void onReceive(Context c, Intent i) {
            if (!on(c)) return;
            final PendingResult pr = goAsync();
            new Thread(() -> { try { auto(c); } finally { pr.finish(); } }).start();
        }
    }
}
