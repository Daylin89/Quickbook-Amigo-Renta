# Rentas Amigo Renta — Android v1.0

Control mensual de rentas: lista de inquilinos con su renta, pagos (completos o parciales), fechas prometidas,
seguimiento de quienes faltan por pagar con recordatorio por WhatsApp, lectura automática de los avisos de
INTERAC e-Transfer que llegan al correo del teléfono (acceso a notificaciones) y reporte en Excel
(manual o automático cada mes en Descargas/Amigo Renta Reportes).
Se compila con GitHub Actions (.github/workflows/compilar-apk.yml).
